//
//  HowTosData.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Array of HowToStruct structs obtained from the JSON file
// for use only in this file to create the database
fileprivate var arrayOfHowToStructs = [HowToStruct]()

public func createHowTosDatabase() {

    // ❎ Get object reference of Core Data managedObjectContext from the persistent container
    let managedObjectContext = PersistenceController.shared.persistentContainer.viewContext
    
    //----------------------------
    // ❎ Define the Fetch Request
    //----------------------------
    let fetchRequest = NSFetchRequest<HowTo>(entityName: "HowTo")
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "category", ascending: true), NSSortDescriptor(key: "title", ascending: true)]
    
    var listOfAllHowToEntitiesInDatabase = [HowTo]()
    
    do {
        //-----------------------------
        // ❎ Execute the Fetch Request
        //-----------------------------
        listOfAllHowToEntitiesInDatabase = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("Database Creation Failed!")
        return
    }
    
    if listOfAllHowToEntitiesInDatabase.count > 0 {
        print("Database has already been created!")
        return
    }
    
    print("Database will be created!")
    
    arrayOfHowToStructs = decodeJsonFileIntoArrayOfStructs(fullFilename: "HowTosData.json", fileLocation: "Main Bundle")

    for aHowTo in arrayOfHowToStructs {
        /*
         =============================
         *   HowTo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the HowTo entity in managedObjectContext
        let howToEntity = HowTo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        howToEntity.title = aHowTo.title
        howToEntity.category = aHowTo.category
        howToEntity.des_cription = aHowTo.description
        howToEntity.dateCreated = aHowTo.dateCreated
        
        // 3️⃣ Its relationship with another Entity is defined below
        
        /*
         =============================
         *   Video Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Video Entity in managedObjectContext
        let videoEntity = Video(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        videoEntity.title = aHowTo.video.title
        videoEntity.youTubeId = aHowTo.video.youTubeId
        videoEntity.des_cription = aHowTo.video.description
        videoEntity.datePublished = aHowTo.video.datePublished
        videoEntity.duration = aHowTo.video.duration
        videoEntity.furtherInfoUrl = aHowTo.video.furtherInfoUrl

        
        // 3️⃣ Establish one-to-one relationship between HowTo and Video
        howToEntity.video = videoEntity     // A howTo can have only one video
        videoEntity.howTo = howToEntity      // A video can belong to only one howTo
        
        /*
         =============================
         *   Audio Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Audio Entity in managedObjectContext
        let audioEntity = Audio(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Obtain the howTo audio file from Main Bundle
        let audioFileUrl = Bundle.main.url(forResource: aHowTo.audio.filename, withExtension: "m4a")
        
        do {
            // Try to get the audio file data from audioFileUrl
            audioEntity.howToAudio = try Data(contentsOf: audioFileUrl!, options: NSData.ReadingOptions.mappedIfSafe)
           
        } catch {
            fatalError("Audio file is not found in the main bundle!")
        }
         
        audioEntity.title = aHowTo.audio.title
        audioEntity.duration = aHowTo.audio.duration
         
        // 3️⃣ Establish one-to-one relationship between HowTo and Audio
        howToEntity.audio = audioEntity     // A HowTo can have only one audio
        audioEntity.howTo = howToEntity     // A Audio can belong to only one HowTo
        
        /*
         =============================
         *   Photo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Photo Entity in managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Obtain the howTo photo image from Assets.xcassets as UIImage
        let photoUIImage = UIImage(named: aHowTo.photo.filename)
        
        /*
         HowTo photo images have transparent backgrounds and therefore
         they are provided in the PNG format to preserve transparency.
         JPEG format cannot have transparency; therefore, PNG must be used.
         */
        
        // Convert photoUIImage to PNG data format
        if let data = photoUIImage?.pngData() {
            // Store PNG data into database attribute howToPhoto of type Binary Data
            photoEntity.howToPhoto = data
        } else {
            photoEntity.howToPhoto = nil
        }
        
        photoEntity.title = aHowTo.photo.title
        photoEntity.des_cription = aHowTo.photo.description
        
        // 3️⃣ Establish one-to-one relationship between HowTo and Photo
        howToEntity.photo = photoEntity         // A howTo can have only one photo
        photoEntity.howTo = howToEntity      // A photo can belong to only one howTo
        
        /*
         =================================
         *   Publisher Entity Creation   *
         =================================
         */
        
        // ❎ Define the fetch request
        let fetchRequest = NSFetchRequest<Publisher>(entityName: "Publisher")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        // Publisher name is equal to the 'aHowTo.publisher.name' in case insensitive manner
        fetchRequest.predicate = NSPredicate(format: "name ==[c] %@", aHowTo.publisher.name)
        
        var results = [Publisher]()
        var aPublisher = Publisher()

        do {
            // ❎ Execute the fetch request
            results = try managedObjectContext.fetch(fetchRequest)
            
            if results.isEmpty {
                /*
                 A publisher with 'aHowTo.publisher.name' does not exist in the database.
                 */
                // 1️⃣ Create an instance of the Publisher Entity in managedObjectContext
                aPublisher = Publisher(context: managedObjectContext)
                
                // 2️⃣ Dress it up by specifying its attributes
                aPublisher.name = aHowTo.publisher.name
                aPublisher.latitude = aHowTo.publisher.latitude as NSNumber
                aPublisher.longitude = aHowTo.publisher.longitude as NSNumber
                aPublisher.websiteUrl = aHowTo.publisher.websiteUrl
            } else {
                /*
                 A publisher with 'aHowTo.publisher.name' already exists in the database.
                 Store the found Publisher's object reference into aPublisher.
                 */
                aPublisher = results[0]
            }
        } catch {
            print("Publisher entity fetch failed!")
        }
        
        // 3️⃣ Establish one-to-many relationship between Publisher and HowTo
        howToEntity.publisher = aPublisher          // A howTo can have only one publisher
        aPublisher.howTos!.adding(howToEntity)     // A publisher can have many howTos
        
        /*
         *************************************
         ❎ Save Changes to Core Data Database
         *************************************
         */
        
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
    }   // End of for loop

}
