//
//  HowTosStructs.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation

struct HowToStruct: Decodable {
    
    var id: Int
    var title: String
    var category: String
    var description: String
    var dateCreated: String
    
    var video: VideoStruct
    var audio: AudioStruct
    var photo: PhotoStruct
    var publisher: PublisherStruct
}

struct VideoStruct: Decodable {
    var title: String
    var youTubeId: String
    var description: String
    var datePublished: String
    var duration: String
    var furtherInfoUrl: String
}

struct AudioStruct: Decodable {
    var filename: String
    var title: String
    var duration: String
}

struct PhotoStruct: Decodable {
    var filename: String
    var title: String
    var description: String
}

struct PublisherStruct: Decodable {
    var name: String
    var latitude: Double
    var longitude: Double
    var websiteUrl: String
}

/*
 {
     "id": 1,
     "title": "How to manage your time",
     "category": "Education",
     "description": "Time management is the process of planning and exercising conscious control of time spent on specific activities, especially to increase effectiveness, efficiency, and productivity.",
     "dateCreated": "2022-02-09",
     "video": {"title": "Parkinson's Law - Manage Your Time More Effectively", "youTubeId": "tlddeUri3GM", "description": "Let me introduce you to the Parkinson's Law. The law states this: 'Work expands so as to fill the time available for its completion.' Essentially the more time you have to complete something, the longer it will take you to finish it. And the less time you have to complete your goal, the more likely it is that you'll complete it in proposed time. But if a goal or a task does not have a specific deadline set, it will most likely never get done. In this video you'll learn how to use the Parkinson's Law to your advantage and manage your time more effectively thanks to it.", "datePublished": "2019-03-13", "duration": "00:06:34", "furtherInfoUrl": "https://www.btytraining.com/"},
     "audio": {"filename": "HowToAudio1", "title": "How to manage your time - personal notes", "duration": "00:00:02.89"},
     "photo": {"filename": "HowToPhoto1", "title": "Photo about: How to manage your time", "description": "This photo is about how to manage your time"},
     "publisher": {"name": "Better Than Yesterday", "latitude": 40.222961, "longitude": -83.3745176, "websiteUrl": "https://www.btytraining.com/"}
 }
 */
