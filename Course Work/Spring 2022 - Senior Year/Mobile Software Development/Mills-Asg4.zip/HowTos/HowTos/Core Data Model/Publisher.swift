//
//  Publisher.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Publisher entity public class
public class Publisher: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var name: String?
    @NSManaged public var latitude: NSNumber?
    @NSManaged public var longitude: NSNumber?
    @NSManaged public var websiteUrl: String?
    
    // Relationship
    @NSManaged public var howTos: NSSet?
}

/*
 NSSet represents an unordered collection of objects in Objective-C
 programming language used internally in CoreData framework.
 
 We convert it to Swift array in DatabaseSearch.swift by typecasting it as follows:
 
    databaseSearchResults = foundPublisher.howTos?.allObjects as! [HowTo]
 
 'allObjects' is an array containing the NSSet’s members.
 We convert the 'allObjects' array to Swift array [HowTo] by typecasting with 'as!'
 */

extension Publisher {
    /*
     ✳️ Core Data @FetchRequest in SearchDatabase.swift invokes this class method
        to fetch all of the Publisher entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as Publisher.allPublishersFetchRequest() in any .swift file in your project.
     */
    static func allPublishersFetchRequest() -> NSFetchRequest<Publisher> {
        /*
         Create a fetchRequest to fetch HowTo entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the HowTo entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<Publisher>(entityName: "Publisher")
        
        // List the fetched publishers in alphabetical order with respect to publisher name.
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        return fetchRequest
    }

}
