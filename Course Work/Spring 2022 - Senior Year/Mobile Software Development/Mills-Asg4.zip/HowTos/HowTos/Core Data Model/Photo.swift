//
//  Photo.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Photo entity public class
public class Photo: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var howToPhoto: Data?    // 'Binary Data' type
    @NSManaged public var title: String?
    @NSManaged public var des_cription: String?
    
    // Relationship
    @NSManaged public var howTo: HowTo?
}
