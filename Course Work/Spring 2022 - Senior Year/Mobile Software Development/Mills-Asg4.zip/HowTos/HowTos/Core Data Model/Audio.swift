//
//  Audio.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Audio entity public class
public class Audio: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var howToAudio: Data?    // 'Binary Data' type
    @NSManaged public var title: String?
    @NSManaged public var duration: String?
    
    // Relationship
    @NSManaged public var howTo: HowTo?
}
