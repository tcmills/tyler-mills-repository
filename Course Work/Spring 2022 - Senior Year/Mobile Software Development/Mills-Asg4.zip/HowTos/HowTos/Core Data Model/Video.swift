//
//  Video.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Video entity public class
public class Video: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var title: String?
    @NSManaged public var youTubeId: String?
    @NSManaged public var des_cription: String?
    @NSManaged public var datePublished: String?
    @NSManaged public var duration: String?
    @NSManaged public var furtherInfoUrl: String?
    
    // Relationship
    @NSManaged public var howTo: HowTo?
}
