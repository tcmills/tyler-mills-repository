//
//  HowTo.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data HowTo entity public class
public class HowTo: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var title: String?
    @NSManaged public var category: String?
    @NSManaged public var des_cription: String?
    @NSManaged public var dateCreated: String?
    
    // Relationships
    @NSManaged public var video: Video?
    @NSManaged public var audio: Audio?
    @NSManaged public var photo: Photo?
    @NSManaged public var publisher: Publisher?
}

extension HowTo {
    /*
     ❎ CoreData @FetchRequest in FavoritesList.swift invokes this class method
        to fetch all of the HowTo entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as HowTo.allHowTosFetchRequest() in any .swift file in your project.
     */
    static func allHowTosFetchRequest() -> NSFetchRequest<HowTo> {
        /*
         Create a fetchRequest to fetch HowTo entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the HowTo entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<HowTo>(entityName: "HowTo")
        /*
         List the fetched howTos in alphabetical order with respect to howTo title.
         */
        fetchRequest.sortDescriptors = [
            // Sort key: howTo category and title
            NSSortDescriptor(key: "category", ascending: true),
            NSSortDescriptor(key: "title", ascending: true),
        ]
        
        return fetchRequest
    }

}

