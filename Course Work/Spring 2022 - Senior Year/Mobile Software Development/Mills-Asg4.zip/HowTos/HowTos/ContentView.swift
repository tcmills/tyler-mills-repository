//
//  ContentView.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            FavoritesList()
                .tabItem {
                    Image(systemName: "heart")
                    Text("Favorites")
            }
            SearchDatabase()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search Database")
            }
            
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
