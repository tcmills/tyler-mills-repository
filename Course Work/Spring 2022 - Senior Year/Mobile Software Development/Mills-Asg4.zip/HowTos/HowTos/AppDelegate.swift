//
//  AppDelegate.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 3/31/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        /*
        *******************************
        *   Create How-Tos Database   *
        *******************************
        */
        createHowTosDatabase()      // Given in HowTosData.swift
        return true
    }
}
