//
//  AddHowTo.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData
import AVFoundation

fileprivate var audioRecorder: AVAudioRecorder!

struct AddHowTo: View {
    /*
     Display this view as a Modal View and enable it to dismiss itself
     to go back to the previous view in the navigation hierarchy.
     */
    @Environment(\.presentationMode) var presentationMode
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //---------------
    // HowTo Entity
    //---------------
    @State private var title = ""
    @State private var description = ""
    @State private var dateCreated = Date()
    
    let howToCategories = ["Business", "Education", "Finance", "Food", "Health", "Lifestyle", "Technology", "Other"]
    @State private var selectedIndex = 3
    
    //--------------------
    // HowTo Video Entity
    //--------------------
    @State private var videoTitle = ""
    @State private var youTubeId = ""
    @State private var videoDescription = ""
    @State private var videoDatePublished = Date()
    @State private var videoDuration = "00:00:00"
    @State private var furtherInfoUrl = ""
    
    //--------------------
    // HowTo Audio Entity
    //--------------------
    @State private var audioTitle = ""
    private let temporaryAudioFileUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("temp.m4a")
    @State private var recordingVoice = false
    
    //--------------------
    // HowTo Photo Entity
    //--------------------
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var useCamera = false
    @State private var usePhotoLibrary = true
    @State private var photoTitle = ""
    @State private var photoDescription = ""
    
    //-----------------
    // Publsiher Entity
    //-----------------
    @State private var publisherName = ""
    @State private var publisherWebsiteUrl = ""

    @State private var latitudeTextFieldValue = "0.0"
    @State private var latitude = 0.0
    @State private var longitudeTextFieldValue = "0.0"
    @State private var longitude = 0.0
    
    //--------------
    // Date Creation
    //--------------
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .long     // e.g., August 14, 2020
        return formatter
    }
       
    var dateClosedRange: ClosedRange<Date> {
        // Set minimum date to 40 years earlier than the current year
        let minDate = Calendar.current.date(byAdding: .year, value: -40, to: Date())!
           
        // Set maximum date to 10 years later than the current year
        let maxDate = Calendar.current.date(byAdding: .year, value: 10, to: Date())!
        return minDate...maxDate
    }
    
    /*
     ---------------
     MARK: Body View
     ---------------
     */
    var body: some View {
        /*
         Create Binding between 'useCamera' and 'usePhotoLibrary' boolean @State variables so that only one of them can be true.
         get
            A closure that retrieves the binding value. The closure has no parameters.
         set
            A closure that sets the binding value. The closure has the following parameter:
            newValue stored in $0: The new value of 'useCamera' or 'usePhotoLibrary' boolean variable as true or false.
         
         Custom get and set closures are run when a newValue is obtained from the Toggle when it is turned on or off.
         */
        let camera = Binding(
            get: { useCamera },
            set: {
                useCamera = $0
                if $0 == true {
                    usePhotoLibrary = false
                }
            }
        )
        let photoLibrary = Binding(
            get: { usePhotoLibrary },
            set: {
                usePhotoLibrary = $0
                if $0 == true {
                    useCamera = false
                }
            }
        )
        
        Form {
            Group {
                /*
                 **********************
                 *   HowTo Entity   *
                 **********************
                 */
                Section(header: Text("How-To Title")) {
                    TextField("Enter how-to title", text: $title)
                }
                Section(header: Text("How-To Category")) {
                    Picker("", selection: $selectedIndex) {
                        ForEach(0 ..< howToCategories.count, id: \.self) {
                            Text(howToCategories[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                }
                Section(header: Text("How-To Description"), footer:
                    Button(action: {
                        self.dismissKeyboard()
                    }) {
                        Image(systemName: "keyboard")
                            .font(Font.title.weight(.light))
                            .foregroundColor(.blue)
                    }
                ) {
                    TextEditor(text: $description)
                        .frame(height: 100)
                        .font(.custom("Helvetica", size: 14))
                        .foregroundColor(.primary)
                        .lineSpacing(2)
                        .multilineTextAlignment(.leading)
                }
                Section(header: Text("How-To Date Created")) {
                    DatePicker(
                        "Date Created",
                        selection: $dateCreated,
                        in: dateClosedRange,
                        displayedComponents: .date    // Sets DatePicker to pick a date
                    )
                }
                /*
                 ********************
                 *   Video Entity   *
                 ********************
                 */
                Section(header: Text("YouTube Video Title")) {
                    TextField("Enter YouTube video title", text: $videoTitle)
                }
                Section(header: Text("YouTube Video Id")) {
                    TextField("Enter YouTube video id", text: $youTubeId)
                }
                Section(header: Text("YouTube Video Description"), footer:
                    Button(action: {
                        self.dismissKeyboard()
                    }) {
                        Image(systemName: "keyboard")
                            .font(Font.title.weight(.light))
                            .foregroundColor(.blue)
                    }
                ) {
                    TextEditor(text: $videoDescription)
                        .frame(height: 100)
                        .font(.custom("Helvetica", size: 14))
                        .foregroundColor(.primary)
                        .lineSpacing(2)
                        .multilineTextAlignment(.leading)
                }
                Section(header: Text("YouTube Video Date Published")) {
                    DatePicker(
                        "Date Published",
                        selection: $videoDatePublished,
                        in: dateClosedRange,
                        displayedComponents: .date    // Sets DatePicker to pick a date
                    )
                }
                Section(header: Text("YouTube Video Duration")) {
                    TextField("Enter time as hh:mm:ss", text: $videoDuration)
                }
                Section(header: Text("Further Information Website")) {
                    TextField("Enter URL", text: $furtherInfoUrl)
                }
            }
            Group {
                /*
                 ********************
                 *   Audio Entity   *
                 ********************
                 */
                Section(header: Text("Audio Notes Title")) {
                    TextField("Enter audio notes title", text: $audioTitle)
                }
                Section(header: Text("Audio Notes Duration Time")) {
                    Text(userData.voiceRecordingDuration)
                }
                Section(header: Text("Voice Recording")) {
                    Button(action: {
                        voiceRecordingMicrophoneTapped()
                    }) {
                        voiceRecordingMicrophoneLabel
                    }
                }
                /*
                 ********************
                 *   Photo Entity   *
                 ********************
                 */
                Section(header: Text("Photo Title")) {
                    TextField("Enter photo title", text: $photoTitle)
                }
                Section(header: Text("Photo Description"), footer:
                    Button(action: {
                        self.dismissKeyboard()
                    }) {
                        Image(systemName: "keyboard")
                            .font(Font.title.weight(.light))
                            .foregroundColor(.blue)
                    }
                ) {
                    TextEditor(text: $photoDescription)
                        .frame(height: 100)
                        .font(.custom("Helvetica", size: 14))
                        .foregroundColor(.primary)
                        .lineSpacing(2)
                        .multilineTextAlignment(.leading)
                }
                Section(header: Text("Take or Pick Photo")) {
                    VStack {
                        Toggle("Use Camera", isOn: camera)
                        Toggle("Use Photo Library", isOn: photoLibrary)
                        
                        Button(action: {
                            showImagePicker = true
                        }) {
                            Text("Get Photo")
                                .padding()
                        }
                    }   // End of VStack
                }
                Section(header: Text("Photo")) {
                    photoImageTakenOrPicked
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100.0, height: 100.0)
                }
            }
            /*
             ************************
             *   Publisher Entity   *
             ************************
             */
            Group {
                Section(header: Text("Publisher Name")) {
                    TextField("Enter name exactly", text: $publisherName)
                }
                Section(header: Text("Publisher Location Latitude")) {
                    TextField("Latitude", text: $latitudeTextFieldValue)
                        .keyboardType(.numbersAndPunctuation)
                        .onSubmit {
                            if let lat = Double(latitudeTextFieldValue) {
                                latitude = lat
                                // Latitude must be a number between -90 and 90
                                if ((latitude > -90.0) && (latitude < 90.0)) {
                                    // Valid latitude value
                                } else {
                                    showAlertMessage = true
                                    alertTitle = "Invalid Latitude Value!"
                                    alertMessage = "Valid latitude must be > -90.0 and < 90.0"
                                }
                            } else {
                                showAlertMessage = true
                                alertTitle = "Invalid Latitude Value!"
                                alertMessage = "Entered latitude value \(latitudeTextFieldValue) is not a number."
                            }
                        }
                }
                Section(header: Text("Publisher Location Longitude")) {
                    TextField("Longitude", text: $longitudeTextFieldValue)
                        .keyboardType(.numbersAndPunctuation)
                        .onSubmit {
                            if let long = Double(longitudeTextFieldValue) {
                                longitude = long
                                // Longitude must be a number between -180 and 180
                                if ((longitude > -180.0) && (longitude < 180.0)) {
                                    // Valid longitude value
                                } else {
                                    showAlertMessage = true
                                    alertTitle = "Invalid Longitude Value!"
                                    alertMessage = "Valid longitude must be > -180.0 and < 180.0"
                                }
                            } else {
                                showAlertMessage = true
                                alertTitle = "Invalid Longitude Value!"
                                alertMessage = "Entered longitude value \(longitudeTextFieldValue) is not a number."
                            }
                        }
                }
                Section(header: Text("Publisher Website Url")) {
                    TextField("Enter publisher's website URL", text: $publisherWebsiteUrl)
                }
            }
            
        }   // End of Form
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .font(.system(size: 14))
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                  Button("OK") {
                      if alertTitle == "New How-To Saved!" {
                          // Dismiss this Modal View and go back
                          presentationMode.wrappedValue.dismiss()
                      }
                  }
                }, message: {
                  Text(alertMessage)
                })
            .navigationBarTitle(Text("Add New How-To"), displayMode: .inline)
            .navigationBarItems(trailing:
                Button(action: {
                    if inputDataValidated() {
                        saveNewHowTo()
                        
                        showAlertMessage = true
                        alertTitle = "New How-To Saved!"
                        alertMessage = "New How-To is successfully saved in the database."
                    } else {
                        showAlertMessage = true
                        alertTitle = "Missing Input Data!"
                        alertMessage = "Please enter all required data!"
                    }
                }) {
                    Text("Save")
            })
        
            .sheet(isPresented: $showImagePicker) {
                /*
                 🔴 We pass $showImagePicker and $photoImageData with $ sign into PhotoCaptureView
                 so that PhotoCaptureView can change them. The @Binding keywork in PhotoCaptureView
                 indicates that the input parameter is passed by reference and is changeable (mutable).
                 */
                PhotoCaptureView(showImagePicker: $showImagePicker,
                                 photoImageData: $photoImageData,
                                 cameraOrLibrary: useCamera ? "Camera" : "Photo Library")
            }
        
    }   // End of body var
    
    /*
     ---------------------------------
     MARK: Dismiss TextEditor Keyboard
     ---------------------------------
     */
    func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    /*
     --------------------------------------
     MARK: Voice Recording Microphone Label
     --------------------------------------
     */
    var voiceRecordingMicrophoneLabel: some View {
        VStack {
            Image(systemName: recordingVoice ? "mic.fill" : "mic.slash.fill")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.blue)
                .padding()
            Text(recordingVoice ? "Recording your voice... Tap to Stop!" : "Start Recording!")
                .multilineTextAlignment(.center)
        }
    }
    
    /*
     ---------------------------------------
     MARK: Voice Recording Microphone Tapped
     ---------------------------------------
     */
    func voiceRecordingMicrophoneTapped() {
        if audioRecorder == nil {
            recordingVoice = true
            userData.startDurationTimer()
            startRecording()
        } else {
            recordingVoice = false
            userData.stopDurationTimer()
            finishRecording()
        }
    }
    
    /*
     --------------------------------
     MARK: Start Voice Memo Recording
     --------------------------------
     */
    func startRecording() {

        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]

        do {
            audioRecorder = try AVAudioRecorder(url: temporaryAudioFileUrl, settings: settings)
            audioRecorder.record()
        } catch {
            finishRecording()
        }
    }
    
    /*
     ---------------------------------
     MARK: Finish Voice Memo Recording
     ---------------------------------
     */
    func finishRecording() {
        audioRecorder.stop()
        audioRecorder = nil
        recordingVoice = false
    }
    
    /*
    --------------------------------------------
    MARK: Photo Image Taken or Picked or Default
    --------------------------------------------
    */
    var photoImageTakenOrPicked: Image {
        
        if let imageData = photoImageData {
            // The public function is given in UtilityFunctions.swift
            let photo = getImageFromBinaryData(binaryData: imageData, defaultFilename: "ImageUnavailable")
            return photo
        } else {
            return Image("ImageUnavailable")
        }
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        if title.isEmpty || description.isEmpty {
            return false
        }
        
        if videoTitle.isEmpty || youTubeId.isEmpty || videoDescription.isEmpty || videoDuration.isEmpty || furtherInfoUrl.isEmpty {
            return false
        }
        
        if audioTitle.isEmpty || userData.voiceRecordingDuration.isEmpty {
            return false
        }
        
        if photoTitle.isEmpty || photoDescription.isEmpty {
            return false
        }
        
        if publisherName.isEmpty || publisherWebsiteUrl.isEmpty {
            return false
        }
        
        return true
    }
    
    /*
     ----------------------
     MARK: Save New HowTo
     ----------------------
     */
    func saveNewHowTo() {
        /*
         =============================
         *   HowTo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the HowTo entity in managedObjectContext
        let howToEntity = HowTo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        
        // Instantiate a DateFormatter object
        let dateFormatter = DateFormatter()

        // Set the date format to yyyy-MM-dd
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        // Format date created as above and convert it to String
        let formattedDateCreated = dateFormatter.string(from: dateCreated)
        
        howToEntity.title = title
        howToEntity.category = howToCategories[selectedIndex]
        howToEntity.des_cription = description
        howToEntity.dateCreated = formattedDateCreated
        
        // 3️⃣ Its relationship with another Entity is defined below
        
        /*
         =============================
         *   Video Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Video Entity in managedObjectContext
        let videoEntity = Video(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Format date published as above and convert it to String
        let formattedDatePublished = dateFormatter.string(from: videoDatePublished)
        
        videoEntity.title = videoTitle
        videoEntity.youTubeId = youTubeId
        videoEntity.des_cription = videoDescription
        videoEntity.datePublished = formattedDatePublished
        videoEntity.duration = videoDuration
        videoEntity.furtherInfoUrl = furtherInfoUrl
        
        
        // 3️⃣ Establish one-to-one relationship between HowTo and Video
        howToEntity.video = videoEntity         // A howTo can have only one video
        videoEntity.howTo = howToEntity      // A video can belong to only one howTo
        
        /*
         =============================
         *   Audio Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Audio Entity in managedObjectContext
        let audioEntity = Audio(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        do {
            // Try to get the audio file data from temporaryAudioFileUrl
            audioEntity.howToAudio = try Data(contentsOf: temporaryAudioFileUrl, options: NSData.ReadingOptions.mappedIfSafe)
        } catch {
            audioEntity.howToAudio = nil
        }
         
        audioEntity.title = audioTitle
        audioEntity.duration = userData.voiceRecordingDuration
        
        // 3️⃣ Establish one-to-one relationship between HowTo and Audio
        howToEntity.audio = audioEntity         // A howTo can have only one audio
        audioEntity.howTo = howToEntity      // A audio can belong to only one howTo
        
        /*
         =============================
         *   Photo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Video Entity in managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Obtain the howTo photo image from the taken or picked photo of the photo
        let photoUIImage = UIImage(data: photoImageData!)
        
        /*
         HowTo photo images have transparent backgrounds and therefore
         they are provided in the PNG format to preserve transparency.
         JPEG format cannot have transparency; therefore, PNG must be used.
         */
        
        // Convert photoUIImage to PNG data format
        if let data = photoUIImage?.pngData() {
            // Store PNG data into database attribute howToPhoto of type Binary Data
            photoEntity.howToPhoto = data
        } else {
            photoEntity.howToPhoto = nil
        }
        
        photoEntity.title = photoTitle
        photoEntity.des_cription = photoDescription
        
        // 3️⃣ Establish one-to-one relationship between HowTo and Photo
        howToEntity.photo = photoEntity         // A howTo can have only one photo
        photoEntity.howTo = howToEntity      // A photo can belong to only one howTo
        
        /*
         =================================
         *   Publisher Entity Creation   *
         =================================
         */
        
        // ✳️ Define the Fetch Request
        let fetchRequest = NSFetchRequest<Publisher>(entityName: "Publisher")
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
        
        // ✳️ Define the Search Criteria
        // Publisher name is equal to the new name in case insensitive manner
        fetchRequest.predicate = NSPredicate(format: "name ==[c] %@", publisherName)
        
        var results = [Publisher]()
        var aPublisher = Publisher()
        
        do {
            // ✳️ Execute the Fetch Request
            results = try managedObjectContext.fetch(fetchRequest)
            
            if results.isEmpty {
                // 1️⃣ Create an instance of the Publisher Entity in managedObjectContext
                aPublisher = Publisher(context: managedObjectContext)
                
                // 2️⃣ Dress it up by specifying its attributes
                aPublisher.name = publisherName
                aPublisher.latitude = latitude as NSNumber
                aPublisher.longitude = longitude as NSNumber
                aPublisher.websiteUrl = publisherWebsiteUrl
            } else {
                aPublisher = results[0]
            }
        } catch {
            print("Publisher entity fetch failed!")
        }
        
        // 3️⃣ Establish one-to-many relationship between HowTo and Publisher
        howToEntity.publisher = aPublisher          // A howTo can have only one publisher
        aPublisher.howTos!.adding(howToEntity)     // A publisher can have many howTos
        
        /*
         *************************************
         ❎ Save Changes to Core Data Database
         *************************************
         */
        
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
    }   // End of func saveNewHowTo
    
}

struct AddHowTo_Previews: PreviewProvider {
    static var previews: some View {
        AddHowTo()
    }
}
