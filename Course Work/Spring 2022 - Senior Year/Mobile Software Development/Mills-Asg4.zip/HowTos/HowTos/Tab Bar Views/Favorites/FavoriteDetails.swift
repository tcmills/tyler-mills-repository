//
//  FavoriteDetails.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import MapKit

struct FavoriteDetails: View {
    
    // ✳️ Input parameter: Core Data HowTo Entity instance reference
    let howTo: HowTo
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    @EnvironmentObject var audioPlayer: AudioPlayer
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("How-To Title")) {
                    Text(howTo.title ?? "")
                }
                Section(header: Text("How-To Category")) {
                    Text(howTo.category ?? "")
                }
                Section(header: Text("How-To Description")) {
                    Text(howTo.des_cription ?? "")
                }
                Section(header: Text("How-To Date Created")) {
                    Text(howTo.dateCreated ?? "")
                }
                Section(header: Text("YouTube Video Title")) {
                    Text(howTo.video?.title ?? "")
                }
                Section(header: Text("Play YouTube Video")) {
                    NavigationLink(destination: WebView(url: "http://www.youtube.com/embed/\(howTo.video?.youTubeId ?? "")")
                        .navigationBarTitle(Text("Play YouTube Video"), displayMode: .inline) )
                    {
                        HStack {
                            Image(systemName: "play.rectangle.fill")
                                .foregroundColor(.red)
                                .font(Font.title.weight(.regular))
                            Text("Play YouTube Video")
                        }
                    }
                }
                Section(header: Text("YouTube Video Description")) {
                    Text(howTo.video?.des_cription ?? "")
                }
                Section(header: Text("YouTube Video Date Published")) {
                    Text(howTo.video?.datePublished ?? "")
                }
                Section(header: Text("YouTube Video Duration")) {
                    Text(howTo.video?.duration ?? "")
                }
                Section(header: Text("Further Information Website")) {
                    // Show  howTo's video's website externally in default web browser
                    Link(destination: URL(string: howTo.video?.furtherInfoUrl ?? "")!) {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("For Further Information See")
                                .font(.system(size: 16))
                                .italic()
                        }
                        .foregroundColor(.blue)
                    }
                }
            }
            Group {
                Section(header: Text("Audio Notes Title")) {
                    Text(howTo.audio?.title ?? "")
                }
                Section(header: Text("Audio Notes Duration")) {
                    Text(howTo.audio?.duration ?? "")
                }
                Section(header: Text("Listen To Recorded Voice Notes")) {
                    Button(action: {
                        if audioPlayer.isPlaying {
                            audioPlayer.pauseAudioPlayer()
                        } else {
                            audioPlayer.startAudioPlayer()
                        }
                    }) {
                        HStack {
                            Image(systemName: audioPlayer.isPlaying ? "pause.fill" : "play.fill")
                                .font(Font.title.weight(.regular))
                            Text("Listen to Recorded Voice Notes")
                            }
                            .foregroundColor(.blue)
                        }
                }
                Section(header: Text("Photo Title")) {
                    Text(howTo.photo?.title ?? "")
                }
                Section(header: Text("Photo")) {
                    getImageFromBinaryData(binaryData: howTo.photo?.howToPhoto, defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                }
                Section(header: Text("Photo Description")) {
                    Text(howTo.photo?.des_cription ?? "")
                }
                Section(header: Text("Publisher Name")) {
                    Text(howTo.publisher?.name ?? "")
                }
                Section(header: Text("Publisher Location on Map")) {
                    let lat = howTo.publisher!.latitude as! Double
                    let long = howTo.publisher!.longitude as! Double
                    
                    if lat == 0.0 || long == 0.0 {
                        Text("Publisher location is not specified!")
                    } else {
                        NavigationLink(destination: locationMap) {
                            HStack {
                                Image(systemName: "map.fill")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                Text("Show Publisher Location on Map")
                                    .font(.system(size: 16))
                            }
                            .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
                            .foregroundColor(.blue)
                        }
                    }
                }
                Section(header: Text("Publisher Website")) {
                    // Show  howTo's publisher's website externally in default web browser
                    Link(destination: URL(string: howTo.publisher?.websiteUrl ?? "")!) {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Publisher Website")
                                .font(.system(size: 16))
                                .italic()
                        }
                        .foregroundColor(.blue)
                    }
                }
            }
            
        }   // End of Form
            .font(.system(size: 14))
            .navigationBarTitle(Text("How-To Details"), displayMode: .inline)
            .onAppear() {
                createPlayer()
            }
            .onDisappear() {
                audioPlayer.stopAudioPlayer()
            }
        
    }   // End of body var
    
    /*
    -------------------------
    MARK: Create Audio Player
    -------------------------
    */
    func createPlayer() {
        audioPlayer.createAudioPlayer(audioData: howTo.audio?.howToAudio ?? Data())
    }
    
    //-------------------------------------
    // HowTo Headquarters Location on Map
    //-------------------------------------
    var locationMap: some View {
        
        let lat = howTo.publisher!.latitude as! Double
        let long = howTo.publisher!.longitude as! Double
        
        return AnyView(MapView(mapType: MKMapType.standard, latitude: lat, longitude: long, delta: 1, deltaUnit: "degrees", annotationTitle: howTo.publisher?.name ?? "", annotationSubtitle: howTo.publisher?.name ?? "")
                .navigationBarTitle(Text(howTo.publisher?.name ?? ""), displayMode: .inline))
    }
    
}

