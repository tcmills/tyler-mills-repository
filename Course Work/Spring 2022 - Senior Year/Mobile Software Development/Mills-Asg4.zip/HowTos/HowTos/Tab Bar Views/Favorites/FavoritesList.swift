//
//  FavoritesList.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

struct FavoritesList: View {
    
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all HowTo entities from the database
    @FetchRequest(fetchRequest: HowTo.allHowTosFetchRequest()) var allHowTos: FetchedResults<HowTo>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        NavigationView {
            List {
                /*
                 Each NSManagedObject has internally assigned unique ObjectIdentifier
                 used by ForEach to display the HowTos in a dynamic scrollable list.
                 */
                ForEach(allHowTos) { aHowTo in
                    NavigationLink(destination: FavoriteDetails(howTo: aHowTo)) {
                        FavoriteItem(howTo: aHowTo)
                    }
                }
                .onDelete(perform: delete)
                
            }   // End of List
                .navigationBarTitle(Text("Favorites"), displayMode: .inline)
                
                // Place the Edit button on left and Add (+) button on right of the navigation bar
                .navigationBarItems(leading: EditButton(), trailing:
                    NavigationLink(destination: AddHowTo()) {
                        Image(systemName: "plus")
                })
            
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body
    
    /*
     -----------------------------
     MARK: Delete Selected HowTo
     -----------------------------
     */
    func delete(at offsets: IndexSet) {
        
        let howToToDelete = allHowTos[offsets.first!]
        
        // ❎ Delete Selected Recipe
        managedObjectContext.delete(howToToDelete)
        
        // ❎ Save Changes to Core Data Database
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
    }
    
}   // End of struct


struct FavoritesList_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesList()
    }
}
