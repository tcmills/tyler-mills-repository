//
//  Home.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

fileprivate let imageNames = ["HowToPhoto1", "HowToPhoto2", "HowToPhoto3", "HowToPhoto4", "HowToPhoto5", "HowToPhoto6", "HowToPhoto7", "HowToPhoto8", "HowToPhoto9", "HowToPhoto10", "HowToPhoto11", "HowToPhoto12", "HowToPhoto13", "HowToPhoto14", "HowToPhoto15", "HowToPhoto16", "HowToPhoto17", "HowToPhoto18", "HowToPhoto19", "HowToPhoto20", "HowToPhoto21", "HowToPhoto22", "HowToPhoto23", "HowToPhoto24", "HowToPhoto25", "HowToPhoto26", "HowToPhoto27", "HowToPhoto28", "HowToPhoto29", "HowToPhoto30"]

fileprivate let numberOfImages = 30

fileprivate let imageCaptions = ["How to manage your time", "How to apply to graduate school", "How to back up your iPhone, iPad, or iPod touch to iCloud", "How to buy a new car", "How to change a flat tire", "How to pay using Apple Pay in stores and other places", "How to avoid a phishing attack", "How to gain the skill of Mindful Living", "How to make ice cream", "How to be happy", "How to create a company", "How to invest in the stock market", "How to make pancakes", "How to lose weight", "How to meet and attract a perfect life partner", "How to manage your personal finances", "How to perform CPR", "How to write a resume", "How to restore your iPhone if you forgot your passcode", "How to perform the Heimlich Maneuver to a choking victim", "How to start an e-commerce business", "How to prevent the next pandemic", "How to protect yourself against cyber attacks", "How to become successful in life", "How to prepare for a job interview", "How to lose belly fat", "How to parallel park a car", "How to use AirDrop to transfer files between iPhone, iPad, and Mac", "How to make Margherita pizza at home", "How to get a car loan"]

struct Home: View {
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ✳️ Core Data FetchRequest returning all HowTo entities from the database
    @FetchRequest(fetchRequest: HowTo.allHowTosFetchRequest()) var allHowTos: FetchedResults<HowTo>
    
    @State private var index = 0
    /*
     Create a timer publisher that fires 'every' 3 seconds and updates the view.
     It runs 'on' the '.main' runloop so that it can update the view.
     It runs 'in' the '.common' mode so that it can run alongside other
     common events such as when the ScrollView is being scrolled.
     */
    @State private var timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                Image("Welcome")
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                
                Image(imageNames[index])
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                    .padding(10)
                
                    // Subscribe to the timer publisher
                    .onReceive(timer) { _ in
                        index += 1
                        if index > numberOfImages - 1 {
                            index = 0
                        }
                    }
                
                Text(imageCaptions[index])
                    .font(.headline)
                    // Allow lines to wrap around
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                
            }   // End of VStack
        }   // End of ScrollView
        .onAppear() {
            startTimer()
        }
        .onDisappear() {
            stopTimer()
        }

        }   // End of ZStack
    }   // End of var
    
    func startTimer() {
        timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    }
    
    func stopTimer() {
        timer.upstream.connect().cancel()
    }
    
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}

