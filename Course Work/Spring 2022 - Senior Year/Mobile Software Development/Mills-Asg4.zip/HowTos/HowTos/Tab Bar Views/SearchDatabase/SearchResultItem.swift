//
//  SearchResultItem.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchResultItem: View {
    
    // ✳️ Input parameter: Core Data HowTo Entity instance reference
    let howTo: HowTo
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        HStack {
            getImageFromUrl(url: "https://img.youtube.com/vi/\(howTo.video?.youTubeId ?? "")/mqdefault.jpg", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80.0, height: 80.0)
            
            VStack(alignment: .leading) {
                Text(howTo.title ?? "")
                Text(howTo.category ?? "")
                Text(howTo.publisher?.name ?? "")
            }
            .font(.system(size: 14))
        }
    }
}
