//
//  DatabaseSearch.swift
//  HowTos
//
//  Created by Tyler Mills and Osman Balci on 4/3/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Global Variable
var databaseSearchResults = [HowTo]()

// Global Search Parameters
var searchCategory = ""
var searchQuery = ""

fileprivate let managedObjectContext: NSManagedObjectContext = PersistenceController.shared.persistentContainer.viewContext

/*
 =====================
 MARK: Search Database
 =====================
 */
public func conductDatabaseSearch() {
    
    // Initialize the array of HowTo structs
    databaseSearchResults = [HowTo]()
    
    switch searchCategory {
    case "HowTo Title":
        searchHowToTitle()
    case "HowTo Category":
        searchHowToCategory()
    case "HowTo Description":
        searchHowToDescription()
    case "HowTo Date Created":
        searchHowToDateCreated()
    case "HowTo Video Title":
        searchVideoTitle()
    case "HowTo Video Description":
        searchVideoDescription()
    case "HowTo Video Date Published":
        searchVideoDatePublished()
    case "HowTo Audio Title":
        searchAudioTitle()
    case "HowTo Photo Title":
        searchPhotoTitle()
    case "HowTo Photo Description":
        searchPhotoDescription()
    case "HowTo Publisher Name":
        searchPublisherName()
    default:
        print("Search category is out of range!")
    }
}

/*
 ========================
 MARK: Search HowTo Title
 ========================
 */
public func searchHowToTitle() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch HowTo entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those HowTo entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<HowTo>(entityName: "HowTo")
    
    // List the fetched howTos in alphabetical order with respect to howTo title.
    fetchRequest.sortDescriptors = [
        // Sort key: howTo category and title
        NSSortDescriptor(key: "category", ascending: true),
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo title contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "title CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for HowTo title failed!")
    }
}

/*
 ===========================
 MARK: Search HowTo Category
 ===========================
 */
public func searchHowToCategory() {
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<HowTo>(entityName: "HowTo")
    
    // List the fetched howTos in alphabetical order with respect to howTo category.
    fetchRequest.sortDescriptors = [
        // Sort key: howTo category and title
        NSSortDescriptor(key: "category", ascending: true),
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo category contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "category CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for HowTo category failed!")
    }
}

/*
 ==============================
 MARK: Search HowTo Description
 ==============================
 */
public func searchHowToDescription() {
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<HowTo>(entityName: "HowTo")
    
    // List the fetched howTos in alphabetical order with respect to howTo description.
    fetchRequest.sortDescriptors = [
        // Sort key: howTo category and title
        NSSortDescriptor(key: "category", ascending: true),
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo description contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "des_cription CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for HowTo description failed!")
    }
}

/*
 ===============================
 MARK: Search HowTo Date Created
 ===============================
 */
public func searchHowToDateCreated() {
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<HowTo>(entityName: "HowTo")
    
    // List the fetched howTos in alphabetical order with respect to howTo date created.
    fetchRequest.sortDescriptors = [
        // Sort key: howTo category and title
        NSSortDescriptor(key: "category", ascending: true),
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo date created contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "dateCreated CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for HowTo date created failed!")
    }
}

/*
 ========================
 MARK: Search Video Title
 ========================
 */
public func searchVideoTitle() {
    /*
     // ❎ Core Data Video entity public class
     public class Video: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var title: String?
         @NSManaged public var youTubeId: String?
         @NSManaged public var des_cription: String?
         @NSManaged public var datePublished: String?
         @NSManaged public var duration: String?
         @NSManaged public var furtherInfoUrl: String?
         
         // Relationship
         @NSManaged public var howTo: HowTo?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Video>(entityName: "Video")
    
    // List the fetched videos in alphabetical order with respect to Video title.
    fetchRequest.sortDescriptors = [
        // Sort key: video title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo video title contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "title CONTAINS[c] %@", searchQuery)
    
    var videosFound = [Video]()
    
    do {
        // 3️⃣ Execute the Fetch Request
        videosFound = try managedObjectContext.fetch(fetchRequest)
        
        if videosFound.isEmpty {
            return
        }
        
        for aVideo in videosFound {
            if aVideo.howTo != nil {
                databaseSearchResults.append(aVideo.howTo!)
            }
        }
    } catch {
        print("fetchRequest for Video title failed!")
    }
}

/*
 ==============================
 MARK: Search Video Description
 ==============================
 */
public func searchVideoDescription() {
    /*
     // ❎ Core Data Video entity public class
     public class Video: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var title: String?
         @NSManaged public var youTubeId: String?
         @NSManaged public var des_cription: String?
         @NSManaged public var datePublished: String?
         @NSManaged public var duration: String?
         @NSManaged public var furtherInfoUrl: String?
         
         // Relationship
         @NSManaged public var howTo: HowTo?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Video>(entityName: "Video")
    
    // List the fetched videos in alphabetical order with respect to Video title.
    fetchRequest.sortDescriptors = [
        // Sort key: video title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo video description contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "des_cription CONTAINS[c] %@", searchQuery)
    
    var videosFound = [Video]()
    
    do {
        // 3️⃣ Execute the Fetch Request
        videosFound = try managedObjectContext.fetch(fetchRequest)
        
        if videosFound.isEmpty {
            return
        }
        
        for aVideo in videosFound {
            if aVideo.howTo != nil {
                databaseSearchResults.append(aVideo.howTo!)
            }
        }
    } catch {
        print("fetchRequest for Video description failed!")
    }
}

/*
 =================================
 MARK: Search Video Date Published
 =================================
 */
public func searchVideoDatePublished() {
    /*
     // ❎ Core Data Video entity public class
     public class Video: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var title: String?
         @NSManaged public var youTubeId: String?
         @NSManaged public var des_cription: String?
         @NSManaged public var datePublished: String?
         @NSManaged public var duration: String?
         @NSManaged public var furtherInfoUrl: String?
         
         // Relationship
         @NSManaged public var howTo: HowTo?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Video>(entityName: "Video")
    
    // List the fetched videos in alphabetical order with respect to Video title.
    fetchRequest.sortDescriptors = [
        // Sort key: video title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo video datePublished contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "datePublished CONTAINS[c] %@", searchQuery)
    
    var videosFound = [Video]()
    
    do {
        // 3️⃣ Execute the Fetch Request
        videosFound = try managedObjectContext.fetch(fetchRequest)
        
        if videosFound.isEmpty {
            return
        }
        
        for aVideo in videosFound {
            if aVideo.howTo != nil {
                databaseSearchResults.append(aVideo.howTo!)
            }
        }
    } catch {
        print("fetchRequest for Video datePublished failed!")
    }
}

/*
 ========================
 MARK: Search Audio Title
 ========================
 */
public func searchAudioTitle() {
    /*
     // ❎ Core Data Audio entity public class
     public class Audio: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var howToAudio: Data?    // 'Binary Data' type
         @NSManaged public var title: String?
         @NSManaged public var duration: String?
         
         // Relationship
         @NSManaged public var howTo: HowTo?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Audio>(entityName: "Audio")
    
    // List the fetched audios in alphabetical order with respect to Audio title.
    fetchRequest.sortDescriptors = [
        // Sort key: audio title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo audio title contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "title CONTAINS[c] %@", searchQuery)
    
    var audiosFound = [Audio]()
    
    do {
        // 3️⃣ Execute the Fetch Request
        audiosFound = try managedObjectContext.fetch(fetchRequest)
        
        if audiosFound.isEmpty {
            return
        }
        
        for aAudio in audiosFound {
            if aAudio.howTo != nil {
                databaseSearchResults.append(aAudio.howTo!)
            }
        }
    } catch {
        print("fetchRequest for Audio title failed!")
    }
}

/*
 ========================
 MARK: Search Photo Title
 ========================
 */
public func searchPhotoTitle() {
    /*
     // ❎ Core Data Photo entity public class
     public class Photo: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var howToPhoto: Data?    // 'Binary Data' type
         @NSManaged public var title: String?
         @NSManaged public var des_cription: String?
         
         // Relationship
         @NSManaged public var howTo: HowTo?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Photo>(entityName: "Photo")
    
    // List the fetched photos in alphabetical order with respect to Photo title.
    fetchRequest.sortDescriptors = [
        // Sort key: photo title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo photo title contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "title CONTAINS[c] %@", searchQuery)
    
    var photosFound = [Photo]()
    
    do {
        // 3️⃣ Execute the Fetch Request
        photosFound = try managedObjectContext.fetch(fetchRequest)
        
        if photosFound.isEmpty {
            return
        }
        
        for aPhoto in photosFound {
            if aPhoto.howTo != nil {
                databaseSearchResults.append(aPhoto.howTo!)
            }
        }
    } catch {
        print("fetchRequest for Photo title failed!")
    }
}

/*
 ==============================
 MARK: Search Photo Description
 ==============================
 */
public func searchPhotoDescription() {
    /*
     // ❎ Core Data Photo entity public class
     public class Photo: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var howToPhoto: Data?    // 'Binary Data' type
         @NSManaged public var title: String?
         @NSManaged public var des_cription: String?
         
         // Relationship
         @NSManaged public var howTo: HowTo?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Photo>(entityName: "Photo")
    
    // List the fetched photos in alphabetical order with respect to Photo title.
    fetchRequest.sortDescriptors = [
        // Sort key: photo title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo photo description contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "des_cription CONTAINS[c] %@", searchQuery)
    
    var photosFound = [Photo]()
    
    do {
        // 3️⃣ Execute the Fetch Request
        photosFound = try managedObjectContext.fetch(fetchRequest)
        
        if photosFound.isEmpty {
            return
        }
        
        for aPhoto in photosFound {
            if aPhoto.howTo != nil {
                databaseSearchResults.append(aPhoto.howTo!)
            }
        }
    } catch {
        print("fetchRequest for Photo description failed!")
    }
}

/*
 ===========================
 MARK: Search Publisher Name
 ===========================
 */
public func searchPublisherName() {
    /*
     // ❎ Core Data Publisher entity public class
     public class Publisher: NSManagedObject, Identifiable {

         // Attributes
         @NSManaged public var name: String?
         @NSManaged public var latitude: NSNumber?
         @NSManaged public var longitude: NSNumber?
         @NSManaged public var websiteUrl: String?
         
         // Relationship
         @NSManaged public var howTos: NSSet?
     }
     */
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Publisher>(entityName: "Publisher")
    
    // List the fetched publishers in alphabetical order with respect to Publisher name.
    fetchRequest.sortDescriptors = [
        // Sort key: publisher name
        NSSortDescriptor(key: "name", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // HowTo publisher name contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "name CONTAINS[c] %@", searchQuery)
    
    var publishersFound = [Publisher]()
    var publisherResult = Publisher()
    
    do {
        // 3️⃣ Execute the Fetch Request
        publishersFound = try managedObjectContext.fetch(fetchRequest)
        
        if publishersFound.isEmpty {
            return
        }
        
        publisherResult = publishersFound[0]
    } catch {
        print("fetchRequest for Publisher name failed!")
    }
    
    databaseSearchResults = publisherResult.howTos?.allObjects as! [HowTo]
}
