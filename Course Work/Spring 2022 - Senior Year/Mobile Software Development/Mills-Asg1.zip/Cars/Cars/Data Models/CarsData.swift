//
//  CarsData.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

// Global arrays of structs

var brandStructList     = [Brand]()
var modelStructList     = [Model]()

public func readDataFiles() {
    // The public function decodeJsonFileIntoArrayOfStructs() is given in UtilityFunctions.swift
    brandStructList   = decodeJsonFileIntoArrayOfStructs(fullFilename: "BrandsData.json", fileLocation: "Main Bundle")
    modelStructList   = decodeJsonFileIntoArrayOfStructs(fullFilename: "ModelsData.json", fileLocation: "Main Bundle")
}
