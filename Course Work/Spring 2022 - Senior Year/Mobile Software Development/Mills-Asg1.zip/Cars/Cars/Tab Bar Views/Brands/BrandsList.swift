//
//  BrandsList.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct BrandsList: View {
    // Alert: Part 1 of 4
    @State private var showSourceReferenceAlert = false
    
    var body: some View {
        NavigationView {
            List {
                // brandStructList is a global array of Brand structs given in CarsData.swift
                ForEach(brandStructList) { aBrand in
                    NavigationLink(destination: BrandDetails(brand: aBrand)) {
                        BrandItem(brand: aBrand)
                    }
                }
            }   // End of List
            .navigationBarTitle(Text("Car Brands"), displayMode: .inline)
            .navigationBarItems(trailing:
                Button(action: {
                    // Alert: Part 2 of 4
                    showSourceReferenceAlert = true
                }) {
                    Image(systemName: "info.circle")
                        .imageScale(.small)
                        .font(Font.title.weight(.light))
                }
            )
            // Alert: Part 3 of 4
            .alert(isPresented: $showSourceReferenceAlert, content: { sourceReferenceAlert })
            
        }   // End of NavigationView
        .customNavigationViewStyle()      // Given in NavigationStyle.swift
        
    }   // End of body
    
    // Alert: Part 4 of 4
    var sourceReferenceAlert: Alert {
        Alert(title: Text("Source Reference"),
              message: Text("Car brands data are taken from: https://en.wikipedia.org/wiki/List_of_automobile_manufacturers"),
              dismissButton: .default(Text("OK")) )
    }}

struct BrandsList_Previews: PreviewProvider {
    static var previews: some View {
        BrandsList()
    }
}
