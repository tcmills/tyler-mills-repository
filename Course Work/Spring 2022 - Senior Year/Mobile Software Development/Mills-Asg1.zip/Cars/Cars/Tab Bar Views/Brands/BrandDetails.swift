//
//  BrandDetails.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import MapKit

struct BrandDetails: View {
    
    // Input Parameter
    let brand: Brand
    
    @State private var selectedMapTypeIndex = 0
    var mapTypes = ["Standard", "Satellite", "Hybrid"]
    
    var body: some View {
        Form {
            Section(header: Text("Brand Name")) {
                Text(brand.brandName)
            }
            Section(header: Text("Parent Company Name")) {
                Text(brand.parentCompanyName)
            }
            Section(header: Text("Brand Logo")) {
                Image(brand.logoFilename)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
            }
            Section(header: Text("Brand Description")) {
                Text(brand.description)
            }
            Section(header: Text("Date Founded")) {
                Text(brand.dateFounded)
            }
            Section(header: Text("Company Headquarters")) {
                Text(brand.headquarters)
            }
            Section(header: Text("Brand Website")) {
                Link(destination: URL(string: brand.websiteUrl)!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("Show Website")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("Select Map Type")) {
                
                Picker("Select Map Type", selection: $selectedMapTypeIndex) {
                    ForEach(0 ..< mapTypes.count, id: \.self) { index in
                       Text(mapTypes[index]).tag(index)
                   }
                }
                .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                .pickerStyle(SegmentedPickerStyle())
                .padding(.horizontal)

                NavigationLink(destination: placeLocationOnMap) {
                    HStack {
                        Image(systemName: "mappin.and.ellipse")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("Show Company Headquarters Location on Map")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
                .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
            }
            
        }   // End of Form
        .navigationBarTitle(Text("\(brand.brandName)"), displayMode: .inline)
        .font(.system(size: 14))    // Set font and size for all Text views in the Form
        
    }   // End of body
    
    var placeLocationOnMap: some View {
        
        var mapType: MKMapType
       
        switch selectedMapTypeIndex {
        case 0:
            mapType = MKMapType.standard
        case 1:
            mapType = MKMapType.satellite
        case 2:
            mapType = MKMapType.hybrid
        default:
            fatalError("Map type is out of range!")
        }
        
        return AnyView( MapView(mapType: mapType, latitude: brand.latitude, longitude: brand.longitude, delta: 10.0, deltaUnit: "degrees", annotationTitle: brand.brandName, annotationSubtitle: brand.parentCompanyName)
                .navigationBarTitle(Text("\(brand.headquarters)"), displayMode: .inline)
                .edgesIgnoringSafeArea(.all) )
    }
}

struct BrandDetails_Previews: PreviewProvider {
    static var previews: some View {
        BrandDetails(brand: brandStructList[0])
    }
}
