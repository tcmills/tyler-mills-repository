//
//  SlideShow.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SlideShow: View {
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)    // Color the background to 10% gray
            TabView {
                // modelStructList is a global array of Model structs given in CarsData.swift
                ForEach(modelStructList) { model in
                    VStack {
                        Link(destination: URL(string: model.websiteUrl)!) {
                            Text("\(model.brandName) \(model.modelName)")
                                .font(.headline)
                                .multilineTextAlignment(.center)
                                .foregroundColor(.blue)
                                .padding()
                        }
                        Image(model.photoFilename)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    }
                }
            }   // End of TabView
                .tabViewStyle(PageTabViewStyle())
                // .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                // .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                .navigationBarTitle(Text("Car Models"), displayMode: .inline)

            }   // End of ZStack
            
        }   // End of NavigationView
            // Use single column navigation view for iPhone and iPad
            .navigationViewStyle(StackNavigationViewStyle())
    }
    
}

struct SlideShow_Previews: PreviewProvider {
    static var previews: some View {
        SlideShow()
    }
}
