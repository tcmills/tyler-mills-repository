//
//  ModelItem.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ModelItem: View {
    
    // Input Parameter
    let model: Model
    
    var body: some View {
        HStack {
            Image(model.logoFilename)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0)
            
            VStack(alignment: .leading) {
                Text(model.brandName)
                Text(model.modelName)
                Text(model.bodyStyle)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
}

struct ModelItem_Previews: PreviewProvider {
    static var previews: some View {
        ModelItem(model: modelStructList[0])
    }
}
