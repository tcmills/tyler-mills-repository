//
//  ModelDetails.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ModelDetails: View {
    
    // Input Parameter
    let model: Model
    
    var body: some View {
        Form {
            Section(header: Text("Brand Name")) {
                HStack {
                    Image(model.logoFilename)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100.0)
                    Text(model.brandName)
                }
            }
            Section(header: Text("Model Name")) {
                Text(model.modelName)
            }
            Section(header: Text("Model Photo")) {
                Image(model.photoFilename)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
            }
            Section(header: Text("Model Year")) {
                Text(model.year)
            }
            Section(header: Text("Model Body Style")) {
                Text(model.bodyStyle)
            }
            Section(header: Text("Starting MSRP")) {
                Text(model.startingMsrp)
            }
            Section(header: Text("Brand Website")) {
                Link(destination: URL(string: model.websiteUrl)!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("Show Website")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("Drive Type")) {
                Text(model.driveType)
            }
            Section(header: Text("Engine")) {
                Text(model.engine)
            }
            Section(header: Text("Miles Per Gallon (MPG)")) {
                Text(model.mpg)
            }
            
        }   // End of Form
        .navigationBarTitle(Text("\(model.brandName) \(model.modelName)"), displayMode: .inline)
        .font(.system(size: 14))    // Set font and size for all Text views in the Form
        
    }   // End of body
}

struct ModelDetails_Previews: PreviewProvider {
    static var previews: some View {
        ModelDetails(model: modelStructList[0])
    }
}
