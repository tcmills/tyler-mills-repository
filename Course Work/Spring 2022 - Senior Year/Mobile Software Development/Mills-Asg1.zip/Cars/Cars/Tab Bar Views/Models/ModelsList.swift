//
//  ModelsList.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ModelsList: View {
    
    var body: some View {
        NavigationView {
            List {
                // modelStructList is a global array of Model structs given in CarsData.swift
                ForEach(modelStructList) { aModel in
                    NavigationLink(destination: ModelDetails(model: aModel)) {
                        ModelItem(model: aModel)
                    }
                }
            }   // End of List
            .navigationBarTitle(Text("Car Models"), displayMode: .inline)
            
        }   // End of NavigationView
        .customNavigationViewStyle()      // Given in NavigationStyle.swift
        
    }   // End of body

}

struct ModelsList_Previews: PreviewProvider {
    static var previews: some View {
        ModelsList()
    }
}
