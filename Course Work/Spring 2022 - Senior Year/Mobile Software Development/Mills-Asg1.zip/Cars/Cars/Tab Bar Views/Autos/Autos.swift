//
//  Autos.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import MapKit

struct Autos: View {
    
    @State private var selectedMapTypeIndex = 0
    var mapTypes = ["Standard", "Satellite", "Hybrid"]
    
    @State private var selectedAuto = brandStructList[0]
   
    var body: some View {
        // NavigationView allows the NavigationLink for the map to be clickable, otherwise, the NavigationLink would be grayed out.
        NavigationView {
        ZStack {
            // Color the background to light gray
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
        VStack {
            Text("Automobiles")
                .font(.headline)
            
            ScrollView(.horizontal, showsIndicators: false) {
                HStack {
                    // brandStructList is a global array of Brand structs given in CarsData.swift
                    ForEach(brandStructList) { brand in
                   
                        Button(action: {
                            selectedAuto = brand
                        }) {
                            VStack {
                                Image(brand.logoFilename)
                                    .renderingMode(.original)
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(height: 60.0)
                                Text(brand.brandName)
                                    .fixedSize()
                                    .foregroundColor(brand == selectedAuto ? .red : .blue)
                                    .multilineTextAlignment(.center)
                            }
                        }   // End of Button
                       
                    }   // End of ForEach
                   
                }   // End of HStack
                .font(.system(size: 14))
               
            }   // End of ScrollView
            
            Divider()
            Form {
                Section(header: Text("Brand Name")) {
                    Text(selectedAuto.brandName)
                }
                Section(header: Text("Parent Company Name")) {
                    Text(selectedAuto.parentCompanyName)
                }
                Section(header: Text("Brand Description")) {
                    Text(selectedAuto.description)
                }
                Section(header: Text("Date Founded")) {
                    Text(selectedAuto.dateFounded)
                }
                Section(header: Text("Company Headquarters")) {
                    Text(selectedAuto.headquarters)
                }
                Section(header: Text("Brand Website")) {
                    Link(destination: URL(string: selectedAuto.websiteUrl)!) {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Website")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
                Section(header: Text("Select Map Type")) {
                    
                    Picker("Select Map Type", selection: $selectedMapTypeIndex) {
                        ForEach(0 ..< mapTypes.count, id: \.self) { index in
                           Text(mapTypes[index]).tag(index)
                       }
                    }
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                    .pickerStyle(SegmentedPickerStyle())
                    .padding(.horizontal)
                    
                    NavigationLink(destination: placeLocationOnMap) {
                        HStack {
                            Image(systemName: "mappin.and.ellipse")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Company Headquarters Location on Map")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                    .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
                }
                
            }   // End of Form
            .font(.system(size: 14))
            .navigationBarHidden(true)
           
        }   // End of VStack
        }   // End of ZStack
        }   // End of NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
    }   // End of body
    
    var placeLocationOnMap: some View {
        
        var mapType: MKMapType
       
        switch selectedMapTypeIndex {
        case 0:
            mapType = MKMapType.standard
        case 1:
            mapType = MKMapType.satellite
        case 2:
            mapType = MKMapType.hybrid
        default:
            fatalError("Map type is out of range!")
        }
        
        return AnyView( MapView(mapType: mapType, latitude: selectedAuto.latitude, longitude: selectedAuto.longitude, delta: 10.0, deltaUnit: "degrees", annotationTitle: selectedAuto.brandName, annotationSubtitle: selectedAuto.parentCompanyName)
                .navigationBarTitle(Text("\(selectedAuto.headquarters)"), displayMode: .inline)
                .edgesIgnoringSafeArea(.all) )
    }
}

struct Autos_Previews: PreviewProvider {
    static var previews: some View {
        Autos()
    }
}
