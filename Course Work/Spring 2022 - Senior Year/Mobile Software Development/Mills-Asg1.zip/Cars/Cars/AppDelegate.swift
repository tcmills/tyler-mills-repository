//
//  AppDelegate.swift
//  AppDelegate
//
//  Created by Osman Balci on 8/3/21.
//  Copyright © 2021 Osman Balci. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        /*
         *******************************
         Read Data Files upon App Launch
         *******************************
         */
        
        readDataFiles()     // Given in CarsData
        
        return true
    }

}
