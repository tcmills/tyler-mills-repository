//
//  ContentView.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            BrandsList()
                .tabItem {
                    Image(systemName: "list.bullet")
                    Text("Brands")
                }
            ModelsList()
                .tabItem {
                    Image(systemName: "list.bullet.rectangle")
                    Text("Models")
                }
            Autos()
                .tabItem {
                    Image(systemName: "car.2")
                    Text("Autos")
                }
            CarLoanCalculator()
                .tabItem {
                    Image(systemName: "dollarsign.square")
                    Text("Loan Calculator")
                }
            SlideShow()
                .tabItem {
                    Image(systemName: "rectangle.on.rectangle")
                    Text("Slide Show")
                }
                .onAppear() {
                    UIPageControl.appearance().currentPageIndicatorTintColor = .black
                    UIPageControl.appearance().pageIndicatorTintColor = .gray
                }
        }   // End of TabView
        .font(.headline)
        .imageScale(.medium)
        .font(Font.title.weight(.regular))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
