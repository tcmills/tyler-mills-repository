/*
**********************************************************
*   Statement of Compliance with the Stated Honor Code   *
**********************************************************
I hereby declare on my honor and I affirm that
 
 (1) I have not given or received any unauthorized help on this assignment, and
 (2) All work is my own in this assignment.
 
I am hereby writing my name as my signature to declare that the above statements are true:
   
      Tyler Christian Mills
 
**********************************************************
 */

//
//  CarsApp.swift
//  Cars
//
//  Created by Tyler Mills and Osman Balci on 2/13/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

@main
struct CarsApp: App {
    // App is a protocol that represents the structure and behavior of an app.
    
    /*
     Use the UIApplicationDelegateAdaptor property wrapper to direct SwiftUI
     to use the AppDelegate class for the application delegate.
     */
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    var body: some Scene {
        WindowGroup {
            // ContentView is the root view to be shown first upon app launch
            ContentView()
        }
    }
}
