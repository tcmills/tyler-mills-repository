//
//  NewsData.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import SwiftUI

// Global array of News structs
var newsStructList = [News]()

/*
 Each orderedSearchableNewsList element contains
 selected news attributes separated by vertical lines
 for inclusion in the search by the Search Bar in FavoritesList:
      "id|sourceName|author|title|descriptiion|publishedAt|content"
 */
var orderedSearchableNewsList = [String]()

/*
 Global flag to track changes to newsStructList.
 If changes are made, newsStructList will be written to document directory
 in NewsApp when the app life cycle state changes.
 */
var dataChanged = false

/*
 **************************
 MARK: Read News Data Files
 **************************
 */
public func readNewsDataFiles() {
    
    var documentDirectoryHasFiles = false
    let newsDataFullFilename = "NewsData.json"
    
    // Obtain URL of the NewsData.json file in document directory on the user's device
    // Global constant documentDirectory is defined in UtilityFunctions.swift
    let urlOfJsonFileInDocumentDirectory = documentDirectory.appendingPathComponent(newsDataFullFilename)

    do {
        /*
         Try to get the contents of the file. The left hand side is
         suppressed by using '_' since we do not use it at this time.
         Our purpose is just to check to see if the file is there or not.
         */

        _ = try Data(contentsOf: urlOfJsonFileInDocumentDirectory)
        
        /*
         If 'try' is successful, it means that the NewsData.json
         file exists in document directory on the user's device.
         ---
         If 'try' is unsuccessful, it throws an exception and
         executes the code under 'catch' below.
         */
        
        documentDirectoryHasFiles = true
        
        /*
         --------------------------------------------------
         |   The app is being launched after first time   |
         --------------------------------------------------
         The NewsData.json file exists in document directory on the user's device.
         Load it from Document Directory into newsStructList.
         */
        
        // The function is given in UtilityFunctions.swift
        newsStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: newsDataFullFilename, fileLocation: "Document Directory")
        print("NewsData is loaded from document directory")
        
    } catch {
        documentDirectoryHasFiles = false
        
        /*
         ----------------------------------------------------
         |   The app is being launched for the first time   |
         ----------------------------------------------------
         The NewsData.json file does not exist in document directory on the user's device.
         Load it from main bundle (project folder) into newsStructList.
         
         This catch section will be executed only once when the app is launched for the first time
         since we write and read the files in document directory on the user's device after first use.
         */
        
        // The function is given in UtilityFunctions.swift
        newsStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: newsDataFullFilename, fileLocation: "Main Bundle")
        print("NewsData is loaded from main bundle")
        
        /*
         --------------------------------------------------------
         |   Create global variable orderedSearchableNewsList   |
         --------------------------------------------------------
         This list has two purposes:
         
            (1) preserve the order of news according to user's liking, and
            (2) enable search of selected news attributes by the SearchBar in FavoritesList.
         
         Each list element consists of "id|sourceName|suthor|title|descriptiion|publishedAt|content".
         We chose these attributes separated by vertical lines to be included in the search.
         We separate them with "|" so that we can extract its components separately.
         For example, to obtain the id: list item.components(separatedBy: "|")[0]
         
         id is the first element in this list even though we do not need it for this search because without it,
         the articles will create duplicates of themselves for each sourceName. When id is added,
         it makes each article unique and therefore does not allow for any duplicates.
         */
        for news in newsStructList {
            let selectedNewsAttributesForSearch = "\(news.id)|\(news.sourceName)|\(news.author)|\(news.title)|\(news.description)|\(news.publishedAt)|\(news.content)"
            
            orderedSearchableNewsList.append(selectedNewsAttributesForSearch)
        }
        
    }   // End of do-catch
    
    /*
    -----------------------------------
    Read OrderedSearchableNewsList File
    -----------------------------------
    */
    if documentDirectoryHasFiles {
        // Obtain URL of the file in document directory on the user's device
        let urlOfFileInDocDir = documentDirectory.appendingPathComponent("OrderedSearchableNewsList")
        
        // Instantiate an NSArray object and initialize it with the contents of the file
        let arrayFromFile: NSArray? = NSArray(contentsOf: urlOfFileInDocDir)
        
        if let arrayObtained = arrayFromFile {
            // Store the unique id of the created array into the global variable
            orderedSearchableNewsList = arrayObtained as! [String]
        } else {
            print("OrderedSearchableNewsList file is not found in document directory on the user's device!")
        }
    }
}

/*
 *************************************************
 MARK: Write News Data Files to Document Directory
 *************************************************
 */
public func writeNewsDataFiles() {
    /*
    ------------------------------------------------------------------
    Write newsStructList into NewsData.json file in Document Directory
    ------------------------------------------------------------------
    */
    
    // Obtain URL of the JSON file into which data will be written
    let urlOfJsonFileInDocumentDirectory: URL? = documentDirectory.appendingPathComponent("NewsData.json")

    // Encode newsStructList into JSON and write it into the JSON file
    let encoder = JSONEncoder()
    if let encoded = try? encoder.encode(newsStructList) {
        do {
            try encoded.write(to: urlOfJsonFileInDocumentDirectory!)
        } catch {
            fatalError("Unable to write encoded news data to document directory!")
        }
    } else {
        fatalError("Unable to encode news data!")
    }
    
    /*
    -------------------------------------------------
    Write orderedSearchableNewsList into a file named
    OrderedSearchableNewsList in Document Directory
    -------------------------------------------------
    */

    // Obtain URL of the file in document directory on the user's device
    let urlOfFileInDocDirectory = documentDirectory.appendingPathComponent("OrderedSearchableNewsList")

    /*
    Swift Array does not yet provide the 'write' function, but NSArray does.
    Therefore, typecast the Swift array as NSArray so that we can write it.
    */
    
    (orderedSearchableNewsList as NSArray).write(to: urlOfFileInDocDirectory, atomically: true)
    
    /*
     The flag "atomically" specifies whether the file should be written atomically or not.
     
     If flag atomically is TRUE, the file is first written to an auxiliary file, and
     then the auxiliary file is renamed as OrderedSearchableNewsList.
     
     If flag atomically is FALSE, the file is written directly to OrderedSearchableNewsList.
     This is a bad idea since the file can be corrupted if the system crashes during writing.
     
     The TRUE option guarantees that the file will not be corrupted even if the system crashes during writing.
     */
    
    // Set global flag
    dataChanged = false
}

