//
//  PublisherStruct.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct Publisher: Hashable, Codable, Identifiable {
    
    var id: String
    var name: String
    var description: String
    var url: String
    var category: String
    var country: String
}

/*
 We create the Publisher structure above to represent a publisher
 JSON object with exactly the same attribute names.
 {
    "id": "abc-news",
    "name": "ABC News",
    "description": "Your trusted source for breaking news, analysis, exclusive interviews, headlines, and videos at ABCNews.com.",
    "url": "https://abcnews.go.com",
    "category": "general",
    "language": "en",
    "country": "us"
 }
 */
