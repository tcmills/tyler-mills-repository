//
//  UserData.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Combine
import SwiftUI

final class UserData: ObservableObject {

    /*
     ===============================================================================
                         Publisher-Subscriber Design Pattern
     ===============================================================================
     | Publisher:   @Published var under class conforming to ObservableObject      |
     | Subscriber:  Any View declaring '@EnvironmentObject var userData: UserData' |
     ===============================================================================
     
     By modifying the first View to be shown, ContentView(), with '.environmentObject(UserData())' in
     NewsApp, we inject an instance of this UserData() class into the environment and make it
     available to every View subscribing to it by declaring '@EnvironmentObject var userData: UserData'.
     
     When a change occurs in userData (e.g., deleting a news from the list, reordering news list,
     adding a new news to the list), every View subscribed to it is notified to re-render its View.
     ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     NOTE:  Only Views can subscribe to it. You cannot subscribe to it within
            a non-View Swift file such as our NewsData file.
     ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     */
    
    // Publish newsList with initial value of newsStructList obtained in NewsData
    @Published var newsList = newsStructList
    
    /*
     Publish searchableOrderedNewsList with initial value of
     orderedSearchableNewsList obtained in NewsData
     */
    @Published var searchableOrderedNewsList = orderedSearchableNewsList

}
