//
//  NewsStruct.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct News: Hashable, Codable, Identifiable {
    
    var id: UUID            // Storage Type: String, Use Type (format): UUID
    var sourceName: String
    var author: String
    var title: String
    var description: String
    var url: String
    var urlToImage: String
    var publishedAt: String
    var content: String
}

/*
 We create the News structure above to represent a news
 JSON object with exactly the same attribute names.
 {
     "id": "8BAFF88A-66DC-4112-83BA-FC81E7756CF5",
     "sourceName": "Space.com",
     "author": "Elizabeth Howell",
     "title": "How NASA's James Webb Space Telescope will get ready for its first cosmic observations - Space.com",
     "description": "Webb's instruments are being switched on as the telescope continues its commissioning.",
     "url": "https://www.space.com/james-webb-space-telescope-activation-plans",
     "urlToImage": "https://cdn.mos.cms.futurecdn.net/vbLeCUro5mhp6ipPaxprxf-1200-80.jpg",
     "publishedAt": "2022-01-30T12:25:32Z",
     "content": "With NASA's newest space observatory exactly on schedule in its commissioning phase, the science team outlined their plan to make the most of this $10 billion opportunity. The James Webb Space Teles… [+8527 chars]"
 }
 */
