//
//  FavoriteDetails.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct FavoriteDetails: View {
    
    // Input Parameter
    let news: News
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
            Section(header: Text("News Item Source Name")) {
                Text(news.sourceName)
            }
            Section(header: Text("News Item Image")) {
                // Public function getImageFromUrl is given in UtilityFunctions.swift
                getImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 320, alignment: .center)
            }
            Section(header: Text("News Item Title")) {
                Text(news.title)
            }
            Section(header: Text("News Item Publisher Website")) {
                Link(destination: URL(string: news.url)!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("News Item Publisher Website")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("News Item Author")) {
                Text(news.author)
            }
            Section(header: Text("News Item Description")) {
                Text(news.description)
            }
            Section(header: Text("News Item Publication Date And Time")) {
                PublicationDateAndTime(stringDate: news.publishedAt)
            }
            Section(header: Text("News Item Content")) {
                Text(news.content)
            }

        }   // End of Form
            .navigationBarTitle(Text("News Item Details"), displayMode: .inline)
            .font(.system(size: 14))
        
    }   // End of body
    
}

struct FavoriteDetails_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteDetails(news: newsStructList[0])
    }
}
