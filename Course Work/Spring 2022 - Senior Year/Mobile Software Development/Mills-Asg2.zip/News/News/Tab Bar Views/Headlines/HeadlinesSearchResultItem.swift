//
//  HeadlinesSearchResultItem.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct HeadlinesSearchResultItem: View {
    
    // Input Parameter
    let news: News
    
    var body: some View {
        HStack {
            // Public function getImageFromUrl is given in UtilityFunctions.swift
            getImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0)
            
            VStack(alignment: .leading) {
                Text(news.sourceName)
                Text(news.title)
                PublicationDateAndTime(stringDate: news.publishedAt)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
    
}

struct HeadlinesSearchResultItem_Previews: PreviewProvider {
    static var previews: some View {
        HeadlinesSearchResultItem(news: newsStructList[0])
    }
}
