//
//  HeadlinesSearchResultsList.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct HeadlinesSearchResultsList: View {
    var body: some View {
        List {
            // Each News struct has its own unique ID used by ForEach
            ForEach(newsSearchResults) { aNews in
                NavigationLink(destination: HeadlinesSearchResultDetails(news: aNews)) {
                    HeadlinesSearchResultItem(news: aNews)
                }
            }
            
        }   // End of List
        .navigationBarTitle(Text("Top News Headlines"), displayMode: .inline)
    }
}

struct HeadlinesSearchResultsList_Previews: PreviewProvider {
    static var previews: some View {
        HeadlinesSearchResultsList()
    }
}
