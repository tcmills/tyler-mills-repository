//
//  SearchHeadlines.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchHeadlines: View {
    
    @State private var searchCompleted = false
    
    let newsCategories = ["All", "Business", "Entertainment", "General", "Health", "Science", "Sports", "Technology"]
    @State private var selectedNewsCategoryIndex = 3
    
    @State private var newsSortOptions = ["Date", "Popularity", "Relevancy"]
    @State private var selectedNewsSortIndex = 0
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            Form {
                Section(header: Text("Select News Category")) {
                    Picker("", selection: $selectedNewsCategoryIndex) {
                        ForEach(0 ..< newsCategories.count, id: \.self) {
                            Text(newsCategories[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                }
                Section(header: Text("Select News Sort Option")) {
                    VStack {    // Enclose within VStack so that Picker is centered
                        Picker("", selection: $selectedNewsSortIndex) {
                            ForEach(0 ..< newsSortOptions.count, id: \.self) {
                                Text(String(newsSortOptions[$0]))
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                }
                Section(header: Text("Search Top News Headlines In USA")) {
                    HStack {
                        Button(action: {
                            searchApi()
                            searchCompleted = true
                        }) {
                            Text(searchCompleted ? "Search Completed" : "Search")
                        }
                        .frame(width: 240, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                }
                
                if searchCompleted {
                    Section(header: Text("Show Top News Headlines In USA")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("Show News Items Found")
                                    .font(.system(size: 16))
                            }
                        }
                        .frame(minWidth: 300, maxWidth: 500)
                    }
                    Section(header: Text("Clear")) {
                        HStack {
                            Button(action: {
                                searchCompleted = false
                            }) {
                                Text("Clear")
                            }
                            .frame(width: 120, height: 36, alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .strokeBorder(Color.black, lineWidth: 1)
                            )
                        }   // End of HStack
                    }
                }
                
            }   // End of Form
                .navigationBarTitle(Text("USA Top News Headlines"), displayMode: .inline)
                
            }   // End of ZStack
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body
    
    /*
     ----------------
     MARK: Search API
     ----------------
     */
    func searchApi() {
            let category = newsCategories[selectedNewsCategoryIndex].lowercased()
           
            var sortBy = ""
            switch newsSortOptions[selectedNewsSortIndex] {
            case "Date":
                sortBy = "publishedAt"
            case "Popularity":
                sortBy = "popularity"
            case "Relevancy":
                sortBy = "relevancy"
            default:
                sortBy = ""
            }
           
            var newsApiUrl = ""
            // If selected category is default value "all", we omit the category parameter.
            if category == "all" {
                newsApiUrl = "https://newsapi.org/v2/top-headlines?country=us&language=en&sortBy=\(sortBy)"
            } else {
                newsApiUrl = "https://newsapi.org/v2/top-headlines?country=us&language=en&category=\(category)&sortBy=\(sortBy)"
            }
           
            // This public function is given in NewsApiData.swift file
            getNewsItemsFromApi(apiUrl: newsApiUrl)
        }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array newsSearchResults is given in NewsApiData.swift
        if newsSearchResults.isEmpty {
            return AnyView(NotFound(message: "API Search Produced No Results!\n\nThe API did not return any value for the given search query!"))
        }
        
        return AnyView(HeadlinesSearchResultsList())
    }
    
}

struct SearchHeadlines_Previews: PreviewProvider {
    static var previews: some View {
        SearchHeadlines()
    }
}

