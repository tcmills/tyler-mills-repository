//
//  PublisherDetails.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct PublisherDetails: View {
    
    // Input Parameter
    let publisher: Publisher
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
            Section(header: Text("Publisher Name")) {
                Text(publisher.name)
            }
            Section(header: Text("Publisher Category")) {
                HStack {
                    
                    Image(getCategory())
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100.0)
                    Text("\(getCategory()) News")
                }
            }
            Section(header: Text("Publisher Description")) {
                Text(publisher.description)
            }
            Section(header: Text("Publisher Website")) {
                Link(destination: URL(string: publisher.url)!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("Publisher Website")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("Publisher Country")) {
                Text(publisher.country.uppercased())
            }

        }   // End of Form
            .navigationBarTitle(Text("Publisher Details"), displayMode: .inline)
            .font(.system(size: 14))
        
    }   // End of body
    
    func getCategory() -> String {
        
        var publisherImage = ""
        switch publisher.category {
        case "business":
            publisherImage = "Business"
        case "entertainment":
            publisherImage = "Entertainment"
        case "general":
            publisherImage = "General"
        case "health":
            publisherImage = "Health"
        case "science":
            publisherImage = "Science"
        case "sports":
            publisherImage = "Sports"
        case "technology":
            publisherImage = "Technology"
        default:
            publisherImage = ""
        }
        
        return publisherImage
    }
    
}

struct PublisherDetails_Previews: PreviewProvider {
    static var previews: some View {
        PublisherDetails(publisher: publisherSearchResults[0])
    }
}
