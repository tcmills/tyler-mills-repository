//
//  PublishersList.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct PublishersList: View {
    var body: some View {
        NavigationView {
            List {
                // Each Publisher struct has its own unique ID used by ForEach
                ForEach(publisherSearchResults) { aPublisher in
                    NavigationLink(destination: PublisherDetails(publisher: aPublisher)) {
                        PublisherItem(publisher: aPublisher)
                    }
                }
                
            }   // End of List
            .navigationBarTitle(Text("News Publishers"), displayMode: .inline)
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
    }
}

struct PublishersList_Previews: PreviewProvider {
    static var previews: some View {
        PublishersList()
    }
}
