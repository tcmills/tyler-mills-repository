//
//  PublisherItem.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct PublisherItem: View {
    
    // Input Parameter
    let publisher: Publisher
    
    var body: some View {
        HStack {
            
            Image(getCategory())
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0)
            
            VStack(alignment: .leading) {
                Text(publisher.name)
                Text("News Category: \(getCategory())")
                Text("Publisher Country: \(publisher.country.uppercased())")
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
    
    func getCategory() -> String {
        
        var publisherImage = ""
        switch publisher.category {
        case "business":
            publisherImage = "Business"
        case "entertainment":
            publisherImage = "Entertainment"
        case "general":
            publisherImage = "General"
        case "health":
            publisherImage = "Health"
        case "science":
            publisherImage = "Science"
        case "sports":
            publisherImage = "Sports"
        case "technology":
            publisherImage = "Technology"
        default:
            publisherImage = ""
        }
        
        return publisherImage
    }
    
}

struct PublisherItem_Previews: PreviewProvider {
    static var previews: some View {
        PublisherItem(publisher: publisherSearchResults[0])
    }
}
