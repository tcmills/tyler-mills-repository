//
//  NewsSearchResultDetails.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct NewsSearchResultDetails: View {
    
    // Input Parameter
    let news: News
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    @State private var showNewsAddedMessage = false
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
            Section(header: Text("Source Name")) {
                Text(news.sourceName)
            }
            Section(header: Text("News Item Image")) {
                // Public function getImageFromUrl is given in UtilityFunctions.swift
                getImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 320, alignment: .center)
            }
            Section(header: Text("News Item Title")) {
                Text(news.title)
            }
            Section(header: Text("Add this news to my favorites list")) {
                Button(action: {
                    // Append the news found to userData.newsList
                    userData.newsList.append(news)

                    // Set the global variable point to the changed list
                    newsStructList = userData.newsList
                    
                    let selectedNewsAttributesForSearch = "\(news.id)|\(news.sourceName)|\(news.author)|\(news.title)|\(news.description)|\(news.publishedAt)|\(news.content)"
                    
                    userData.searchableOrderedNewsList.append(selectedNewsAttributesForSearch)
                    
                    // Set the global variable point to the changed list
                    orderedSearchableNewsList = userData.searchableOrderedNewsList
                    
                    // Set global flag defined in NewsData
                    dataChanged = true
                    
                    showNewsAddedMessage = true
                }) {
                    HStack {
                        Image(systemName: "plus")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                            .foregroundColor(.blue)
                        Text("Add Found News Item to Favorites")
                            .font(.system(size: 16))
                    }
                }
            }
            Section(header: Text("News Item Publisher Website")) {
                Link(destination: URL(string: news.url)!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("News Item Publisher Website")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("News Item Author")) {
                Text(news.author)
            }
            Section(header: Text("News Item Description")) {
                Text(news.description)
            }
            Section(header: Text("News Item Publication Date And Time")) {
                PublicationDateAndTime(stringDate: news.publishedAt)
            }
            Section(header: Text("News Item Content")) {
                Text(news.content)
            }

        }   // End of Form
            .navigationBarTitle(Text("News Item Details"), displayMode: .inline)
            .alert(isPresented: $showNewsAddedMessage, content: { self.newsAddedMessage })
            .font(.system(size: 14))
        
    }   // End of body
    
    var newsAddedMessage: Alert {
        Alert(title: Text("News Item Added!"),
              message: Text("This news item is added to your favorites list."),
              dismissButton: .default(Text("OK")) )
    }
    
}

struct NewsSearchResultDetails_Previews: PreviewProvider {
    static var previews: some View {
        NewsSearchResultDetails(news: newsStructList[0])
    }
}
