//
//  SearchNews.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchNews: View {
    
    @State private var searchTextFieldValue = ""
    @State private var showMissingInputDataAlert = false
    @State private var searchCompleted = false
    
    @State private var apiEndpointOptions = ["Top Headlines", "Everything"]
    @State private var selectedEndpointIndex = 0
    
    @State private var newsSortOptions = ["Publication Date", "Popularity"]
    @State private var selectedNewsSortIndex = 0
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            Form {
                Section(header: Text("Select News API Endpoint")) {
                    VStack {    // Enclose within VStack so that Picker is centered
                        Picker("", selection: $selectedEndpointIndex) {
                            ForEach(0 ..< apiEndpointOptions.count, id: \.self) {
                                Text(String(apiEndpointOptions[$0]))
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                }
                Section(header: Text("Select News Sort Option")) {
                    VStack {    // Enclose within VStack so that Picker is centered
                        Picker("", selection: $selectedNewsSortIndex) {
                            ForEach(0 ..< newsSortOptions.count, id: \.self) {
                                Text(String(newsSortOptions[$0]))
                            }
                        }
                        .pickerStyle(SegmentedPickerStyle())
                    }
                }
                Section(header: Text("Enter Search String")) {
                    HStack {
                        TextField("Enter Search Query", text: $searchTextFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                        
                        // Button to clear the text field
                        Button(action: {
                            searchTextFieldValue = ""
                            showMissingInputDataAlert = false
                            searchCompleted = false
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                        
                    }   // End of HStack
                }
                Section(header: Text("Search News")) {
                    HStack {
                        Button(action: {
                            if inputDataValidated() {
                                searchApi()
                                searchCompleted = true
                            } else {
                                showMissingInputDataAlert = true
                            }
                        }) {
                            Text(searchCompleted ? "Search Completed" : "Search")
                        }
                        .frame(width: 240, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                }
                
                if searchCompleted {
                    Section(header: Text("Show News Items Found")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("Show News Items Found")
                                    .font(.system(size: 16))
                            }
                        }
                        .frame(minWidth: 300, maxWidth: 500)
                    }
                    Section(header: Text("Clear")) {
                        HStack {
                            Button(action: {
                                searchCompleted = false
                            }) {
                                Text("Clear")
                            }
                            .frame(width: 120, height: 36, alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .strokeBorder(Color.black, lineWidth: 1)
                            )
                        }   // End of HStack
                    }
                }
                
            }   // End of Form
                .navigationBarTitle(Text("Search News in English"), displayMode: .inline)
                .alert(isPresented: $showMissingInputDataAlert, content: { missingInputDataAlert })
                
            }   // End of ZStack
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body
    
    /*
     ----------------
     MARK: Search API
     ----------------
     */
    func searchApi() {
           
            // Remove spaces, if any, at the beginning and at the end of the entered search query string
            let searchStringTrimmed = searchTextFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
           
            let query = searchStringTrimmed.lowercased()
           
            // Replace all occurrences of space with +
            let searchQuery = query.replacingOccurrences(of: " ", with: "+")
           
            var endpoint = ""
            switch apiEndpointOptions[selectedEndpointIndex] {
            case "Top Headlines":
                endpoint = "top-headlines"
            case "Everything":
                endpoint = "everything"
            default:
                endpoint = ""
            }
           
            var sortBy = ""
            switch newsSortOptions[selectedNewsSortIndex] {
            case "Publication Date":
                sortBy = "publishedAt"
            case "Popularity":
                sortBy = "popularity"
            default:
                sortBy = ""
            }
           
            var newsApiUrl = ""
            if endpoint == "top-headlines" {
                newsApiUrl = "https://newsapi.org/v2/top-headlines?q=\(searchQuery)&language=en&sortBy=\(sortBy)"
            } else {
                newsApiUrl = "https://newsapi.org/v2/everything?q=\(searchQuery)&language=en&sortBy=\(sortBy)"
            }
           
            // This public function is given in NewsApiData.swift
            getNewsItemsFromApi(apiUrl: newsApiUrl)
        }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array newsSearchResults is given in NewsApiData.swift
        if newsSearchResults.isEmpty {
            return AnyView(NotFound(message: "API Search Produced No Results!\n\nThe API did not return any value for the given search query!"))
        }
        
        return AnyView(NewsSearchResultsList())
    }
    
    /*
     ------------------------------
     MARK: Missing Input Data Alert
     ------------------------------
     */
    var missingInputDataAlert: Alert {
        Alert(title: Text("Country Search Field is Empty!"),
              message: Text("Please enter a search query!"),
              dismissButton: .default(Text("OK")) )
        /*
         Tapping OK resets @State var showMissingInputDataAlert to false.
         */
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchTextFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if queryTrimmed.isEmpty {
            return false
        }
        return true
    }
    
}

struct SearchNews_Previews: PreviewProvider {
    static var previews: some View {
        SearchNews()
    }
}
