//
//  NewsSearchResultItem.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct NewsSearchResultItem: View {
    
    // Input Parameter
    let news: News
    
    var body: some View {
        HStack {
            // Public function getImageFromUrl is given in UtilityFunctions.swift
            getImageFromUrl(url: news.urlToImage, defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0)
            
            VStack(alignment: .leading) {
                Text(news.sourceName)
                Text(news.title)
                PublicationDateAndTime(stringDate: news.publishedAt)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
    
}

struct NewsSearchResultItem_Previews: PreviewProvider {
    static var previews: some View {
        NewsSearchResultItem(news: newsStructList[0])
    }
}
