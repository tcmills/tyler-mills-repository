//
//  NewsSearchResultsList.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct NewsSearchResultsList: View {
    var body: some View {
        List {
            // Each News struct has its own unique ID used by ForEach
            ForEach(newsSearchResults) { aNews in
                NavigationLink(destination: NewsSearchResultDetails(news: aNews)) {
                    NewsSearchResultItem(news: aNews)
                }
            }
            
        }   // End of List
        .navigationBarTitle(Text("News Search Results"), displayMode: .inline)
    }
}

struct NewsSearchResultsList_Previews: PreviewProvider {
    static var previews: some View {
        NewsSearchResultsList()
    }
}
