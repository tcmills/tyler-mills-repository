//
//  NewsApiData.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation

// Global variable
var newsSearchResults = [News]()

fileprivate var previousApiUrl = ""

/*
 ==========================================================
 Get News Search Results from the API for the Given API URL
 ==========================================================
*/
public func getNewsItemsFromApi(apiUrl: String) {
    
    // Avoid executing this function if already done for the same API URL
    if apiUrl == previousApiUrl {
        return
    } else {
        previousApiUrl = apiUrl
    }
    
    // Initialize the array of News structs
    newsSearchResults = [News]()
    
    
    
    var apiQueryUrlStruct: URL?
    
    if let urlStruct = URL(string: apiUrl) {
        apiQueryUrlStruct = urlStruct
    } else {
        // newsSearchResults will be empty
        return
    }

    /*
    *******************************
    *   HTTP GET Request Set Up   *
    *******************************
    */
    
    let headers = [
        "x-api-key": "a332c06d4b0d4a92891c489bd9c70107",
        "accept": "application/json",
        "cache-control": "no-cache",
        "connection": "keep-alive",
        "host": "newsapi.org"
    ]

    let request = NSMutableURLRequest(url: apiQueryUrlStruct!,
                                      cachePolicy: .useProtocolCachePolicy,
                                      timeoutInterval: 10.0)

    request.httpMethod = "GET"
    request.allHTTPHeaderFields = headers

    /*
    *********************************************************************
    *  Setting Up a URL Session to Fetch the JSON File from the API     *
    *  in an Asynchronous Manner and Processing the Received JSON File  *
    *********************************************************************
    */
    
    /*
     Create a semaphore to control getting and processing API data.
     signal() -> Int    Signals (increments) a semaphore.
     wait()             Waits for, or decrements, a semaphore.
     */
    let semaphore = DispatchSemaphore(value: 0)

    URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
        /*
        URLSession is established and the JSON file from the API is set to be fetched
        in an asynchronous manner. After the file is fetched, data, response, error
        are returned as the input parameter values of this Completion Handler Closure.
        */

        // Process input parameter 'error'
        guard error == nil else {
            // newsSearchResults will be empty
            semaphore.signal()
            return
        }
        
        /*
         ---------------------------------------------------------
         🔴 Any 'return' used within the completionHandler Closure
            exits the Closure; not the public function it is in.
         ---------------------------------------------------------
         */

        // Process input parameter 'response'. HTTP response status codes from 200 to 299 indicate success.
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            // newsSearchResults will be empty
            semaphore.signal()
            return
        }

        // Process input parameter 'data'. Unwrap Optional 'data' if it has a value.
        guard let jsonDataFromApi = data else {
            // newsSearchResults will be empty
            semaphore.signal()
            return
        }

        //------------------------------------------------
        // JSON data is obtained from the API. Process it.
        //------------------------------------------------
        do {
            /*
             Foundation framework’s JSONSerialization class is used to convert JSON data
             into Swift data types such as Dictionary, Array, String, Number, or Bool.
             */
            let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi,
                               options: JSONSerialization.ReadingOptions.mutableContainers)

            /*
             ******************************
             *   News API Documentation   *
             ******************************

             The green checkmark icon shows the JSON object we will use.

             {
             "status":"ok",
             "totalResults":38,
             "articles":[
             {"source":{"id":"cbs-news",✅"name":"CBS News"},
             ✅"author":"CBS News",
             ✅"title":"Winter storm Saturday affecting millions in Midwest and Northeast, bringing snow and ice - forecast today - CBS News",
             ✅"description":"All flights in and out of Chicago's O'Hare Airport were halted Friday night.",
             ✅"url":"https://www.cbsnews.com/live-updates/winter-storm-saturday-affecting-millions-in-midwest-and-northeast-bringing-snow-and-ice-forecast-today-2020-01-18/",
             ✅"urlToImage":"https://cbsnews1.cbsistatic.com/hub/i/r/2020/01/18/1d88de7f-1e1b-4aa6-9076-a6baa66e5417/thumbnail/1200x630g2/0f32d25c48ec97f6d95a6f60c6bb674d/ap-20018134585858.jpg",
             ✅"publishedAt":"2020-01-18T16:13:00Z",
             ✅"content":"CBS Minnesota's director of meteorology says there might be an additional half-inch of snow for parts of the state before noon Saturday, but the bigger threat will be high winds.\r\nWinds have already started kicking up on the western side of the state, with gu… [+817 chars]"},
              
             {"source":{"id":null,"name":"Bbc.com"},
             "author":"https://www.facebook.com/bbcnews",
             "title":"Why Iran plane disaster protests mark most serious test yet - BBC News",
             "description":"Unique factors make the latest anti-government protests different from those in the past.",
             "url":"https://www.bbc.com/news/world-middle-east-51147191",
             "urlToImage":"https://ichef.bbci.co.uk/news/1024/branded_news/A2CA/production/_110547614_mediaitem110547613.jpg",
             "publishedAt":"2020-01-18T15:22:37Z",
             "content":"Image copyrightAFPImage caption\r\n Many have been angered by the government's actions over the plane crash\r\nThe latest anti-government demonstrations sweeping Iran arguably pose the most serious challenge to the administration of any in its 40-year history.\r\nI… [+4893 chars]"},
              
             :
             :
             :
              
             ]
             }
             */
            
            /*
             JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
             Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
             where Dictionary Key type is String and Value type is Any (instance of any type)
             */
            var jsonDataDictionary = Dictionary<String, Any>()
            
            if let jsonObject = jsonResponse as? [String: Any] {
                jsonDataDictionary = jsonObject
            } else {
                // newsSearchResults will be empty
                semaphore.signal()
                return
            }
            
            //-----------------------
            // Obtain News JSON Array
            //-----------------------
                       
            var articlesJsonArray = [Any]()
            if let jArray = jsonDataDictionary["articles"] as? [Any] {
                articlesJsonArray = jArray
            } else {
                semaphore.signal()
                return
            }
            
            // Iterate over the articlesJsonArray containing JSON objects representing news
            for newsJsonObject in articlesJsonArray {
                
                //------------------------
                // Obtain News JSON Object
                //------------------------
                
                var newsDataDictionary = [String: Any]()
                
                if let jObject = newsJsonObject as? [String: Any] {
                    newsDataDictionary = jObject
                } else {
                    // Skip this news
                    break
                }
                
                //----------------------
                // Obtain News Item Name
                //----------------------

                var sourceName = ""
                
                /*
                 "source":{
                     "id":"cbs-news",
                     "name":"CBS News"
                 },
                 */
                if let nameDictionary = newsDataDictionary["source"] as? [String: Any] {
                    
                    if let name = nameDictionary["name"] as? String {
                        sourceName = name
                    } else {
                        // Skip this news
                        break
                    }
                } else {
                    // newsSearchResults will be empty
                    semaphore.signal()
                    return
                }

                //------------------------
                // Obtain News Item Author
                //------------------------

                var author = ""
                
                // "author":"CBS News"
                if !(newsDataDictionary["author"] is NSNull) {
                    if let newsAuthor = newsDataDictionary["author"] as? String {
                        author = newsAuthor
                    }
                }
                
                //-----------------------
                // Obtain News Item Title
                //-----------------------
                
                var title = ""

                // "title":"Winter storm Saturday affecting millions in Midwest and Northeast, bringing snow and ice - forecast today - CBS News"
                if let newsTitle = newsDataDictionary["title"] as? String {
                    title = newsTitle
                }

                //-----------------------------
                // Obtain News Item Description
                //-----------------------------

                var description = ""
                
                // "description":"All flights in and out of Chicago's O'Hare Airport were halted Friday night."
                if let newsDescription = newsDataDictionary["description"] as? String {
                    description = newsDescription
                }

                //---------------------
                // Obtain News Item Url
                //---------------------
                
                var url = ""

                // "url":"https://www.cbsnews.com/live-updates/winter-storm-saturday-affecting-millions-in-midwest-and-northeast-bringing-snow-and-ice-forecast-today-2020-01-18/"
                if let newsUrl = newsDataDictionary["url"] as? String {
                    url = newsUrl
                }

                //------------------------------
                // Obtain News Item Url To Image
                //------------------------------
                
                var urlToImage = ""

                // "urlToImage":"https://cbsnews1.cbsistatic.com/hub/i/r/2020/01/18/1d88de7f-1e1b-4aa6-9076-a6baa66e5417/thumbnail/1200x630g2/0f32d25c48ec97f6d95a6f60c6bb674d/ap-20018134585858.jpg"
                if let newsUrlToImage = newsDataDictionary["urlToImage"] as? String {
                    urlToImage = newsUrlToImage
                }

                //-----------------------------------
                // Obtain News Item Date Published At
                //-----------------------------------

                var publishedAt = ""
                
                // "publishedAt":"2020-01-18T16:13:00Z"
                if let newsDate = newsDataDictionary["publishedAt"] as? String {
                    publishedAt = newsDate
                }

                //-------------------------
                // Obtain News Item Content
                //-------------------------

                var content = ""
                
                // "content":"CBS Minnesota's director of meteorology says there might be an additional half-inch of snow for parts of the state before noon Saturday, but the bigger threat will be high winds.\r\nWinds have already started kicking up on the western side of the state, with gu… [+817 chars]"
                if let newsContent = newsDataDictionary["content"] as? String {
                    content = newsContent
                }

                //---------------------------------------------------------------
                // Create an Instance of News Struct and Append it to the List
                //---------------------------------------------------------------
                
                let newsFound = News(id: UUID(), sourceName: sourceName, author: author, title: title, description: description, url: url, urlToImage: urlToImage, publishedAt: publishedAt, content: content)
                
                newsSearchResults.append(newsFound)

            }   // End of for loop

        } catch {
            // newsSearchResults will be empty
            semaphore.signal()
            return
        }

        semaphore.signal()
    }).resume()

    /*
     The URLSession task above is set up. It begins in a suspended state.
     The resume() method starts processing the task in an execution thread.

     The semaphore.wait blocks the execution thread and starts waiting.
     Upon completion of the task, the Completion Handler code is executed.
     The waiting ends when .signal() fires or timeout period of 10 seconds expires.
    */

    _ = semaphore.wait(timeout: .now() + 10)

}
