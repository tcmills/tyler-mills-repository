//
//  PublishersApiData.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 3/1/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation

// Global variable
var publisherSearchResults = [Publisher]()

/*
 ===================================
 MARK: Obtain Publisher from the API
 ===================================
 */

/*
 This function is called upon app launch in AppDelegate to obtain the publisher
 from the API and make it ready for app's use.
 */
public func getPublishersFromApi() {

    let apiUrl = "https://newsapi.org/v2/sources?language=en"

    // Initialize the array of Publisher structs
    publisherSearchResults = [Publisher]()



    var apiQueryUrlStruct: URL?

    if let urlStruct = URL(string: apiUrl) {
        apiQueryUrlStruct = urlStruct
    } else {
        // publisherSearchResults will be empty
        return
    }

    /*
    *******************************
    *   HTTP GET Request Set Up   *
    *******************************
    */

    let headers = [
        "x-api-key": "a332c06d4b0d4a92891c489bd9c70107",
        "accept": "application/json",
        "cache-control": "no-cache",
        "connection": "keep-alive",
        "host": "newsapi.org"
    ]

    let request = NSMutableURLRequest(url: apiQueryUrlStruct!,
                                      cachePolicy: .useProtocolCachePolicy,
                                      timeoutInterval: 10.0)

    request.httpMethod = "GET"
    request.allHTTPHeaderFields = headers

    /*
    *********************************************************************
    *  Setting Up a URL Session to Fetch the JSON File from the API     *
    *  in an Asynchronous Manner and Processing the Received JSON File  *
    *********************************************************************
    */

    /*
     Create a semaphore to control getting and processing API data.
     signal() -> Int    Signals (increments) a semaphore.
     wait()             Waits for, or decrements, a semaphore.
     */
    let semaphore = DispatchSemaphore(value: 0)

    URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
        /*
        URLSession is established and the JSON file from the API is set to be fetched
        in an asynchronous manner. After the file is fetched, data, response, error
        are returned as the input parameter values of this Completion Handler Closure.
        */

        // Process input parameter 'error'
        guard error == nil else {
            // publisherSearchResults will be empty
            semaphore.signal()
            return
        }

        /*
         ---------------------------------------------------------
         🔴 Any 'return' used within the completionHandler Closure
            exits the Closure; not the public function it is in.
         ---------------------------------------------------------
         */

        // Process input parameter 'response'. HTTP response status codes from 200 to 299 indicate success.
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            // publisherSearchResults will be empty
            semaphore.signal()
            return
        }

        // Process input parameter 'data'. Unwrap Optional 'data' if it has a value.
        guard let jsonDataFromApi = data else {
            // publisherSearchResults will be empty
            semaphore.signal()
            return
        }

        //------------------------------------------------
        // JSON data is obtained from the API. Process it.
        //------------------------------------------------
        do {
            /*
             Foundation framework’s JSONSerialization class is used to convert JSON data
             into Swift data types such as Dictionary, Array, String, Number, or Bool.
             */
            let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi,
                               options: JSONSerialization.ReadingOptions.mutableContainers)

            /*
             ***********************************
             *   Publisher API Documentation   *
             ***********************************

             The green checkmark icon shows the JSON object we will use.

             {
             "status": "ok",
             "sources": [
             {
             ✅"id": "abc-news",
             ✅"name": "ABC News",
             ✅"description": "Your trusted source for breaking news, analysis, exclusive interviews, headlines, and videos at ABCNews.com.",
             ✅"url": "https://abcnews.go.com",
             ✅"category": "general",
             "language": "en",
             ✅"country": "us"
             },
              
             :
             :
             :
              
             ]
             }
             */

            /*
             JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
             Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
             where Dictionary Key type is String and Value type is Any (instance of any type)
             */
            var jsonDataDictionary = Dictionary<String, Any>()
            
            if let jsonObject = jsonResponse as? [String: Any] {
                jsonDataDictionary = jsonObject
            } else {
                // publisherSearchResults will be empty
                semaphore.signal()
                return
            }
            
            //----------------------------
            // Obtain Publisher JSON Array
            //----------------------------
                       
            var articlesJsonArray = [Any]()
            if let jArray = jsonDataDictionary["sources"] as? [Any] {
                articlesJsonArray = jArray
            } else {
                semaphore.signal()
                return
            }

            // Iterate over the searchResultsJsonArray containing JSON objects representing publisher
            for publisherJsonObject in articlesJsonArray {
                
                //-----------------------------
                // Obtain Publisher JSON Object
                //-----------------------------

                var publisherDataDictionary = [String: Any]()

                if let jObject = publisherJsonObject as? [String: Any] {
                    publisherDataDictionary = jObject
                } else {
                    // Skip this publisher
                    break
                }

                //--------------------
                // Obtain Publisher ID
                //--------------------

                var id = ""

                // "id": "abc-news"
                if let publisherId = publisherDataDictionary["id"] as? String {
                    id = publisherId
                }

                //----------------------
                // Obtain Publisher Name
                //----------------------

                var name = ""

                // "name": "ABC News"
                if let publisherName = publisherDataDictionary["name"] as? String {
                    name = publisherName
                }

                //-----------------------------
                // Obtain Publisher Description
                //-----------------------------

                var description = ""

                // "description": "Your trusted source for breaking news, analysis, exclusive interviews, headlines, and videos at ABCNews.com."
                if let publisherDescription = publisherDataDictionary["description"] as? String {
                    description = publisherDescription
                }

                //---------------------
                // Obtain Publisher Url
                //---------------------

                var url = ""

                // "url": "https://abcnews.go.com"
                if let publisherUrl = publisherDataDictionary["url"] as? String {
                    url = publisherUrl
                }

                //--------------------------
                // Obtain Publisher Category
                //--------------------------

                var category = ""

                // "category": "general"
                if let publisherCategory = publisherDataDictionary["category"] as? String {
                    category = publisherCategory
                }

                //-------------------------
                // Obtain Publisher Country
                //-------------------------

                var country = ""

                // "country": "us"
                if let publisherCountry = publisherDataDictionary["country"] as? String {
                    country = publisherCountry
                }

                //-----------------------------------------------------------------
                // Create an Instance of Publisher Struct and Append it to the List
                //-----------------------------------------------------------------

                let publisherFound = Publisher(id: id, name: name, description: description, url: url, category: category, country: country)

                publisherSearchResults.append(publisherFound)

            }   // End of for loop

        } catch {
            // publisherSearchResults will be empty
            semaphore.signal()
            return
        }

        semaphore.signal()
    }).resume()

    /*
     The URLSession task above is set up. It begins in a suspended state.
     The resume() method starts processing the task in an execution thread.

     The semaphore.wait blocks the execution thread and starts waiting.
     Upon completion of the task, the Completion Handler code is executed.
     The waiting ends when .signal() fires or timeout period of 10 seconds expires.
    */

    _ = semaphore.wait(timeout: .now() + 10)

}
