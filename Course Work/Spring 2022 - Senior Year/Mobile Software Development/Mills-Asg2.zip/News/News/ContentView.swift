//
//  ContentView.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            FavoritesList()
                .tabItem {
                    Image(systemName: "heart.fill")
                    Text("Favorites")
                }
            SearchHeadlines()
                .tabItem {
                    Image(systemName: "doc.richtext")
                    Text("Headlines")
                }
            SearchNews()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search")
                }
            PublishersList()
                .tabItem {
                    Image(systemName: "building.2.fill")
                    Text("Publishers")
                }
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
