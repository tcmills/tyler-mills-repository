//
//  AppDelegate.swift
//  News
//
//  Created by Tyler Mills and Osman Balci on 2/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        /*
         *****************************************
         Read News data files upon app launch
         *****************************************
         */
        readNewsDataFiles()            // In NewsData
        
        /*
         **********************************************************
         Obtain list of all publishers from the API upon app launch
         **********************************************************
         */
        getPublishersFromApi()        // In PublishersApiData
        
        return true
    }

}
