//
//  SurveysTakenStruct.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

public struct SurveysTaken: Hashable, Codable, Identifiable {
    
    // Property 'id' must be declared public because it matches a requirement in public protocol 'Identifiable'
    public var id: UUID                // Unique id of survey. Storage Type: String, Data Type: UUID
    var dateTime: String               // Survey date and time
    var answerToQuestion1: String      // Answer to survey question 1
    var answerToQuestion2: String      // Answer to survey question 2
    var answerToQuestion3: String      // Answer to survey question 3
    var answerToQuestion4: String      // Answer to survey question 4
    var answerToQuestion5: String      // Answer to survey question 5
    var answerToQuestion6: String      // Answer to survey question 6
    var answerToQuestion7: Int         // Answer to survey question 7
    var answerToQuestion8: String      // Answer to survey question 8
    var answerToQuestion9: String      // Answer to survey question 9
    var answerToQuestion10: Int        // Answer to survey question 10
    
}

/*
 {
     "id": "4E2A0B00-D9A3-4002-8B73-4316FD64C0AB",
     "dateTime": "2021-06-15 at 14:23:45",
     "answerToQuestion1": "2-3 times per week",
     "answerToQuestion2": "No",
     "answerToQuestion3": "4-6 times per week",
     "answerToQuestion4": "Ice cream, chocolate, cookies, candy",
     "answerToQuestion5": "Regular soda or other sugared beverages",
     "answerToQuestion6": "1 time per week",
     "answerToQuestion7": 3,
     "answerToQuestion8": "Racquetball",
     "answerToQuestion9": "No stress",
     "answerToQuestion10": 7
 }
 */
