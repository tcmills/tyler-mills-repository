//
//  VideoStruct.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

public struct Video: Hashable, Codable, Identifiable {
    
    // Property 'id' must be declared public because it matches a requirement in public protocol 'Identifiable'
    public var id: UUID                // Unique id of video. Storage Type: String, Data Type: UUID
    var youTubeId: String              // Id of youtube video
    var title: String                  // Video title
    var description: String            // Video description
    var durationTime: String           // Video duration
    var releaseDate: String            // Video release date
    var youTubeCategory: String        // Video youtube category
    
}

/*
 {
     "id": "C3669385-C69D-473B-A273-FEE011BDEF49",
     "youTubeId": "6-kviptjtXk",
     "title": "Apple Park: The New $5 Billion Headquarters",
     "description": "In this video, we go over the new Apple Campus 2 in Cupertino, California. For more Apple Headquarters mega project and engineering content, be sure to subscribe to Top Luxury.",
     "durationTime": "00:10:05",
     "releaseDate": "2020-09-25",
     "youTubeCategory": "People & Blogs"
 }
 */
