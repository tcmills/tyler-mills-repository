//
//  PersonalData.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import SwiftUI
import CoreLocation

// Global array of structs

var surveysTakenStructList = [SurveysTaken]()
var videoStructList = [Video]()
var dogBreedStructList = [DogBreed]()

/*
 Global flag to track changes to surveysTakenStructList and videoStructList.
 If changes are made, surveysTakenStructList and videoStructList will be written to document directory
 in PersonalApp when the app life cycle state changes.
 */
var dataChanged = false

/*
 *********************************
 MARK: Read SurveysTaken Data File
 *********************************
 */
public func readSurveysTakenDataFile() {
    
    let jsonDataFullFilename = "SurveysTakenData.json"
    
    // Obtain URL of the data file in document directory on user's device
    let urlOfJsonFileInDocumentDirectory = documentDirectory.appendingPathComponent(jsonDataFullFilename)

    do {
        _ = try Data(contentsOf: urlOfJsonFileInDocumentDirectory)

        surveysTakenStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: jsonDataFullFilename, fileLocation: "Document Directory")
        print("SurveysTakenData is loaded from document directory")
        
    } catch {
        /*
         SurveysTakenData.json file does not exist in the document directory; Load it from the main bundle.
         This happens only once when the app is launched for the very first time.
         */
        
        surveysTakenStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: jsonDataFullFilename, fileLocation: "Main Bundle")
        print("surveysTakenData is loaded from main bundle")
    }
}

/*
 **************************
 MARK: Read Video Data File
 **************************
 */
public func readVideoDataFile() {
    
    let jsonDataFullFilename = "VideosData.json"
    
    // Obtain URL of the data file in document directory on user's device
    let urlOfJsonFileInDocumentDirectory = documentDirectory.appendingPathComponent(jsonDataFullFilename)

    do {
        _ = try Data(contentsOf: urlOfJsonFileInDocumentDirectory)

        videoStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: jsonDataFullFilename, fileLocation: "Document Directory")
        print("VideosData is loaded from document directory")
        
    } catch {
        /*
         VideosData.json file does not exist in the document directory; Load it from the main bundle.
         This happens only once when the app is launched for the very first time.
         */
        
        videoStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: jsonDataFullFilename, fileLocation: "Main Bundle")
        print("VideosData is loaded from main bundle")
    }
}

/*
 *****************************
 MARK: Read DogBreed Data File
 *****************************
 */
public func readDogBreedDataFile() {
    // The public function decodeJsonFileIntoArrayOfStructs() is given in UtilityFunctions.swift
    dogBreedStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: "DogBreedsData.json", fileLocation: "Main Bundle")
}

/*
 ****************************************************
 MARK: Write Personal Data File to Document Directory
 ****************************************************
 */
public func writePersonalDataFile() {
    
    // Obtain URL of the first JSON file into which data will be written
    let urlOfJsonFileInDocumentDirectory1: URL? = documentDirectory.appendingPathComponent("SurveysTakenData.json")
    
    // Obtain URL of the second JSON file into which data will be written
    let urlOfJsonFileInDocumentDirectory2: URL? = documentDirectory.appendingPathComponent("VideosData.json")

    // Encode surveysTakenStructList into JSON and write it into the JSON file
    let encoder = JSONEncoder()
    if let encoded = try? encoder.encode(surveysTakenStructList) {
        do {
            try encoded.write(to: urlOfJsonFileInDocumentDirectory1!)
        } catch {
            fatalError("Unable to write encoded surveysTaken data to document directory!")
        }
    } else {
        fatalError("Unable to encode surveysTaken data!")
    }
    
    // Encode videoStructList into JSON and write it into the JSON file
    if let encoded = try? encoder.encode(videoStructList) {
        do {
            try encoded.write(to: urlOfJsonFileInDocumentDirectory2!)
        } catch {
            fatalError("Unable to write encoded video data to document directory!")
        }
    } else {
        fatalError("Unable to encode video data!")
    }
    
    // Set global flag defined above on top
    dataChanged = false
}

