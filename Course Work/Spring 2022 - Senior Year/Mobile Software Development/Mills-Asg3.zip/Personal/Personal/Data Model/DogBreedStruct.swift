//
//  DogBreedStruct.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct DogBreed: Hashable, Codable, Identifiable {
    
    var id: Int                        // Dog breed Id
    var name: String                   // Dog breed name
    var description: String            // Dog breed description
    var facePhotoFilename: String      // Photo of dog breed face
    var fullPhotoFilename: String      // Full photo of dog breed
    var websiteUrl: String             // Dog breed website url
    var lifeExpectancy: String         // Dog breed life expectancy
    var origin: String                 // Dog breed origin
    var weight: String                 // Dog breed weight
    var height: String                 // Dog breed height
    var colors: String                 // Dog breed colors
    var temperament: String            // Dog breed temperament
}

/*
 {
     "id": 1,
     "name": "Basset Hound",
     "description": "The Basset Hound is a short-legged breed of dog in the hound family. The Basset is a scent hound that was originally bred for the purpose of hunting hare. Their sense of smell and ability to ground-scent is second only to the Bloodhound. Basset Hounds are one of six recognized basset-type breeds in France.",
     "facePhotoFilename": "BassetHoundFace",
     "fullPhotoFilename": "BassetHound",
     "websiteUrl": "https://www.akc.org/dog-breeds/basset-hound/",
     "lifeExpectancy": "10-12 years",
     "origin": "France, Great Britain",
     "weight": "Female: 44–60 lbs (20–27 kg), Male: 51–64 lbs (23–29 kg)",
     "height": "Female: 11–14 inches (28–36 cm), Male: 12–15 inches (30–38 cm)",
     "colors": "Any recognized hound color",
     "temperament": "Tenacious, Devoted, Affectionate, Sweet-Tempered, Friendly, Gentle"
 }
 */
