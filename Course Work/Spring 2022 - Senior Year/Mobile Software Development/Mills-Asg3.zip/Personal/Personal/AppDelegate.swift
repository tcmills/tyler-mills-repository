//
//  AppDelegate.swift
//  AppDelegate
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {

    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {

        // Read personal data file upon app launch
        readSurveysTakenDataFile()           // In PersonalData.swift
        readVideoDataFile()                  // In PersonalData.swift
        readDogBreedDataFile()               // In PersonalData.swift
        
        return true
    }

}
