//
//  SurveysList.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SurveysList: View {
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        NavigationView {
            List {
                ForEach(userData.surveysList) { aSurvey in
                    NavigationLink(destination: SurveyDetails(survey: aSurvey)) {
                        SurveyItem(survey: aSurvey)
                    }
                }
                .onDelete(perform: delete)
                .onMove(perform: move)
                
            }   // End of List
                .navigationBarTitle(Text("Health Surveys Taken"), displayMode: .inline)
                // Place the Edit button on left and Add (+) button on right of the navigation bar
                .navigationBarItems(leading: EditButton(), trailing:
                    NavigationLink(destination: AddSurvey()) {
                        Image(systemName: "plus")
                })
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle.swift
    }
    
    /*
     ----------------------------
     MARK: Delete Selected Survey
     ----------------------------
     */
    func delete(at offsets: IndexSet) {
        /*
         'offsets.first' is an unsafe pointer to the index number of the array element
         to be deleted. It is nil if the array is empty. Process it as an optional.
         */
        if let index = offsets.first {
            // Remove the selected survey from the list
            userData.surveysList.remove(at: index)
        }
        // Set the global variable point to the changed list
        surveysTakenStructList = userData.surveysList
        
        // Set global flag defined in PersonalData
        dataChanged = true
    }
    
    /*
     --------------------------
     MARK: Move Selected Survey
     --------------------------
     */
    func move(from source: IndexSet, to destination: Int) {
        
        userData.surveysList.move(fromOffsets: source, toOffset: destination)
        
        // Set the global variable point to the changed list
        surveysTakenStructList = userData.surveysList
        
        // Set global flag defined in PersonalData
        dataChanged = true
    }
}

struct SurveysList_Previews: PreviewProvider {
    static var previews: some View {
        SurveysList()
    }
}
