//
//  AddSurvey.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct AddSurvey: View {
    /*
     Display this view as a Modal View and enable it to dismiss itself
     to go back to the previous view in the navigation hierarchy.
     */
    @Environment(\.presentationMode) var presentationMode
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    @State private var selectedIndex1 = 0
    @State private var selectedIndex2 = 0
    @State private var selectedIndex3 = 0
    @State private var selectedIndex4 = 0
    @State private var selectedIndex5 = 0
    @State private var selectedIndex6 = 0
    @State private var sliderValue7 = 0.0
    @State private var selectedIndex8 = 0
    @State private var selectedIndex9 = 0
    @State private var sliderValue10 = 1.0
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    // Array of question answer choices
    var choicesForAnswer1 = ["Never", "1 time per week", "2-3 times per week", "4-6 times per week", "1 time per day", "2 times per day", "3+ times per day"]
    var choicesForAnswer2 = ["I quit", "I smoke e-cigarettes", "No", "Yes"]
    var choicesForAnswer3 = ["Never", "1 time per week", "2-3 times per week", "4-6 times per week", "1 time per day", "2 times per day", "3+ times per day"]
    var choicesForAnswer4 = ["Chips, crackers, nuts", "Fast foods (e.g. pizza, fries)", "Fruits, vegetables", "Ice cream, chocolate, cookies, candy", "Protein bar, fruit and nut bar, energy bar", "Other"]
    var choicesForAnswer5 = ["Juice Box", "Milk", "Regular soda or other sugared beverages", "Tea", "Water"]
    var choicesForAnswer6 = ["Never", "1 time per week", "2-3 times per week", "4-6 times per week", "1 time per day", "2 times per day", "3+ times per day"]
    var choicesForAnswer8 = ["Aerobics", "Cycling", "Gym Workouts", "Gymnastics", "Hiking", "Pilates", "Racquetball", "Running", "Swimming", "Team Sport", "Walking", "Other"]
    var choicesForAnswer9 = ["No stress", "Mild stress", "Moderate stress", "Severe stress"]
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
            Section {
                HStack {
                    Spacer()
                    Button(action: {
                        selectedIndex1 = 0
                        selectedIndex2 = 0
                        selectedIndex3 = 0
                        selectedIndex4 = 0
                        selectedIndex5 = 0
                        selectedIndex6 = 0
                        sliderValue7 = 0.0
                        selectedIndex8 = 0
                        selectedIndex9 = 0
                        sliderValue10 = 1.0
                    }) {
                        Text("Reset Health Survey")
                    }
                    Spacer()
                }
            }
            Group {
                Section(header: Text("How often do you consume fast food?")) {
                    HStack {
                        Image("photoQ1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex1) {
                            ForEach(0 ..< choicesForAnswer1.count, id: \.self) {
                                Text(self.choicesForAnswer1[$0])
                            }
                        }
                    }
                }
                Section(header: Text("Do you smoke?")) {
                    HStack {
                        Image("photoQ2")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex2) {
                            ForEach(0 ..< choicesForAnswer2.count, id: \.self) {
                                Text(self.choicesForAnswer2[$0])
                            }
                        }
                    }
                }
                Section(header: Text("How often do you consume alcohol?")) {
                    HStack {
                        Image("photoQ3")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex3) {
                            ForEach(0 ..< choicesForAnswer3.count, id: \.self) {
                                Text(self.choicesForAnswer3[$0])
                            }
                        }
                    }
                }
                Section(header: Text("What types of food do you usually snack on?")) {
                    HStack {
                        Image("photoQ4")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex4) {
                            ForEach(0 ..< choicesForAnswer4.count, id: \.self) {
                                Text(self.choicesForAnswer4[$0])
                            }
                        }
                    }
                }
                Section(header: Text("When you are thirsty, which of the following do you typically choose?")) {
                    HStack {
                        Image("photoQ5")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex5) {
                            ForEach(0 ..< choicesForAnswer5.count, id: \.self) {
                                Text(self.choicesForAnswer5[$0])
                            }
                        }
                    }
                }
                Section(header: Text("How often do you microwave your food?")) {
                    HStack {
                        Image("photoQ6")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex6) {
                            ForEach(0 ..< choicesForAnswer6.count, id: \.self) {
                                Text(self.choicesForAnswer6[$0])
                            }
                        }
                    }
                }
                Section(header: Text("How many times do you exercise per week on average?")) {
                    HStack {
                        Image("photoQ7")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        VStack {
                            HStack {
                                Text("0")
                                Slider(value: $sliderValue7, in: 0.0...7.0, step: 1.0)
                                Text("7")
                            }   // End of HStack
                                .padding(.horizontal)
                                       
                            Text(String(Int(sliderValue7)))
                        }
                    }
                }
                Section(header: Text("What do you most often do to exercise?")) {
                    HStack {
                        Image("photoQ8")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex8) {
                            ForEach(0 ..< choicesForAnswer8.count, id: \.self) {
                                Text(self.choicesForAnswer8[$0])
                            }
                        }
                    }
                }
                Section(header: Text("What is your stress level?")) {
                    HStack {
                        Image("photoQ9")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        Picker("Answer:", selection: $selectedIndex9) {
                            ForEach(0 ..< choicesForAnswer9.count, id: \.self) {
                                Text(self.choicesForAnswer9[$0])
                            }
                        }
                    }
                }
                Section(header: Text("How many hours of sleep do you get each night on average?")) {
                    HStack {
                        Image("photoQ10")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                        
                        VStack {
                            HStack {
                                Text("1")
                                Slider(value: $sliderValue10, in: 1.0...10.0, step: 1.0)
                                Text("10")
                            }   // End of HStack
                                .padding(.horizontal)
                                       
                            Text(String(Int(sliderValue10)))
                        }
                    }
                }
            }   // End of Group
        }   // End of Form
        .font(.system(size: 14))
        .navigationBarTitle(Text("Take Survey"), displayMode: .inline)
        // Use single column navigation view for iPhone and iPad
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarItems(trailing:
            Button(action: {
                saveNewSurvey()
                    
                showAlertMessage = true
                alertTitle = "Survey Saved!"
                alertMessage = "Congratulations! Your survey is successfully saved!"
            }) {
                Text("Save")
        })
        .alert(alertTitle, isPresented: $showAlertMessage, actions: {
              Button("OK") {
                  if alertTitle == "Survey Saved!" {
                      // Dismiss this Modal View and go back to the previous view in the navigation hierarchy
                      presentationMode.wrappedValue.dismiss()
                  }
              }
            }, message: {
              Text(alertMessage)
            })
        
    }   // End of body var
    
    /*
    ------------------------------------
    MARK: Save New Survey to Survey List
    ------------------------------------
    */
    func saveNewSurvey() {
        
        let newSurvey = saveSurvey()
        
        // Append the new survey to surveysList
        userData.surveysList.append(newSurvey)
        
        // Set the global variable point to the changed list
        surveysTakenStructList = userData.surveysList
        
        // Set global flag defined in PersonalData
        dataChanged = true
        
        // Initialize @State variables
        selectedIndex1 = 0
        selectedIndex2 = 0
        selectedIndex3 = 0
        selectedIndex4 = 0
        selectedIndex5 = 0
        selectedIndex6 = 0
        sliderValue7 = 0.0
        selectedIndex8 = 0
        selectedIndex9 = 0
        sliderValue10 = 1.0
    }
    
    /*
    ---------------------------------------
    MARK: Save Survey to Document Directory
    ---------------------------------------
    */
    public func saveSurvey() -> SurveysTaken {

        //------------------
        // Generate a new id
        //------------------
        let newSurveyId = UUID()
     
        //-----------------------------
        // Obtain Current Date and Time
        //-----------------------------
        let date = Date()
        
        // Instantiate a DateFormatter object
        let dateFormatter = DateFormatter()

        // Set the date format to yyyy-MM-dd at HH:mm:ss
        dateFormatter.dateFormat = "yyyy-MM-dd' at 'HH:mm:ss"
        
        // Format current date and time as above and convert it to String
        let currentDateTime = dateFormatter.string(from: date)
        
        let newSurveysTaken = SurveysTaken(id: newSurveyId,
                                         dateTime: currentDateTime,
                                         answerToQuestion1: choicesForAnswer1[selectedIndex1],
                                         answerToQuestion2: choicesForAnswer2[selectedIndex2],
                                         answerToQuestion3: choicesForAnswer3[selectedIndex3],
                                         answerToQuestion4: choicesForAnswer4[selectedIndex4],
                                         answerToQuestion5: choicesForAnswer5[selectedIndex5],
                                         answerToQuestion6: choicesForAnswer6[selectedIndex6],
                                         answerToQuestion7: Int(sliderValue7),
                                         answerToQuestion8: choicesForAnswer8[selectedIndex8],
                                         answerToQuestion9: choicesForAnswer9[selectedIndex9],
                                         answerToQuestion10: Int(sliderValue10))
        
        return newSurveysTaken
        
    }   // End of func saveSurvey
    
}   // End of struct

struct AddSurvey_Previews: PreviewProvider {
    static var previews: some View {
        AddSurvey()
    }
}
