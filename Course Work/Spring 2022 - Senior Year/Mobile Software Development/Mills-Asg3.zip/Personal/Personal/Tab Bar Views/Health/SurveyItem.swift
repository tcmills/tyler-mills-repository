//
//  SurveyItem.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SurveyItem: View {
    
    // Input Parameter
    let survey: SurveysTaken
    
    var body: some View {
        HStack {
            Image("SurveyIcon")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 50)
            
            VStack(alignment: .leading) {
                Text("Survey Taken on")
                Text(survey.dateTime)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
}

struct SurveyItem_Previews: PreviewProvider {
    static var previews: some View {
        SurveyItem(survey: surveysTakenStructList[0])
    }
}
