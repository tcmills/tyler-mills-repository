//
//  SurveyDetails.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SurveyDetails: View {
    
    // Input Parameter
    let survey: SurveysTaken
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
            Section(header: Text("Survey Taken On")) {
                Text(survey.dateTime)
            }
            Group {
                Section(header: Text("How often do you consume fast food?")) {
                    HStack {
                        Image("photoQ1")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion1)
                    }
                }
                Section(header: Text("Do you smoke?")) {
                    HStack {
                        Image("photoQ2")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion2)
                    }
                }
                Section(header: Text("How often do you consume alcohol?")) {
                    HStack {
                        Image("photoQ3")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion3)
                    }
                }
                Section(header: Text("What types of food do you usually snack on?")) {
                    HStack {
                        Image("photoQ4")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion4)
                    }
                }
                Section(header: Text("When you are thirsty, which of the following do you typically choose?")) {
                    HStack {
                        Image("photoQ5")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion5)
                    }
                }
                Section(header: Text("How often do you microwave your food?")) {
                    HStack {
                        Image("photoQ6")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion6)
                    }
                }
                Section(header: Text("How many times do you exercise per week on average?")) {
                    HStack {
                        Image("photoQ7")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(String(survey.answerToQuestion7))
                    }
                }
                Section(header: Text("What do you most often do to exercise?")) {
                    HStack {
                        Image("photoQ8")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion8)
                    }
                }
                Section(header: Text("What is your stress level?")) {
                    HStack {
                        Image("photoQ9")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text(survey.answerToQuestion9)
                    }
                }
                Section(header: Text("How many hours of sleep do you get each night on average?")) {
                    HStack {
                        Image("photoQ10")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 100)
                    
                        Text("\(String(survey.answerToQuestion10)) hours")
                    }
                }
            }   // End of Group
        }   // End of Form
        .navigationBarTitle(Text("Health Survey Taken Details"), displayMode: .inline)
        .font(.system(size: 14))
    }

}

struct SurveyDetails_Previews: PreviewProvider {
    static var previews: some View {
        SurveyDetails(survey: surveysTakenStructList[0])
    }
}
