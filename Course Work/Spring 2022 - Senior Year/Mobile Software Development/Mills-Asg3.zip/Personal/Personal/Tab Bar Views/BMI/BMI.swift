//
//  BMI.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct BMI: View {
    
    @State private var sliderValueHeightFeet = 5.0
    @State private var sliderValueHeightInches = 6.0
    @State private var sliderValueWeight = 100.0
    
    var body: some View {
        NavigationView {
            Form {
                Section(header: Text("Select Your Height In Feet")) {
                    VStack {
                        HStack {
                            Text("3 ft")
                            Slider(value: $sliderValueHeightFeet, in: 3.0...9.0, step: 1.0)
                            Text("9ft")
                        }   // End of HStack
                            .padding(.horizontal)
                                   
                        Text(String(sliderValueHeightFeet))
                    }
                }
                Section(header: Text("Select Your Height In Inches")) {
                    VStack {
                        HStack {
                            Text("0 in")
                            Slider(value: $sliderValueHeightInches, in: 0.0...11.0, step: 1.0)
                            Text("11 in")
                        }   // End of HStack
                            .padding(.horizontal)
                                   
                        Text(String(sliderValueHeightInches))
                    }
                }
                Section(header: Text("Select Your Weight In Pounds")) {
                    VStack {
                        HStack {
                            Text("50 lbs")
                            Slider(value: $sliderValueWeight, in: 50.0...400.0, step: 1.0)
                            Text("400 lbs")
                        }   // End of HStack
                            .padding(.horizontal)
                                   
                        Text(String(sliderValueWeight))
                    }
                }
                Section(header: Text("Compute Body Mass Index")) {
                    NavigationLink(destination: showBMIResults) {
                        HStack {
                            Image(systemName: "gear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                                .foregroundColor(.blue)
                            Text("Compute BMI")
                                .font(.system(size: 16))
                        }
                    }
                    .frame(minWidth: 300, maxWidth: 500)
                }
                Section(header: Text("Reset Values")) {
                    HStack {
                        Button(action: {
                            sliderValueHeightFeet = 5.0
                            sliderValueHeightInches = 6.0
                            sliderValueWeight = 100.0
                        }) {
                            Text("Reset")
                        }
                        .frame(width: 120, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                }
                
            }   // End of Form
                .navigationBarTitle(Text("BMI Calculator"), displayMode: .inline)
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body var
    
    /*
     ----------------------
     MARK: Show BMI Results
     ----------------------
     */
    var showBMIResults: VStack<TupleView<(Image, Text)>> {
        
        let totalInches = (sliderValueHeightFeet*12) + sliderValueHeightInches
        
        let BMI = (sliderValueWeight*703)/(totalInches*totalInches)
        
        if (BMI < 18.5) {
            return VStack {
                Image("underweight")
                Text("You are Underweight")
            }
        }
        else if (BMI >= 18.5 && BMI < 25) {
            return VStack {
                Image("normal")
                Text("You are Normal Weight")
            }
        }
        else if (BMI >= 25 && BMI < 30) {
            return VStack {
                Image("overweight")
                Text("You are Overweight")
            }
        }
        else if (BMI >= 30 && BMI < 35) {
            return VStack {
                Image("obese")
                Text("You are Obese")
            }
        }
        else if (BMI >= 35) {
            return VStack {
                Image("extremelyObese")
                Text("You are Extremely Obese")
            }
        }
        else {
            return VStack {
                Image("ImageUnavailable")
                Text("The Image is Unavailable")
            }
        }
    }
}

struct BMI_Previews: PreviewProvider {
    static var previews: some View {
        BMI()
    }
}
