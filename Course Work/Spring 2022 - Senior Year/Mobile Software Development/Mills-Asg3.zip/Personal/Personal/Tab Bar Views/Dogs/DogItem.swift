//
//  DogItem.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2021 Tyler Mills. All rights reserved.
//

import SwiftUI

struct DogItem: View {
    
    // Input Parameter
    let dog: DogBreed
    
    var body: some View {
        HStack {
            Image(dog.facePhotoFilename)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 75.0)
            
            VStack(alignment: .leading) {
                Text(dog.name)
                Text(dog.lifeExpectancy)
                Text(dog.origin)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
}

struct DogItem_Previews: PreviewProvider {
    static var previews: some View {
        DogItem(dog: dogBreedStructList[0])
    }
}
