//
//  DogsList.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2021 Tyler Mills. All rights reserved.
//

import SwiftUI

struct DogsList: View {
    
    var body: some View {
        NavigationView {
            List {
                // dogBreedStructList is a global array of Dog structs given in PersonalData.swift
                ForEach(dogBreedStructList) { aDog in
                    NavigationLink(destination: DogDetails(dog: aDog)) {
                        DogItem(dog: aDog)
                    }
                }
            }   // End of List
            .navigationBarTitle(Text("List of Dog Breeds"), displayMode: .inline)
            
        }   // End of NavigationView
        .customNavigationViewStyle()      // Given in NavigationStyle.swift
        
    }   // End of body

}

struct DogsList_Previews: PreviewProvider {
    static var previews: some View {
        DogsList()
    }
}
