//
//  DogDetails.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2021 Tyler Mills. All rights reserved.
//

import SwiftUI

struct DogDetails: View {
    
    // Input Parameter
    let dog: DogBreed
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
                Section(header: Text("Dog Breed Face Photo")) {
                    HStack {
                        Spacer()
                        Image(dog.facePhotoFilename)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 150)
                        Spacer()
                    }
                }
                Section(header: Text("Dog Breed Full Body Photo")) {
                    HStack {
                        Spacer()
                        Image(dog.fullPhotoFilename)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                        Spacer()
                    }
                }
            Group {
                Section(header: Text("Dog Breed Name")) {
                    Text(dog.name)
                }
                Section(header: Text("Dog Breed Description")) {
                    Text(dog.description)
                }
                Section(header: Text("Dog Breed Website")) {
                    Link(destination: URL(string: dog.websiteUrl)!) {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Dog Breed Website")
                                .font(.system(size: 16))
                                .italic()
                        }
                        .foregroundColor(.blue)
                    }
                }
                Section(header: Text("Dog Breed Life Expectancy")) {
                    Text(dog.lifeExpectancy)
                }
                Section(header: Text("Dog Breed Origin")) {
                    Text(dog.origin)
                }
                Section(header: Text("Dog Breed Weight")) {
                    Text(dog.weight)
                }
                Section(header: Text("Dog Breed Height")) {
                    Text(dog.height)
                }
                Section(header: Text("Dog Breed Colors")) {
                    Text(dog.colors)
                }
                Section(header: Text("Dog Breed Temperament")) {
                    Text(dog.temperament)
                }
            }   // End of Group
            
        }   // End of Form
        .navigationBarTitle(Text("Dog Breed Details"), displayMode: .inline)
        .font(.system(size: 14))    // Set font and size for all Text views in the Form
        
    }   // End of body
    
}

struct DogDetails_Previews: PreviewProvider {
    static var previews: some View {
        DogDetails(dog: dogBreedStructList[0])
    }
}
