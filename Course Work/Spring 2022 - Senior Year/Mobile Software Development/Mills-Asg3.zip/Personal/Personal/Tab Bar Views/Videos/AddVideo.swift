//
//  AddVideo.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct AddVideo: View {
    /*
     Display this view as a Modal View and enable it to dismiss itself
     to go back to the previous view in the navigation hierarchy.
     */
    @Environment(\.presentationMode) var presentationMode
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    @State private var youTubeVideoIdTextFieldValue = ""
    @State private var videoTitleTextFieldValue = ""
    @State private var videoDescriptionTextEditorValue = ""
    @State private var videoDurationTimeTextFieldValue = ""
    @State private var videoReleaseDate = Date()
    @State private var youTubeCategorySelectedIndex = 0
    
    var dateFormatter: DateFormatter {
        let formatter = DateFormatter()
        formatter.dateStyle = .long     // e.g., August 14, 2020
        return formatter
    }
       
    var dateClosedRange: ClosedRange<Date> {
        // Set minimum date to 40 years earlier than the current year
        let minDate = Calendar.current.date(byAdding: .year, value: -40, to: Date())!
           
        // Set maximum date to 10 years later than the current year
        let maxDate = Calendar.current.date(byAdding: .year, value: 10, to: Date())!
        return minDate...maxDate
    }
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    // Array of youtube video categories
    let youTubeCategories = ["Autos & Vehicles", "Comedy", "Education", "Entertainment", "Film & Animation", "Gaming", "Howto & Style", "Music", "News & Politics", "Nonprofits & Activism", "People & Blogs", "Pets & Animals", "Science & Technology", "Sports", "Travel & Events"]
    
    var body: some View {
        Form {
            Section(header: Text("YouTube Video Id"), footer: Text("YouTube provides video IDs uniquely")) {
                TextField("Enter Video ID", text: $youTubeVideoIdTextFieldValue)
                    .disableAutocorrection(true)
            }
            Section(header: Text("Video Title")) {
                TextField("Enter Video Title", text: $videoTitleTextFieldValue)
                    .disableAutocorrection(true)
                    .autocapitalization(.words)
            }
            Section(header: Text("Video Description"), footer:
                Button(action: {
                    self.dismissKeyboard()
                }) {
                    Image(systemName: "keyboard")
                        .font(Font.title.weight(.light))
                        .foregroundColor(.blue)
                }
            ) {
                TextEditor(text: $videoDescriptionTextEditorValue)
                    .frame(height: 100)
                    .font(.custom("Helvetica", size: 14))
                    .foregroundColor(.primary)
                    .lineSpacing(2)
                    .multilineTextAlignment(.leading)
            }
            Section(header: Text("Video Duration Time")) {
                TextField("Enter time as hh:mm:ss", text: $videoDurationTimeTextFieldValue)
                    .disableAutocorrection(true)
            }
            Section(header: Text("Video Release Date")) {
                DatePicker(
                    "Release Date",
                    selection: $videoReleaseDate,
                    in: dateClosedRange,
                    displayedComponents: .date    // Sets DatePicker to pick a date
                )
            }
            Section(header: Text("Video YouTube Category")) {
                Picker("Category", selection: $youTubeCategorySelectedIndex) {
                    ForEach(0 ..< youTubeCategories.count, id: \.self) {
                        Text(self.youTubeCategories[$0])
                    }
                }
            }
        }   // End of Form
        .font(.system(size: 14))
        .navigationBarTitle(Text("Add Video"), displayMode: .inline)
        // Use single column navigation view for iPhone and iPad
        .navigationViewStyle(StackNavigationViewStyle())
        .navigationBarItems(trailing:
            Button(action: {
                if inputDataValidated() {
                    saveNewVideo()
                    
                    showAlertMessage = true
                    alertTitle = "Youtube Video Added!"
                    alertMessage = "The new YouTube video is successfully added!"
                } else {
                    showAlertMessage = true
                    alertTitle = "Missing Input Data!"
                    alertMessage = "YouTube ID, Title, Description, and Duration Time are required. Release Date and Category defaults are used if not selected."
                }
            }) {
                Text("Save")
        })
        .alert(alertTitle, isPresented: $showAlertMessage, actions: {
              Button("OK") {
                  if alertTitle == "Youtube Video Added!" {
                      // Dismiss this Modal View and go back to the previous view in the navigation hierarchy
                      presentationMode.wrappedValue.dismiss()
                  }
              }
            }, message: {
              Text(alertMessage)
            })
        
    }   // End of body var
    
    /*
     ---------------------------------
     MARK: Dismiss TextEditor Keyboard
     ---------------------------------
     */
    func dismissKeyboard() {
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let videoId = youTubeVideoIdTextFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let videoTitle = videoTitleTextFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let videoDescription = videoDescriptionTextEditorValue.trimmingCharacters(in: .whitespacesAndNewlines)
        let videoDuration = videoDurationTimeTextFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // YouTube ID, Title, Description, and Duration Time are required.
        // Release Date and Category defaults are used if not selected.
        if videoId.isEmpty {
            return false
        }
        if videoTitle.isEmpty {
            return false
        }
        if videoDescription.isEmpty {
            return false
        }
        if videoDuration.isEmpty {
            return false
        }
        return true
    }
    
    /*
    --------------------
    MARK: Save New Video
    --------------------
    */
    func saveNewVideo() {
        
        let newSavedVideo = saveVideo()
        
        // Append the new video to videosList
        userData.videosList.append(newSavedVideo)
        
        // Set the global variable point to the changed list
        videoStructList = userData.videosList
        
        // Set global flag defined in PersonalData
        dataChanged = true
        
        // Initialize @State variables
        youTubeVideoIdTextFieldValue = ""
        videoTitleTextFieldValue = ""
        videoDescriptionTextEditorValue = ""
        videoDurationTimeTextFieldValue = ""
        videoReleaseDate = Date()
        youTubeCategorySelectedIndex = 0
    }
    
    /*
    --------------------------------------
    MARK: Save Video to Document Directory
    --------------------------------------
    */
    public func saveVideo() -> Video {

        //------------------
        // Generate a new id
        //------------------
        let newVideoId = UUID()
        
        // Instantiate a DateFormatter object
        let dateFormatter = DateFormatter()

        // Set the date format to yyyy-MM-dd
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        // Format release date as above and convert it to String
        let formattedReleaseDate = dateFormatter.string(from: videoReleaseDate)
        
        let newVideo = Video(id: newVideoId,
                             youTubeId: youTubeVideoIdTextFieldValue,
                             title: videoTitleTextFieldValue,
                             description: videoDescriptionTextEditorValue,
                             durationTime: videoDurationTimeTextFieldValue,
                             releaseDate: formattedReleaseDate,
                             youTubeCategory: youTubeCategories[youTubeCategorySelectedIndex])
        
        return newVideo
        
    }   // End of func saveVideo
    
}   // End of struct

struct AddVideo_Previews: PreviewProvider {
    static var previews: some View {
        AddVideo()
    }
}
