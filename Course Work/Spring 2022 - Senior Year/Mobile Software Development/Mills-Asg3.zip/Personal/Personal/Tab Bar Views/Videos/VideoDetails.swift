//
//  VideoDetails.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct VideoDetails: View {
    
    // Input Parameter
    let video: Video
    
    var body: some View {
        Form {
            Section(header: Text("Video Title")) {
                Text(video.title)
            }
            Section(header: Text("Video Thumbnail Image"), footer: Text(video.youTubeId)) {
                // This public function is given in UtilityFunctions.swift
                getImageFromUrl(url: "https://img.youtube.com/vi/\(video.youTubeId)/mqdefault.jpg", defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
            }
            Section(header: Text("Play Video")) {
                NavigationLink(destination: WebView(url: "http://www.youtube.com/embed/\(video.youTubeId)")
                    .navigationBarTitle(Text("Play Video"), displayMode: .inline) )
                {
                    Image(systemName: "play.rectangle.fill")
                        .foregroundColor(.red)
                        .font(Font.title.weight(.regular))
                }
                .navigationBarTitle(Text(video.youTubeId), displayMode: .inline)
            }
            Section(header: Text("Video Description")) {
                Text(video.description)
            }
            Section(header: Text("Video Duration Time")) {
                Text(video.durationTime)
            }
            Section(header: Text("Video Release Date")) {
                Text(video.releaseDate)
            }
            Section(header: Text("Video YouTube Category")) {
                Text(video.youTubeCategory)
            }
        }   // End of Form
        .navigationBarTitle(Text(video.youTubeId), displayMode: .inline)
        .font(.system(size: 14))
    }

}

struct VideoDetails_Previews: PreviewProvider {
    static var previews: some View {
        VideoDetails(video: videoStructList[0])
    }
}
