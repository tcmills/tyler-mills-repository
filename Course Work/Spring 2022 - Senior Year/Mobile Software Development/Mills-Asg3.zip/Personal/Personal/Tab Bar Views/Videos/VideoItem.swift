//
//  VideoItem.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct VideoItem: View {
    
    // Input Parameter
    let video: Video
    
    var body: some View {
        HStack {
            // This public function is given in UtilityFunctions.swift
            getImageFromUrl(url: "https://img.youtube.com/vi/\(video.youTubeId)/mqdefault.jpg", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 75)
            
            VStack(alignment: .leading) {
                Text(video.title)
                Text(video.youTubeCategory)
                Text(video.releaseDate)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
}

struct VideoItem_Previews: PreviewProvider {
    static var previews: some View {
        VideoItem(video: videoStructList[0])
    }
}
