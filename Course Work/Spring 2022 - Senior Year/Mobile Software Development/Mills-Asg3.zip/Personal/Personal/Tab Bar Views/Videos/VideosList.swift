//
//  VideoList.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/21/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct VideosList: View {
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    var body: some View {
        NavigationView {
            List {
                ForEach(userData.videosList) { aVideo in
                    NavigationLink(destination: VideoDetails(video: aVideo)) {
                        VideoItem(video: aVideo)
                    }
                }
                .onDelete(perform: delete)
                .onMove(perform: move)
                
            }   // End of List
                .navigationBarTitle(Text("Videos I Like"), displayMode: .inline)
                // Place the Edit button on left and Add (+) button on right of the navigation bar
                .navigationBarItems(leading: EditButton(), trailing:
                    NavigationLink(destination: AddVideo()) {
                        Image(systemName: "plus")
                })
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle.swift
    }
    
    /*
     ---------------------------
     MARK: Delete Selected Video
     ---------------------------
     */
    func delete(at offsets: IndexSet) {
        /*
         'offsets.first' is an unsafe pointer to the index number of the array element
         to be deleted. It is nil if the array is empty. Process it as an optional.
         */
        if let index = offsets.first {
            // Remove the selected video from the list
            userData.videosList.remove(at: index)
        }
        // Set the global variable point to the changed list
        videoStructList = userData.videosList
        
        // Set global flag defined in PersonalData
        dataChanged = true
    }
    
    /*
     -------------------------
     MARK: Move Selected Video
     -------------------------
     */
    func move(from source: IndexSet, to destination: Int) {
        
        userData.videosList.move(fromOffsets: source, toOffset: destination)
        
        // Set the global variable point to the changed list
        videoStructList = userData.videosList
        
        // Set global flag defined in PersonalData
        dataChanged = true
    }
}

struct VideosList_Previews: PreviewProvider {
    static var previews: some View {
        VideosList()
    }
}
