/*
**********************************************************
*   Statement of Compliance with the Stated Honor Code   *
**********************************************************
I hereby declare on my honor and I affirm that
 
 (1) I have not given or received any unauthorized help on this assignment, and
 (2) All work is my own in this assignment.
 
I am hereby writing my name as my signature to declare that the above statements are true:
   
      Tyler Christian Mills
 
**********************************************************
 */

//
//  PersonalApp.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

@main
struct PersonalApp: App {
    // App is a protocol that represents the structure and behavior of an app.
    
    /*
     Use the UIApplicationDelegateAdaptor property wrapper to direct SwiftUI
     to use the AppDelegate class for the application delegate.
     */
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate
    
    /*
     @Environment property wrapper for SwiftUI's pre-defined key scenePhase is declared to
     monitor changes of app's life cycle states such as active, inactive, or background.
     The \. indicates that we access scenePhase by its object reference, not by its value.
     */
    @Environment(\.scenePhase) private var scenePhase
    
    var body: some Scene {
        WindowGroup {
            // ContentView is the root view to be shown first upon app launch
            ContentView()
                /*
                 Inject an instance of UserData() class into the environment and make it available to
                 every View subscribing to it by declaring '@EnvironmentObject var userData: UserData'
                 */
                .environmentObject(UserData())
        }
        .onChange(of: scenePhase) { _ in
            /*
             Save data changes if any whenever app life cycle state changes.
             Global flag 'dataChanged' is defined in PersonalData.
             */
            if dataChanged {
                writePersonalDataFile()  // Given in PersonalData
            }
        }
    }
}
