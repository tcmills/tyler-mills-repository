//
//  MainView.swift
//  Personal
//
//  Created by Tyler Mills and Osman Balci on 3/20/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            SurveysList()
                .tabItem {
                    Image(systemName: "bolt.heart")
                    Text("Health")
                }
            BMI()
                .tabItem {
                    Image(systemName: "keyboard")
                    Text("BMI")
                }
            VideosList()
                .tabItem {
                    Image(systemName: "video")
                    Text("Videos")
                }
            DogsList()
                .tabItem {
                    Image(systemName: "list.bullet.rectangle")
                    Text("Dogs")
                }
            Settings()
                .tabItem {
                    Image(systemName: "gear")
                    Text("Settings")
                }
            
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
