//
//  ContentView.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house.fill")
                    Text("Home")
                }
            FavoritesList()
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Favorites")
                }
            PhotosGrid()
                .tabItem {
                    Image(systemName: "square.grid.3x3.fill")
                    Text("Photos Grid")
                }
            SlideShow()
                .tabItem {
                    Image(systemName: "photo.on.rectangle")
                    Text("Slide Show")
                }
                .onAppear() {
                    UIPageControl.appearance().currentPageIndicatorTintColor = .black
                    UIPageControl.appearance().pageIndicatorTintColor = .gray
                }
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
