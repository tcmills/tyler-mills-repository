//
//  PhotosGrid.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

fileprivate var selectedFlower = flowerStructList[0]

struct PhotosGrid: View {
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    @State private var showFlowerInfoAlert = false
    
    // Fit as many images per row as possible with minimum image width of 100 points each.
    // spacing defines spacing between columns
    let columns = [ GridItem(.adaptive(minimum: 100), spacing: 3) ]
    
    var body: some View {
        ScrollView {
            // spacing defines spacing between rows
            LazyVGrid(columns: columns, spacing: 3) {
                // 🔴 Specifying id: \.self is critically important to prevent photos being listed as out of order
                ForEach(userData.flowersList, id: \.self) { flower in
                    
                    Image(flower.photoFilename)
                        .resizable()
                        .scaledToFit()
                        .onTapGesture {
                            selectedFlower = flower
                            showFlowerInfoAlert = true
                        }
                }
            }   // End of LazyVGrid
                .padding()
            
        }   // End of ScrollView
            .alert(isPresented: $showFlowerInfoAlert, content: { flowerInfoAlert })
    }
    
    var flowerInfoAlert: Alert {
        Alert(title: Text(selectedFlower.name),
              message: Text("Meaning: \(selectedFlower.meaning)"),
              dismissButton: .default(Text("OK")) )
    }
    
}   // End of PhotosGrid struct

struct PhotosGrid_Previews: PreviewProvider {
    static var previews: some View {
        PhotosGrid()
    }
}
