//
//  FavoriteDetails.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct FavoriteDetails: View {
    
    // Input Parameter
    let flower: Flower
    
    var body: some View {
        // A Form cannot have more than 10 Sections.
        // Group the Sections if more than 10.
        Form {
            Group {
                Section(header: Text("Flower Name")) {
                    Text(flower.name)
                }
                Section(header: Text("Flower Photo")) {
                    Image(flower.photoFilename)
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(minWidth: 300, maxWidth: 320, alignment: .center)
                }
                Section(header: Text("Flower Meaning")) {
                    Text(flower.meaning)
                }
                Section(header: Text("Flower Website")) {
                    Link(destination: URL(string: flower.websiteUrl)!) {
                        HStack {
                            Image(systemName: "globe")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                            Text("Show Website")
                                .font(.system(size: 16))
                        }
                        .foregroundColor(.blue)
                    }
                }
                Section(header: Text("Flower Description")) {
                    Text(flower.description)
                }
            }

        }   // End of Form
            .navigationBarTitle(Text("Flower Details"), displayMode: .inline)
            .font(.system(size: 14))
        
    }   // End of body
    
}

struct FavoriteDetails_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteDetails(flower: flowerStructList[0])
    }
}
