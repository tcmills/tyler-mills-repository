//
//  FavoriteItem.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct FavoriteItem: View {
    
    // Input Parameter
    let flower: Flower
    
    var body: some View {
        HStack {
            Image(flower.photoFilename)
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0)
            
            VStack(alignment: .leading) {
                Text(flower.name)
                Text(flower.meaning)
            }
            // Set font and size for the whole VStack content
            .font(.system(size: 14))
            
        }   // End of HStack
    }
    
}

struct FavoriteItem_Previews: PreviewProvider {
    static var previews: some View {
        FavoriteItem(flower: flowerStructList[0])
    }
}
