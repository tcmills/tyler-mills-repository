//
//  FavoritesList.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct FavoritesList: View {
    
    // Subscribe to changes in UserData
    @EnvironmentObject var userData: UserData
    
    @State private var searchItem = ""
    
    var body: some View {
        NavigationView {
            List {
                SearchBar(searchItem: $searchItem, placeholder: "Search Flowers")
                
                ForEach(userData.searchableOrderedFlowersList.filter {searchItem.isEmpty ? true : $0.localizedStandardContains(searchItem)}, id: \.self)
                { item in
                    NavigationLink(destination: FavoriteDetails(flower: searchItemFlower(searchListItem: item)))
                    {
                        FavoriteItem(flower: searchItemFlower(searchListItem: item))
                    }
                }
                .onDelete(perform: delete)
                .onMove(perform: move)
                
            }   // End of List
            .navigationBarTitle(Text("Favorites"), displayMode: .inline)
            
            // Place the Edit button on left of the navigation bar
            .navigationBarItems(leading: EditButton())
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle
    }
    
    func searchItemFlower(searchListItem: String) -> Flower {
        /*
         searchListItem = "name|meaning|description"
         flower name = searchListItem.components(separatedBy: "|")[0]
         */
        // Find the index number of flowersList matching the flower attribute 'id'
        let index = userData.flowersList.firstIndex(where: {"\($0.name)" == searchListItem.components(separatedBy: "|")[0]})!
        
        return userData.flowersList[index]
    }
    
    /*
     ----------------------------
     MARK: Delete Selected Flower
     ----------------------------
     */
    func delete(at offsets: IndexSet) {
        /*
        'offsets.first' is an unsafe pointer to the index number of the array element
        to be deleted. It is nil if the array is empty. Process it as an optional.
        */
        if let index = offsets.first {
            userData.flowersList.remove(at: index)
            userData.searchableOrderedFlowersList.remove(at: index)
        }
        // Set the global variable point to the changed list
        flowerStructList = userData.flowersList
        
        // Set the global variable point to the changed list
        orderedSearchableFlowersList = userData.searchableOrderedFlowersList
        
        // Set global flag defined in FlowersData
        dataChanged = true
    }
    
    /*
     --------------------------
     MARK: Move Selected Flower
     --------------------------
     */
    func move(from source: IndexSet, to destination: Int) {

        userData.flowersList.move(fromOffsets: source, toOffset: destination)
        userData.searchableOrderedFlowersList.move(fromOffsets: source, toOffset: destination)
        
        // Set the global variable point to the changed list
        flowerStructList = userData.flowersList
        
        // Set the global variable point to the changed list
        orderedSearchableFlowersList = userData.searchableOrderedFlowersList
        
        // Set global flag defined in FlowersData
        dataChanged = true
    }
}

struct FavoritesList_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesList()
    }
}
