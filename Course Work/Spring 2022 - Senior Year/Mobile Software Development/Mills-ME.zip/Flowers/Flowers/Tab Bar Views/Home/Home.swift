//
//  Home.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct Home: View {
    
    // Set initial Image
    @State private var image = getImageFromUrl(url: "https://picsum.photos/500/400", defaultFilename: "ImageUnavailable")
    
    // Set initial Quote
    @State private var quote = randomQuote      // randomQuote is created in QuoteApiData.swift
    
    var body: some View {
        ZStack {
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                Image("Welcome")
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                
                image
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
                    .padding()
                
                Button(action: {
                    // Update Image by getting a new random image from the url
                    image = getImageFromUrl(url: "https://picsum.photos/500/400", defaultFilename: "ImageUnavailable")
                }) {
                    Text("Show a Random Photo")
                        .frame(width: 230, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                }
                
                Text(quote)
                    .frame(width: 400)
                    .padding()
                
                Button(action: {
                    // Update Quote by generating a new quote with obtainQuoteFromApi()
                    // which is then stored in randomQuote
                    obtainQuoteFromApi()
                    quote = randomQuote
                }) {
                    Text("Show a Random Quote")
                        .frame(width: 230, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                }
                
            }   // End of VStack
        }   // End of ScrollView

        }   // End of ZStack
    }   // End of var
    
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}

