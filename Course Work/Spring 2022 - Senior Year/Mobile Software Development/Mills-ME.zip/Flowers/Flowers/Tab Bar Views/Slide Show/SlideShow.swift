//
//  SlideShow.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SlideShow: View {
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)    // Color the background to 10% gray
            TabView {
                // flowerStructList is a global array of Flower structs given in FlowersData.swift
                ForEach(flowerStructList) { flower in
                    VStack {
                        Link(destination: URL(string: flower.websiteUrl)!) {
                            Text(flower.name)
                                .font(.headline)
                                .multilineTextAlignment(.center)
                                .foregroundColor(.blue)
                                .padding()
                        }
                        Image(flower.photoFilename)
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                    }
                }
            }   // End of TabView
                .tabViewStyle(PageTabViewStyle())
                // .indexViewStyle(PageIndexViewStyle(backgroundDisplayMode: .always))
                // .tabViewStyle(PageTabViewStyle(indexDisplayMode: .never))
                .navigationBarTitle(Text("Flowers Slide Show"), displayMode: .inline)
                

            }   // End of ZStack
            
        }   // End of NavigationView
            // Use single column navigation view for iPhone and iPad
            .navigationViewStyle(StackNavigationViewStyle())
    }
    
}

struct SlideShow_Previews: PreviewProvider {
    static var previews: some View {
        SlideShow()
    }
}

