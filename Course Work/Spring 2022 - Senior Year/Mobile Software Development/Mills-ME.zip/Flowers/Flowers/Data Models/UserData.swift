//
//  UserData.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Combine
import SwiftUI

final class UserData: ObservableObject {

    /*
     ===============================================================================
                         Publisher-Subscriber Design Pattern
     ===============================================================================
     | Publisher:   @Published var under class conforming to ObservableObject      |
     | Subscriber:  Any View declaring '@EnvironmentObject var userData: UserData' |
     ===============================================================================
     
     By modifying the first View to be shown, ContentView(), with '.environmentObject(UserData())' in
     FlowersApp, we inject an instance of this UserData() class into the environment and make it
     available to every View subscribing to it by declaring '@EnvironmentObject var userData: UserData'.
     
     When a change occurs in userData (e.g., deleting a flower from the list, reordering flowers list),
     every View subscribed to it is notified to re-render its View.
     ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     NOTE:  Only Views can subscribe to it. You cannot subscribe to it within
            a non-View Swift file such as our FlowersData file.
     ++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
     */
    
    // Publish flowersList with initial value of flowerStructList obtained in FlowersData
    @Published var flowersList = flowerStructList
    
    /*
     Publish searchableOrderedFlowersList with initial value of
     orderedSearchableFlowersList obtained in FlowersData
     */
    @Published var searchableOrderedFlowersList = orderedSearchableFlowersList

}
