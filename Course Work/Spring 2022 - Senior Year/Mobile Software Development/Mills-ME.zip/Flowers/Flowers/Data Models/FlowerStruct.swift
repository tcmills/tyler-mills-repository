//
//  FlowerStruct.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct Flower: Hashable, Codable, Identifiable {
    
    var id: Int
    var name: String
    var meaning: String
    var photoFilename: String
    var websiteUrl: String
    var description: String
}

/*
 We create the Flower structure above to represent a country
 JSON object with exactly the same attribute names.
 {
     "id": 1,
     "name": "Alstroemeria",
     "meaning": "symbol of grace, purity, majesty and honor",
     "photoFilename": "Alstroemeria",
     "websiteUrl": "https://www.gardenia.net/plant-variety/alstroemeria-peruvian-lily",
     "description": "The alstroemeria, also called the Peruvian lily, features streaked or speckled blossoms in a range of colors, including white, yellow, orange, pink, and red. With their trumpet-like appearance, they resemble lilies and grow to one to three feet tall."
 }
*/
