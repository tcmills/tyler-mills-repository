//
//  FlowersData.swift
//  Flowers
//
//  Created by Tyler Mills and Osman Balci on 2/22/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import SwiftUI

// Global array of Flower structs
var flowerStructList = [Flower]()

/*
 Each orderedSearchableFlowersList element contains
 selected flower attributes separated by vertical lines
 for inclusion in the search by the Search Bar in FavoritesList:
      "name|meaning|description"
 */
var orderedSearchableFlowersList = [String]()

/*
 Global flag to track changes to flowerStructList.
 If changes are made, flowerStructList will be written to document directory
 in FlowersApp when the app life cycle state changes.
 */
var dataChanged = false

/*
 *****************************
 MARK: Read Flowers Data Files
 *****************************
 */
public func readFlowersDataFiles() {
    
    var documentDirectoryHasFiles = false
    let flowersDataFullFilename = "FlowersData.json"
    
    // Obtain URL of the FlowersData.json file in document directory on the user's device
    // Global constant documentDirectory is defined in UtilityFunctions.swift
    let urlOfJsonFileInDocumentDirectory = documentDirectory.appendingPathComponent(flowersDataFullFilename)

    do {
        /*
         Try to get the contents of the file. The left hand side is
         suppressed by using '_' since we do not use it at this time.
         Our purpose is just to check to see if the file is there or not.
         */

        _ = try Data(contentsOf: urlOfJsonFileInDocumentDirectory)
        
        /*
         If 'try' is successful, it means that the FlowersData.json
         file exists in document directory on the user's device.
         ---
         If 'try' is unsuccessful, it throws an exception and
         executes the code under 'catch' below.
         */
        
        documentDirectoryHasFiles = true
        
        /*
         --------------------------------------------------
         |   The app is being launched after first time   |
         --------------------------------------------------
         The FlowersData.json file exists in document directory on the user's device.
         Load it from Document Directory into flowerStructList.
         */
        
        // The function is given in UtilityFunctions.swift
        flowerStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: flowersDataFullFilename, fileLocation: "Document Directory")
        print("FlowersData is loaded from document directory")
        
    } catch {
        documentDirectoryHasFiles = false
        
        /*
         ----------------------------------------------------
         |   The app is being launched for the first time   |
         ----------------------------------------------------
         The FlowersData.json file does not exist in document directory on the user's device.
         Load it from main bundle (project folder) into flowerStructList.
         
         This catch section will be executed only once when the app is launched for the first time
         since we write and read the files in document directory on the user's device after first use.
         */
        
        // The function is given in UtilityFunctions.swift
        flowerStructList = decodeJsonFileIntoArrayOfStructs(fullFilename: flowersDataFullFilename, fileLocation: "Main Bundle")
        print("FlowersData is loaded from main bundle")
        
        /*
         -----------------------------------------------------------
         |   Create global variable orderedSearchableFlowersList   |
         -----------------------------------------------------------
         This list has two purposes:
         
            (1) preserve the order of flowers according to user's liking, and
            (2) enable search of selected flower attributes by the SearchBar in FavoritesList.
         
         Each list element consists of "name|meaning|description".
         We chose these attributes separated by vertical lines to be included in the search.
         We separate them with "|" so that we can extract its components separately.
         For example, to obtain the name: list item.components(separatedBy: "|")[0]
         */
        for flower in flowerStructList {
            let selectedFlowerAttributesForSearch = "\(flower.name)|\(flower.meaning)|\(flower.description)"
            
            orderedSearchableFlowersList.append(selectedFlowerAttributesForSearch)
        }
        
    }   // End of do-catch
    
    /*
    --------------------------------------
    Read OrderedSearchableFlowersList File
    --------------------------------------
    */
    if documentDirectoryHasFiles {
        // Obtain URL of the file in document directory on the user's device
        let urlOfFileInDocDir = documentDirectory.appendingPathComponent("OrderedSearchableFlowersList")
        
        // Instantiate an NSArray object and initialize it with the contents of the file
        let arrayFromFile: NSArray? = NSArray(contentsOf: urlOfFileInDocDir)
        
        if let arrayObtained = arrayFromFile {
            // Store the unique id of the created array into the global variable
            orderedSearchableFlowersList = arrayObtained as! [String]
        } else {
            print("OrderedSearchableFlowersList file is not found in document directory on the user's device!")
        }
    }
}

/*
 ****************************************************
 MARK: Write Flowers Data Files to Document Directory
 ****************************************************
 */
public func writeFlowersDataFiles() {
    /*
    -----------------------------------------------------------------------
    Write flowerStructList into FlowersData.json file in Document Directory
    -----------------------------------------------------------------------
    */
    
    // Obtain URL of the JSON file into which data will be written
    let urlOfJsonFileInDocumentDirectory: URL? = documentDirectory.appendingPathComponent("FlowersData.json")

    // Encode flowerStructList into JSON and write it into the JSON file
    let encoder = JSONEncoder()
    if let encoded = try? encoder.encode(flowerStructList) {
        do {
            try encoded.write(to: urlOfJsonFileInDocumentDirectory!)
        } catch {
            fatalError("Unable to write encoded flowers data to document directory!")
        }
    } else {
        fatalError("Unable to encode flowers data!")
    }
    
    /*
    ----------------------------------------------------
    Write orderedSearchableFlowersList into a file named
    OrderedSearchableFlowersList in Document Directory
    ----------------------------------------------------
    */

    // Obtain URL of the file in document directory on the user's device
    let urlOfFileInDocDirectory = documentDirectory.appendingPathComponent("OrderedSearchableFlowersList")

    /*
    Swift Array does not yet provide the 'write' function, but NSArray does.
    Therefore, typecast the Swift array as NSArray so that we can write it.
    */
    
    (orderedSearchableFlowersList as NSArray).write(to: urlOfFileInDocDirectory, atomically: true)
    
    /*
     The flag "atomically" specifies whether the file should be written atomically or not.
     
     If flag atomically is TRUE, the file is first written to an auxiliary file, and
     then the auxiliary file is renamed as OrderedSearchableFlowersList.
     
     If flag atomically is FALSE, the file is written directly to OrderedSearchableFlowersList.
     This is a bad idea since the file can be corrupted if the system crashes during writing.
     
     The TRUE option guarantees that the file will not be corrupted even if the system crashes during writing.
     */
    
    // Set global flag
    dataChanged = false
}

