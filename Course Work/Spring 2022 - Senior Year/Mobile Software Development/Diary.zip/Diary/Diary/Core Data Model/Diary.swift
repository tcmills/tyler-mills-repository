//
//  Diary.swift
//  Diary
//
//  Created by Tyler Mills, Haylin Kwok, and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import Foundation
import CoreData

// ❎ CoreData Diary entity public class
public class Diary: NSManagedObject, Identifiable {
    
    // Attributes
    @NSManaged public var date: String?
    @NSManaged public var title: String?
    @NSManaged public var diaryEntry: String?
    @NSManaged public var audio: Data?
    @NSManaged public var youTubeId: String?
    
    // Relationships
    @NSManaged public var photo: Photo?
    
}

extension Diary {
    /*
     ❎ CoreData @FetchRequest invokes this class method
        to fetch all of the Diary entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as Diary.allDiariesFetchRequest() in any .swift file in your project.
     */
    static func allDiariesFetchRequest() -> NSFetchRequest<Diary> {
        /*
         Create a fetchRequest to fetch Diary entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the Diary entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<Diary>(entityName: "Diary")
        
        /*
         List the fetched Diaries with respect to date
         */
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
        
        return fetchRequest
    }

}


