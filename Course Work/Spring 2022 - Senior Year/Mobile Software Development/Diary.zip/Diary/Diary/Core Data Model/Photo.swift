//
//  Photo.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/23/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import Foundation
import CoreData

// ❎ CoreData Photo entity public class
public class Photo: NSManagedObject, Identifiable {
    
    // Attributes
    @NSManaged public var photoData: Data?
    @NSManaged public var photoUrl: String?
    @NSManaged public var author: String?
    @NSManaged public var profileUrl: String?
    
    // Relationships
    @NSManaged public var diary: Diary?
    
}

extension Photo {
    /*
     ❎ CoreData @FetchRequest invokes this class method
        to fetch all of the Photo entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as Photo.allPhotosFetchRequest() in any .swift file in your project.
     */
    static func allPhotosFetchRequest() -> NSFetchRequest<Photo> {
        /*
         Create a fetchRequest to fetch Photo entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the Photo entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<Photo>(entityName: "Photo")
        
        /*
         List the fetched Photos in alphabetical order with respect to author
         */
        fetchRequest.sortDescriptors = [NSSortDescriptor(key: "author", ascending: true)]
        
        return fetchRequest
    }

}
