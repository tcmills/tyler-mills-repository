//
//  NotFound.swift
//  Diary
//
//  Created by Osman Balci on 3/11/22.
//  Copyright © 2022 Osman Balci. All rights reserved.
//

import SwiftUI
 
struct NotFound: View {
   
    // Input parameter
    let message: String
   
    var body: some View {
        ZStack {    // Color Background to Ivory color
            Color(red: 1.0, green: 1.0, blue: 240/255).edgesIgnoringSafeArea(.all)
          
            VStack {
                Image(systemName: "exclamationmark.triangle")
                    .imageScale(.large)
                    .font(Font.title.weight(.medium))
                    .foregroundColor(.red)
                    .padding()
                Text(message)
                    .fixedSize(horizontal: false, vertical: true)   // Allow lines to wrap around
                    .multilineTextAlignment(.center)
                    .padding()
            } // End of VStack
          
        } // End of ZStack
    }
}

struct NotFound_Previews: PreviewProvider {
    static var previews: some View {
        NotFound(message: "")
    }
}
