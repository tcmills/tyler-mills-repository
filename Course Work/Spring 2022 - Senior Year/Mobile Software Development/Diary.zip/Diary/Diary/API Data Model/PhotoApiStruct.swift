//
//  PhotoApiStruct.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/23/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct PhotoApiStruct: Identifiable {
    
    var id: UUID
    var photoUrl: String
    var authorName: String
    var profileUrl: String
    
}
