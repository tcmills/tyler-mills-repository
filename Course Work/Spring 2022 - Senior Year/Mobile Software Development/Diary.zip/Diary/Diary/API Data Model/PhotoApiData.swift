//
//  PhotoApiData.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/30/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import Foundation

// Global variable
var photoSearchResults = [PhotoApiStruct]()

var apiKey = "qlG7mFZ8GWwE6o1LhY271w7fqBe9r669f9DOgdx4PAk"

fileprivate var previousQuery = ""

/*
 ================================================================
 Get Photo Search Results from the API for the Given Search Query
 ================================================================
*/
public func getPhotoSearchResultsFromApi(query: String) {
    
    // Avoid executing this function if already done for the same query
    if query == previousQuery {
        return
    } else {
        previousQuery = query
    }
    
    photoSearchResults = [PhotoApiStruct]()
    
    /*
     *********************************************
     *   Obtaining API Search Query URL Struct   *
     *********************************************
     */
    
    let apiUrl = "https://api.unsplash.com/search/photos/?query=\(query)&per_page=25"
    
    /*
     searchQuery may include unrecognizable foreign characters inputted by the user,
     e.g., Côte d'Ivoire, that can prevent the creation of a URL struct from the
     given apiUrl string. Therefore, we must test it as an Optional.
    */
    var apiQueryUrlStruct: URL?
    
    if let urlStruct = URL(string: apiUrl) {
        apiQueryUrlStruct = urlStruct
    } else {
        // photoSearchResults will be empty
        return
    }

    /*
    *******************************
    *   HTTP GET Request Set Up   *
    *******************************
    */
    
    let headers = [
        "authorization": "Client-ID \(apiKey)",
        "accept": "application/json",
        "cache-control": "no-cache",
        "connection": "keep-alive",
        "host": "api.unsplash.com"
    ]

    let request = NSMutableURLRequest(url: apiQueryUrlStruct!,
                                      cachePolicy: .useProtocolCachePolicy,
                                      timeoutInterval: 10.0)

    request.httpMethod = "GET"
    request.allHTTPHeaderFields = headers

    /*
    *********************************************************************
    *  Setting Up a URL Session to Fetch the JSON File from the API     *
    *  in an Asynchronous Manner and Processing the Received JSON File  *
    *********************************************************************
    */
    
    /*
     Create a semaphore to control getting and processing API data.
     signal() -> Int    Signals (increments) a semaphore.
     wait()             Waits for, or decrements, a semaphore.
     */
    let semaphore = DispatchSemaphore(value: 0)

    URLSession.shared.dataTask(with: request as URLRequest, completionHandler: { (data, response, error) -> Void in
        /*
        URLSession is established and the JSON file from the API is set to be fetched
        in an asynchronous manner. After the file is fetched, data, response, error
        are returned as the input parameter values of this Completion Handler Closure.
        */

        // Process input parameter 'error'
        guard error == nil else {
            // photoSearchResults will be empty
            semaphore.signal()
            return
        }
        
        /*
         ---------------------------------------------------------
         🔴 Any 'return' used within the completionHandler Closure
            exits the Closure; not the public function it is in.
         ---------------------------------------------------------
         */

        // Process input parameter 'response'. HTTP response status codes from 200 to 299 indicate success.
        guard let httpResponse = response as? HTTPURLResponse, (200...299).contains(httpResponse.statusCode) else {
            // photoSearchResults will be empty
            semaphore.signal()
            return
        }

        // Process input parameter 'data'. Unwrap Optional 'data' if it has a value.
        guard let jsonDataFromApi = data else {
            // photoSearchResults will be empty
            semaphore.signal()
            return
        }

        //------------------------------------------------
        // JSON data is obtained from the API. Process it.
        //------------------------------------------------
        
        do {
            /*
            Foundation framework’s JSONSerialization class is used to convert JSON data
            into Swift data types such as Dictionary, Array, String, Number, or Bool.
            */
            let unsplashPhotoResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi,
                             options: JSONSerialization.ReadingOptions.mutableContainers)
            
            /*
             -----------------
             API Documentation
             -----------------
             */
            
            /*
             {
               "total": 133,
               "total_pages": 7,
               "results": [
                 {
                   "id": "eOLpJytrbsQ",
                   "created_at": "2014-11-18T14:35:36-05:00",
                   "width": 4000,
                   "height": 3000,
                   "color": "#A7A2A1",
                   "blur_hash": "LaLXMa9Fx[D%~q%MtQM|kDRjtRIU",
                   "likes": 286,
                   "liked_by_user": false,
                   "description": "A man drinking a coffee.",
                   "user": {
                     "id": "Ul0QVz12Goo",
                     "username": "ugmonk",
                    ✅"name": "Jeff Sheldon",
                     "first_name": "Jeff",
                     "last_name": "Sheldon",
                     "instagram_username": "instantgrammer",
                     "twitter_username": "ugmonk",
                     "portfolio_url": "http://ugmonk.com/",
                     "profile_image": {
                       "small": "https://images.unsplash.com/profile-1441298803695-accd94000cac?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&cs=tinysrgb&fit=crop&h=32&w=32&s=7cfe3b93750cb0c93e2f7caec08b5a41",
                       "medium": "https://images.unsplash.com/profile-1441298803695-accd94000cac?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&cs=tinysrgb&fit=crop&h=64&w=64&s=5a9dc749c43ce5bd60870b129a40902f",
                       "large": "https://images.unsplash.com/profile-1441298803695-accd94000cac?ixlib=rb-0.3.5&q=80&fm=jpg&crop=faces&cs=tinysrgb&fit=crop&h=128&w=128&s=32085a077889586df88bfbe406692202"
                     },
                     "links": {
                       "self": "https://api.unsplash.com/users/ugmonk",
                    ✅"html": "http://unsplash.com/@ugmonk",
                       "photos": "https://api.unsplash.com/users/ugmonk/photos",
                       "likes": "https://api.unsplash.com/users/ugmonk/likes"
                     }
                   },
                   "current_user_collections": [],
                   "urls": {
                     "raw": "https://images.unsplash.com/photo-1416339306562-f3d12fefd36f",
                     "full": "https://hd.unsplash.com/photo-1416339306562-f3d12fefd36f",
                    ✅"regular": "https://images.unsplash.com/photo-1416339306562-f3d12fefd36f?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=1080&fit=max&s=92f3e02f63678acc8416d044e189f515",
                     "small": "https://images.unsplash.com/photo-1416339306562-f3d12fefd36f?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=400&fit=max&s=263af33585f9d32af39d165b000845eb",
                     "thumb": "https://images.unsplash.com/photo-1416339306562-f3d12fefd36f?ixlib=rb-0.3.5&q=80&fm=jpg&crop=entropy&cs=tinysrgb&w=200&fit=max&s=8aae34cf35df31a592f0bef16e6342ef"
                   },
                   "links": {
                     "self": "https://api.unsplash.com/photos/eOLpJytrbsQ",
                     "html": "http://unsplash.com/photos/eOLpJytrbsQ",
                     "download": "http://unsplash.com/photos/eOLpJytrbsQ/download"
                   }
                 },
                 // more photos ...
               ]
             }

             */
            
            /*
            JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
            Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
            where Dictionary Key type is String and Value type is Any (instance of any type)
            */
            
            var unsplashPhotoDataDictionary = Dictionary<String, Any>()
     
            if let unsplashPhotoObject = unsplashPhotoResponse as? [String: Any] {
               unsplashPhotoDataDictionary = unsplashPhotoObject
            } else {
                // photoSearchResults will be empty
                semaphore.signal()
                return
            }
            
            // Get the results array
            if let resultsArray = unsplashPhotoDataDictionary["results"] as? [Any] {
        
                // Iterate over the array
                for aPhoto in resultsArray {
                    
                    var photoDataDictionary = Dictionary<String, Any>()
             
                    if let photo = aPhoto as? [String: Any] {
                       photoDataDictionary = photo
                    } else {
                       break
                    }
                    
                    var photoFileUrl = ""
                    var photoAuthorName = ""
                    var photoProfileUrl = ""
                    
                    //-----------------
                    // Obtain Photo Url
                    //-----------------
                    
                    var photoUrlDictionary = Dictionary<String, Any>()
                    
                    if let urlDictionary = photoDataDictionary["urls"] as? [String: Any] {
                       photoUrlDictionary = urlDictionary
                    }
                    else {
                       break
                    }
                    
                    if let url = photoUrlDictionary["regular"] as! String? {
                        photoFileUrl = url
                    }
                    
                    // Get the user json object
                    var photoUserDictionary = Dictionary<String, Any>()
                    
                    if let userDictionary = photoDataDictionary["user"] as? [String: Any] {
                        
                        photoUserDictionary = userDictionary
                        
                        //-------------------
                        // Obtain Author Name
                        //-------------------
                        
                        if let author = photoUserDictionary["name"] as! String? {
                            photoAuthorName = author
                        }
                        
                        //-------------------
                        // Obtain Profile Url
                        //-------------------
                        
                        var photoLinksDictionary = Dictionary<String, Any>()
                        
                        if let linksDictionary = photoUserDictionary["links"] as? [String: Any] {
                            
                            photoLinksDictionary = linksDictionary
                            
                            if let profileUrl = photoLinksDictionary["html"] as! String? {
                                photoProfileUrl = profileUrl
                            }
                            
                        }
                        
                    }   // End of photoUserDictionary
                    
                    //-------------------------------------------------------------------------
                    // Create an Instance of PhotoApiStruct and Append it to photoSearchResults
                    //-------------------------------------------------------------------------
                    
                    let foundPhoto = PhotoApiStruct(id: UUID(), photoUrl: photoFileUrl, authorName: photoAuthorName, profileUrl: photoProfileUrl)
                    
                    photoSearchResults.append(foundPhoto)
                    
                }   // End of for loop
                
            }
            // return if no results
            else {
                // photoSearchResults will be empty
                semaphore.signal()
                return
            }
            
        }
        catch {
            // photoSearchResults will be empty
            semaphore.signal()
            return
        }

        semaphore.signal()
    }).resume()

    /*
     The URLSession task above is set up. It begins in a suspended state.
     The resume() method starts processing the task in an execution thread.

     The semaphore.wait blocks the execution thread and starts waiting.
     Upon completion of the task, the Completion Handler code is executed.
     The waiting ends when .signal() fires or timeout period of 10 seconds expires.
    */

    _ = semaphore.wait(timeout: .now() + 10)

}
