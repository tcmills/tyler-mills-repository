//
//  MainView.swift
//  Diary
//
//  Created by Tyler Mills and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct MainView: View {
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            DiaryEntriesList()
                .tabItem {
                    Image(systemName: "text.book.closed")
                    Text("Diary Entries")
            }
            JigsawPuzzleList()
                .tabItem {
                    Image(systemName: "puzzlepiece")
                    Text("Jigsaw Puzzle")
            }
            DrawingView()
                .tabItem {
                    Image(systemName: "paintbrush.pointed")
                    Text("Paint")
            }
            More()
                .tabItem {
                    Image(systemName: "ellipsis")
                    Text("More")
                }
            
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct MainView_Previews: PreviewProvider {
    static var previews: some View {
        MainView()
    }
}
