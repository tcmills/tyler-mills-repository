//
//  DiaryData.swift
//  Diary
//
//  Created by Shuai Lin, Tyler Mills, and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI
import CoreData

// Array of DiaryStruct structs obtained from the JSON file
// for use only in this file to create the database
fileprivate var arrayOfDiaryStructs = [DiaryStruct]()

public func createDiaryDatabase() {
    // ❎ Get object reference of Core Data managedObjectContext from the persistent container
    let managedObjectContext = PersistenceController.shared.persistentContainer.viewContext
    
    //----------------------------
    // ❎ Define the Fetch Request
    //----------------------------
    let fetchRequest = NSFetchRequest<Diary>(entityName: "Diary")
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "date", ascending: true)]
    
    var listOfAllDiaryEntitiesInDatabase = [Diary]()
    
    do {
        //-----------------------------
        // ❎ Execute the Fetch Request
        //-----------------------------
        listOfAllDiaryEntitiesInDatabase = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("Database Creation Failed!")
        return
    }
    
    if listOfAllDiaryEntitiesInDatabase.count > 0 {
        print("Database has already been created!")
        return
    }
    
    print("Database will be created!")
    
    arrayOfDiaryStructs = decodeJsonFileIntoArrayOfStructs(fullFilename: "DiaryData.json", fileLocation: "Main Bundle")
    
    for aDiary in arrayOfDiaryStructs {
        /*
         =============================
         *   Diary Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Diary entity in managedObjectContext
        let diaryEntity = Diary(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        diaryEntity.title = aDiary.title
        diaryEntity.date = aDiary.date
        diaryEntity.diaryEntry = aDiary.diaryEntry
        diaryEntity.youTubeId = aDiary.youTubeId
        
        // Obtain the URL of the audio file from main bundle
        let audioFileUrl = Bundle.main.url(forResource: aDiary.audio, withExtension: "m4a")
         
        do {
            // Try to get the audio file data from audio
            diaryEntity.audio = try Data(contentsOf: audioFileUrl!, options: NSData.ReadingOptions.mappedIfSafe)
           
        } catch {
            fatalError("Audio file is not found in the main bundle!")
        }
        
        // 3️⃣ Its relationship with another Entity is defined below
        
        
        /*
         =============================
         *   Photo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Photo Entity in managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Obtain the photo image from Assets.xcassets as UIImage
        let photoUIImage = UIImage(named: aDiary.photo.photoFilename)
        
        // Convert photoUIImage to data of type Data (Binary Data) in JPEG format with 100% quality
        let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)
        
        // Assign photoData to Core Data entity attribute of type Data (Binary Data)
        photoEntity.photoData = photoData!
        photoEntity.photoUrl = ""
        photoEntity.author = ""
        photoEntity.profileUrl = ""
        
        // 3️⃣ Establish one-to-one relationship between Diary and Photo
        diaryEntity.photo = photoEntity      // A Diary can have only one photo
        photoEntity.diary = diaryEntity      // A photo can belong to only one Diary
        
        /*
         *************************************
         ❎ Save Changes to Core Data Database
         *************************************
         */
        
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
    }   // End of for loop

}
