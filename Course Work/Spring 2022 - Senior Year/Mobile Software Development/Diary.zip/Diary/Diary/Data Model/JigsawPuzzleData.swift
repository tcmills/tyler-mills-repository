//
//  JigsawPuzzleData.swift
//  Diary
//
//  Created by Tyler Mills and Osman Balci on 4/23/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import UIKit
import AVFoundation
import SwiftUI

// Global AVAudioPlayer object references
var clickSoundAudioPlayer: AVAudioPlayer?
var applaudSoundAudioPlayer: AVAudioPlayer?

/*
 --------------------
 Check iPhone or iPad
 --------------------
 */
public func isiPhone() -> Bool {
    if UIDevice.current.localizedModel == "iPhone" {
         return true    // The app is running on iPhone
    } else {
        return false    // The app is running on iPad
    }
}

/*
 --------------------
 Create Audio Players
 --------------------
 */
public func createAudioPlayers() {
    
    if let clickSoundAudioFileUrl = Bundle.main.url(forResource: "ClickSound", withExtension: "wav") {
        do {
            clickSoundAudioPlayer = try AVAudioPlayer(contentsOf: clickSoundAudioFileUrl)
            clickSoundAudioPlayer!.prepareToPlay()
        } catch {
            print("Unable to create clickSoundAudioPlayer!")
        }
    } else {
        print("Unable to find ClickSound in the main bundle!")
    }
    
    if let applaudSoundAudioFileUrl = Bundle.main.url(forResource: "ApplaudSound", withExtension: "wav") {
        do {
            applaudSoundAudioPlayer = try AVAudioPlayer(contentsOf: applaudSoundAudioFileUrl)
            applaudSoundAudioPlayer!.prepareToPlay()
        } catch {
            print("Unable to create applaudSoundAudioPlayer!")
        }
    } else {
        print("Unable to find ApplaudSound in the main bundle!")
    }
    
}
