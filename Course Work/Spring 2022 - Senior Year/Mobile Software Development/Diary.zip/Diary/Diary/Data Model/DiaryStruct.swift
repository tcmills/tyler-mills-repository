//
//  DiaryStruct.swift
//  Diary
//
//  Created by Shuai Lin and Osman Balci on 4/14/22
//  Copyright © 2022 Team 2. All rights reserved.
//

import Foundation

/*
 Diary and Photo are Entity class names that must be unique and cannot be used for struct name.
 Therefore, 'Struct' is added to make Entity and Struct name to be different.
 */

struct DiaryStruct: Decodable {
    
    var id: Int
    var date: String
    var title: String
    var diaryEntry: String
    var youTubeId: String
    var audio: String
    
    var photo: PhotoStruct
}

struct PhotoStruct: Decodable {
    var photoFilename: String

}

/*
 {
     "id": 1,
     "date": "",
     "title": "",
     "photo": {"photoFilename": ""},
     "diaryEntry": "",
     "video": "",
     "audio": ""
 }
 */
