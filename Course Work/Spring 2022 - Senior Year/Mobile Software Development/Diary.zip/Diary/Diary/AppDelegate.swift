//
//  AppDelegate.swift
//  Diary
//
//  Created by Tyler Mills and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        /*
        *****************************
        *   Create Diary Database   *
        *****************************
        */
        createDiaryDatabase()      // Given in DiaryData.swift
        
        /*
        *******************************************
        *   Get Permissions for Voice Recording   *
        *******************************************
        */
        getPermissionForVoiceRecording()        // In AudioPlayer.swift
        
        return true
    }
}
