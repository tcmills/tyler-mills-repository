//
//  Home.swift
//  Diary
//
//  Created by Tyler Mills and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI
import CoreData

struct Home: View {
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ✳️ Core Data FetchRequest returning all Diary entities from the database
    @FetchRequest(fetchRequest: Diary.allDiariesFetchRequest()) var allDiaries: FetchedResults<Diary>
    
    @State private var index = 0
    /*
     Create a timer publisher that fires 'every' 3 seconds and updates the view.
     It runs 'on' the '.main' runloop so that it can update the view.
     It runs 'in' the '.common' mode so that it can run alongside other
     common events such as when the ScrollView is being scrolled.
     */
    @State private var timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                Image("Welcome")
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                
                /*
                 -------------------------------------------------------------------------
                 Show an image slider of the photos of all of the diaries in the database.
                 -------------------------------------------------------------------------
                 */
                
                if (!(allDiaries[index].photo?.photoUrl ?? "").isEmpty) {
                    getImageFromUrl(url: (allDiaries[index].photo?.photoUrl ?? ""), defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: 300, maxHeight: 260)
                        .offset(.zero)
                    // Subscribe to the timer publisher
                    .onReceive(timer) { _ in
                        index += 1
                        if index > allDiaries.count - 1 {
                            index = 0
                        }
                    }
                }
                else if ((allDiaries[index].photo?.photoData ?? nil) != nil) {
                    getImageFromBinaryData(binaryData: allDiaries[index].photo?.photoData, defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 300)
                        .padding()
                    // Subscribe to the timer publisher
                    .onReceive(timer) { _ in
                        index += 1
                        if index > allDiaries.count - 1 {
                            index = 0
                        }
                    }
                }
                else {
                    Text("")
                        .onAppear() {
                            var searching = true
                            var tempIndex = index
                            var infinityCheck = 0
                            
                            // Search for the next index in allDiaries that has a photo
                            while (searching) {
                                tempIndex += 1
                                if tempIndex > allDiaries.count - 1 {
                                    tempIndex = 0
                                }
                                
                                if ((!(allDiaries[tempIndex].photo?.photoUrl ?? "").isEmpty) || ((allDiaries[tempIndex].photo?.photoData ?? nil) != nil)) {
                                    searching = false
                                    index = tempIndex
                                }
                                
                                // If no photo is found, then just display the Text("")
                                if infinityCheck >= (allDiaries.count*2) {
                                    searching = false
                                }
                                
                                infinityCheck += 1
                            }
                        }
                }
                
                // Diary title
                Text(allDiaries[index].title ?? "")
                    .font(.headline)
                    // Allow lines to wrap around
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                
                Text("Powered By")
                    .font(.system(size: 18, weight: .light, design: .serif))
                    .italic()
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                
                // Show Unsplash API provider's website externally in default web browser
                Link(destination: URL(string: "https://unsplash.com/developers")!, label: {
                    Image("UnsplashDevelopers") // Find Unsplash Picture
                        .renderingMode(.original)   // To keep the logo in its original form
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 60)
                })
                .padding()
                
            }   // End of VStack
        }   // End of ScrollView
        .onAppear() {
            startTimer()
        }
        .onDisappear() {
            stopTimer()
        }

        }   // End of ZStack
    }   // End of var
    
    func startTimer() {
        timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    }
    
    func stopTimer() {
        timer.upstream.connect().cancel()
    }
    
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}

