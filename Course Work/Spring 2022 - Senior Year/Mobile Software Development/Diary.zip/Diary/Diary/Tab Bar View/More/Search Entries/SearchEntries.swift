//
//  SearchEntries.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/30/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct SearchEntries: View {
    
    let searchCategoriesList = ["Entry Title Contains", "Entry Date Contains", "Entry Notes Contains"]
    @State private var selectedSearchCategoryIndex = 1
    
    @State private var searchFieldValue = ""
    @State private var searchCompleted = false
    
    //--------------
    // Alert Message
    //--------------
    @State private var showAlertMessage = false
    
    var body: some View {
            
        Form {
                
            Section(header: Text("Select a Search Category")) {
                Picker("", selection: $selectedSearchCategoryIndex) {
                    ForEach(0 ..< searchCategoriesList.count, id: \.self) {
                        Text(self.searchCategoriesList[$0])
                    }   // End of ForEach
                }   // End of Picker
                .pickerStyle(WheelPickerStyle())
            }
            Section(header: Text("Search Query Under Selected Category")) {
                HStack {
                    TextField("Enter Search Query", text: $searchFieldValue)
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .frame(minWidth: 260, maxWidth: 500, alignment: .leading)
                       
                    // Button to clear the text field
                    Button(action: {
                        searchFieldValue = ""
                        searchCompleted = false
                    }) {
                        Image(systemName: "clear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }   // End of HStack
            }
            Section(header: Text("Search Database")) {
                HStack {
                    Button(action: {
                        if inputDataValidated() {
                            searchEntries()
                            searchCompleted = true
                        } else {
                            showAlertMessage = true
                        }
                    }) {
                        Text(searchCompleted ? "Search Completed" : "Search")
                    }
                    .frame(width: 240, height: 36, alignment: .center)
                    .background(
                        RoundedRectangle(cornerRadius: 16)
                            .strokeBorder(Color.black, lineWidth: 1)
                    )
                }   // End of HStack
            }
            if searchCompleted {
                Section(header: Text("List Entries Found")) {
                    NavigationLink(destination: showSearchResults) {
                        HStack {
                            Image(systemName: "list.bullet")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                                .foregroundColor(.blue)
                            Text("List Entries Found")
                                .font(.system(size: 16))
                        }
                    }
                    .frame(minWidth: 300, maxWidth: 500)
                }
                Section(header: Text("Clear")) {
                    HStack {
                        Button(action: {
                            searchFieldValue = ""
                            searchCompleted = false
                        }) {
                            Text("Clear")
                        }
                        .frame(width: 120, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }
                }
            }
                
        }   // End of Form
        .navigationBarTitle(Text("Search Diary Entries"), displayMode: .inline)
        .alert("Unrecognized Input Data!", isPresented: $showAlertMessage, actions: {
                Button("OK") {}
            }, message: {
                Text("Please enter a valid search query!")
            })
        
    }   // End of body
    
    /*
     ------------------
     MARK: Search Diary
     ------------------
     */
    func searchEntries() {
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // searchCategory and searchQuery are global search parameters defined in EntriesSearch.swift
        searchCategory = searchCategoriesList[selectedSearchCategoryIndex]
        searchQuery = queryTrimmed

        // Public function searchDiaryEntries is given in EntriesSearch.swift
        searchDiaryEntries()
    }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array databaseSearchResults is given in EntriesSearch.swift
        if diaryEntriesSearchResults.isEmpty {
            return AnyView(NotFound(message: "Database Search Produced No Results!\n\nThe database did not return any value for the given search query!"))
        }
        
        return AnyView(SearchResultsList())
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if selectedSearchCategoryIndex == 3 || selectedSearchCategoryIndex == 4 {
            if let _ = Int(queryTrimmed) {
                // Entered value is valid integer
            } else {
                return false
            }
        } else {
            if (queryTrimmed.isEmpty) {
                return false
            }
        }
        
        return true
    }
    
}

struct SearchEntries_Previews: PreviewProvider {
    static var previews: some View {
        SearchEntries()
    }
}
