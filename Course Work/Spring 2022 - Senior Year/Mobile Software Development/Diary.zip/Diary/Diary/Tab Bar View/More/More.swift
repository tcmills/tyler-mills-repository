//
//  More.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 5/3/22.
//  Copyright © 2022 Osman Balci. All rights reserved.
//

import SwiftUI

struct More: View {
    
    var body: some View {
        NavigationView {
            List {
                NavigationLink(destination: SearchEntries()) {
                    HStack {
                        Image(systemName: "magnifyingglass")
                            .imageScale(.large)
                            .font(Font.title.weight(.regular))
                            .frame(width: 60, alignment: .center)
                        Text("Search")
                            .font(.custom("Helvetica", size: 14))
                    }
                    .foregroundColor(.blue)
                }
                NavigationLink(destination: Settings()) {
                    HStack {
                        Image(systemName: "gear")
                            .imageScale(.large)
                            .font(Font.title.weight(.regular))
                            .frame(width: 60, alignment: .center)
                        Text("Settings")
                            .font(.custom("Helvetica", size: 14))
                    }
                    .foregroundColor(.blue)
                }
            }   // End of List
            .navigationBarTitle(Text("More"), displayMode: .inline)
            
        }   // End of NavigationView
        // Use single column navigation view for iPhone and iPad
        .navigationViewStyle(StackNavigationViewStyle())
    }
}

struct More_Previews: PreviewProvider {
    static var previews: some View {
        More()
    }
}
