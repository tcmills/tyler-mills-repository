//
//  SearchResultsList.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/28/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct SearchResultsList: View {
    
    var body: some View {
            
        List {
            ForEach(diaryEntriesSearchResults) { anEntry in
                NavigationLink(destination: SearchResultDetails(diaryEntry: anEntry)) {
                    SearchResultItem(diaryEntry: anEntry)
                }
            }   // End of ForEach
        }   // End of List
        .navigationBarTitle(Text("Search Results"), displayMode: .inline)
        
    }
    
}

struct SearchResultsList_Previews: PreviewProvider {
    static var previews: some View {
        SearchResultsList()
    }
}
