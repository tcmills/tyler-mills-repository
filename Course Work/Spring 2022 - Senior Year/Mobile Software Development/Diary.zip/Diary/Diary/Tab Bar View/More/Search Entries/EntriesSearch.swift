//
//  EntriesSearch.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/30/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI
import CoreData

// Global variables
var diaryEntriesSearchResults = [Diary]()

// Global Search Parameters
var searchCategory = ""
var searchQuery = ""

fileprivate let managedObjectContext: NSManagedObjectContext = PersistenceController.shared.persistentContainer.viewContext

/*
 ==========================
 MARK: Search Diary Entries
 ==========================
 */
public func searchDiaryEntries() {
    
    // Initialize the array of Diary structs
    diaryEntriesSearchResults = [Diary]()
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Diary>(entityName: "Diary")
    
    /*
     List the fetched entries in "newest to oldest" order with respect to date
     */
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "date", ascending: false)]
    
    // 2️⃣ Define the Search Criteria
    switch searchCategory {
    case "Entry Title Contains":
        fetchRequest.predicate = NSPredicate(format: "title CONTAINS[c] %@", searchQuery)
    case "Entry Date Contains":
        fetchRequest.predicate = NSPredicate(format: "date CONTAINS[c] %@", searchQuery)
    case "Entry Notes Contains":
        fetchRequest.predicate = NSPredicate(format: "diaryEntry CONTAINS[c] %@", searchQuery)
    default:
        print("Search category is out of range!")
    }
    
    do {
        // 3️⃣ Execute the Fetch Request
        diaryEntriesSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for \(searchQuery) failed!")
    }
    
}
