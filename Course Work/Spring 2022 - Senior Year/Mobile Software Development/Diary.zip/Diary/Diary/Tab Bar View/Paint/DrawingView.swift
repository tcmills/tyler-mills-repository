//
//  DrawingView.swift
//  Diary
//
//  Created by Shuai Lin, Karin Prater, and KINGandKONG on 4/30/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct DrawingView: View {
    
    @State private var lines = [Line]()
    @State private var deletedLines = [Line]()
    
    @State private var sharedImage: UIImage?
    @State private var shotting = false
    
    @State private var selectedColor: Color = .black
    @State private var selectedLineWidth: CGFloat = 1
    
    @State private var showSaveAlert = false
    
    let engine = DrawingEngine()
    @State private var showDeleteConfirmation: Bool = false
    @State private var showSaveConfirmation: Bool = false
    
    let imageSize: CGSize = CGSize(width: 450, height: 800)
    
    var body: some View {
        
        VStack {
            
            HStack {
                ColorPicker("line color", selection: $selectedColor)
                    .labelsHidden()
                Slider(value: $selectedLineWidth, in: 1...20) {
                    Text("linewidth")
                }.frame(maxWidth: 100)
                Text(String(format: "%.0f", selectedLineWidth))
                
                Spacer()
                
                Button {
                    let last = lines.removeLast()
                    deletedLines.append(last)
                } label: {
                    Image(systemName: "arrow.uturn.backward.circle")
                        .imageScale(.large)
                }.disabled(lines.count == 0)
                
                Button {
                    let last = deletedLines.removeLast()
                    
                    lines.append(last)
                } label: {
                    Image(systemName: "arrow.uturn.forward.circle")
                        .imageScale(.large)
                }.disabled(deletedLines.count == 0)

                Button(action: {
                   showSaveConfirmation = true
                }) {
                    Text("Save")
                }
                    .foregroundColor(.red)
                    .confirmationDialog(Text("Are you sure you want to save everything?"), isPresented: $showSaveConfirmation,
                                        titleVisibility: .visible) {
                        Button("Save") {
                            let highresImage = paint.asImage(size: imageSize)
                            let imageSaver = ImageSaver()
                            imageSaver.writeToPhotoAlbum(image: highresImage)
                            showSaveAlert = true
                        }
                    }
                Button(action: {
                   showDeleteConfirmation = true
                }) {
                    Text("Delete")
                }
                    .foregroundColor(.red)
                    .confirmationDialog(Text("Are you sure you want to delete everything?"), isPresented: $showDeleteConfirmation, titleVisibility: .visible) {
                        Button("Delete", role: .destructive) {
                            lines = [Line]()
                            deletedLines = [Line]()
                        }
                    }
                
            }.padding()
            
            ZStack {
                Color.white
                
                ForEach(lines){ line in
                    DrawingShape(points: line.points)
                        .stroke(line.color, style: StrokeStyle(lineWidth: line.lineWidth, lineCap: .round, lineJoin: .round))
                }
            }
            .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local).onChanged({ value in
                let newPoint = value.location
                if value.translation.width + value.translation.height == 0 {
                    //TODO: use selected color and linewidth
                    lines.append(Line(points: [newPoint], color: selectedColor, lineWidth: selectedLineWidth))
                } else {
                    let index = lines.count - 1
                    lines[index].points.append(newPoint)
                }
                
            }).onEnded({ value in
                if let last = lines.last?.points, last.isEmpty {
                    lines.removeLast()
                }
            })
            
            )
        } //  End of VStack
        .alert("Save Completed", isPresented: $showSaveAlert, actions: {
            Button("OK") {}
        }, message: {
            Text("The painting has been saved to the media gallery!")
        })
    } //  End of body
    
    var paint: some View { //  For screenshot only
            
        ZStack {
            Color.white
            
            ForEach(lines){ line in
                DrawingShape(points: line.points)
                    .stroke(line.color, style: StrokeStyle(lineWidth: line.lineWidth, lineCap: .round, lineJoin: .round))
            }
        }
        .gesture(DragGesture(minimumDistance: 0, coordinateSpace: .local).onChanged({ value in
            let newPoint = value.location
            if value.translation.width + value.translation.height == 0 {
                //TODO: use selected color and linewidth
                lines.append(Line(points: [newPoint], color: selectedColor, lineWidth: selectedLineWidth))
            } else {
                let index = lines.count - 1
                lines[index].points.append(newPoint)
            }
            
        }).onEnded({ value in
            if let last = lines.last?.points, last.isEmpty {
                lines.removeLast()
            }
        })
        
        )
    } //  End of Paint
    
}

extension UIView {
    func asImage() -> UIImage {
        let format = UIGraphicsImageRendererFormat()
        format.scale = 1
        return UIGraphicsImageRenderer(size: self.layer.frame.size, format: format).image { context in
            self.drawHierarchy(in: self.layer.bounds, afterScreenUpdates: true)
        }
    }
}

extension View {
    func asImage(size: CGSize) -> UIImage {
        let controller = UIHostingController(rootView: self)
        controller.view.bounds = CGRect(origin: .zero, size: size)
        let image = controller.view.asImage()
        return image
    }
}

class ImageSaver: NSObject {
    func writeToPhotoAlbum(image: UIImage) {
        UIImageWriteToSavedPhotosAlbum(image, self, #selector(saveCompleted), nil)
    }

    @objc func saveCompleted(_ image: UIImage, didFinishSavingWithError error: Error?, contextInfo: UnsafeRawPointer) {
    }
}


struct DrawingView_Previews: PreviewProvider {
    static var previews: some View {
        DrawingView()
    }
}
