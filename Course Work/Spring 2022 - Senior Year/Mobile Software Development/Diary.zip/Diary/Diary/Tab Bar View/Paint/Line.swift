//
//  Line.swift
//  Diary
//
//  Created by Karin Prater on 6/18/21.
//  Copyright © 2022 Karin Prater. All rights reserved.
//

import Foundation
import SwiftUI

struct Line: Identifiable {
    
    var points: [CGPoint]
    var color: Color
    var lineWidth: CGFloat

    let id = UUID()
}
