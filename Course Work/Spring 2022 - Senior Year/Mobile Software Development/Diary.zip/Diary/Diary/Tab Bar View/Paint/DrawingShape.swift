//
//  DrawingShape.swift
//  Diary
//
//  Created by Karin Prater on 6/18/21.
//  Copyright © 2022 Karin Prater. All rights reserved.
//

import SwiftUI

struct DrawingShape: Shape {
    let points: [CGPoint]
    let engine = DrawingEngine()
    func path(in rect: CGRect) -> Path {
        engine.createPath(for: points)
    }
}
