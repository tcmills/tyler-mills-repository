//
//  ApiPhotoGrid.swift
//  Diary
//
//  Created by Haylin Kwok and Osman Balci on 4/25/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct ApiPhotoGrid: View {
    
    /*
     Display this view as a Modal View and enable it to dismiss itself
     to go back to the previous view in the navigation hierarchy.
     */
     @Environment(\.presentationMode) var presentationMode
    
    // Fit as many images per row as possible with minimum image width of 100 points each.
    // spacing defines spacing between columns
    let columns = [ GridItem(.adaptive(minimum: 100), spacing: 3) ]
    
    var body: some View {
        
        ScrollView {
            
            // spacing defines spacing between rows
            LazyVGrid(columns: columns, spacing: 3) {
                // 🔴 Specifying id: \.self is critically important to prevent photos being listed as out of order
                ForEach(photoSearchResults) { photo in
                    // Public function getImageFromUrl is given in UtilityFunctions.swift
                    getImageFromUrl(url: photo.photoUrl, defaultFilename: "ImageUnavailable")
                        .resizable()
                        .scaledToFit()
                        .onTapGesture {
                            chosenPhoto = photo
                            photoPickedFromApi = true
                            presentationMode.wrappedValue.dismiss()
                        }
                }
            }   // End of LazyVGrid
                .padding()

        }   // End of ScrollView
        .navigationBarTitle(Text("Photos from API"), displayMode: .inline)
        
    }   // End of body
    
}

struct ApiPhotoGrid_Previews: PreviewProvider {
    static var previews: some View {
        ApiPhotoGrid()
    }
}
