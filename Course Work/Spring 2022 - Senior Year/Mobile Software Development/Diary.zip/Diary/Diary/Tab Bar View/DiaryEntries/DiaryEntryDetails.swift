//
//  DiaryEntryDetails.swift
//  Diary
//
//  Created by Tyler Mills, Haylin Kwok, and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct DiaryEntryDetails: View {
    
    // Input parameter
    let diaryEntry: Diary
    
    // Audio player
    @EnvironmentObject var audioPlayer: AudioPlayer
    
    var body: some View {
        
        Form {
            Section(header: Text("Entry Title")) {
                Text(diaryEntry.title ?? "")
            }
            Section(header: Text("Entry Date")) {
                Text(diaryEntry.date ?? "")
            }
            Section(header: Text("Entry Photo")) {
                diaryEntryPhoto()
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
            }
            if (!(diaryEntry.photo?.photoUrl ?? "").isEmpty) {
                Section(header: Text("Photo Author")) {
                    Text(diaryEntry.photo?.author ?? "")
                }
                Section(header: Text("Author Profile Url")) {
                    Link(destination: URL(string: (diaryEntry.photo?.profileUrl ?? ""))!) {
                        if ((diaryEntry.photo?.profileUrl ?? "").isEmpty) {
                            Text("No profile url provided!")
                        }
                        else {
                            HStack {
                                Image(systemName: "person.crop.circle")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                Text("Go to author's profile page")
                                    .font(.system(size: 16))
                            }   // End of HStack
                            .foregroundColor(.blue)
                        }
                    }
                }
            }
            Section(header: Text("Entry Notes")) {
                Text(diaryEntry.diaryEntry ?? "")
            }
            Section(header: Text("Listen To Recorded Voice Notes")) {
                if (diaryEntry.audio == nil) {
                    Text("No audio notes!")
                }
                else {
                    Button(action: {
                        if audioPlayer.isPlaying {
                            audioPlayer.pauseAudioPlayer()
                        } else {
                            audioPlayer.startAudioPlayer()
                        }
                    }) {
                        HStack {
                            Image(systemName: audioPlayer.isPlaying ? "pause.fill" : "play.fill")
                                .font(Font.title.weight(.regular))
                            Text("Listen to Recorded voice Notes")
                                .font(.system(size: 16))
                            }
                        }   // End of HStack
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("Entry Video")) {
                if ((diaryEntry.youTubeId ?? "").isEmpty) {
                    Text("YouTube video is unavailable!")
                }
                else {
                    NavigationLink(destination: WebView(url: "http://www.youtube.com/embed/\(diaryEntry.youTubeId ?? "")")
                        .navigationBarTitle(Text("Play Video"), displayMode: .inline) )
                    {
                        HStack {
                            Image(systemName: "play.rectangle.fill")
                                .foregroundColor(.red)
                                .font(Font.title.weight(.regular))
                            Text("Play YouTube Video")
                                .font(.system(size: 16))
                        }   // End HStack
                    }
                }
            }
            
        }   // End of Form
        .font(.system(size: 14))
        .navigationBarTitle(Text("\(diaryEntry.date ?? "")"), displayMode: .inline)
        .onAppear() {
            if (diaryEntry.audio != nil) {
                audioPlayer.createAudioPlayer(audioData: diaryEntry.audio!)
            }
        }
        .onDisappear() {
            audioPlayer.stopAudioPlayer()
        }
        
    }   // End of body
    
    /*
     ---------------------
     MARK: Get Diary Photo
     ---------------------
     */
    func diaryEntryPhoto() -> Image {
        
        if (!(diaryEntry.photo?.photoUrl ?? "").isEmpty) {
            return getImageFromUrl(url: (diaryEntry.photo?.photoUrl ?? ""), defaultFilename: "ImageUnavailable")
        }
        
        return getImageFromBinaryData(binaryData: (diaryEntry.photo?.photoData ?? nil), defaultFilename: "ImageUnavailable")
        
    }
    
}
