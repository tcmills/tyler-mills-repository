//
//  DiaryEntriesList.swift
//  Diary
//
//  Created by Tyler Mills, Haylin Kwok, and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct DiaryEntriesList: View {
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ✳️ Core Data FetchRequest returning all Diary entities from the database
    @FetchRequest(fetchRequest: Diary.allDiariesFetchRequest()) var allDiaries: FetchedResults<Diary>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        
        NavigationView {
            
            List {
                
                ForEach(allDiaries) { anEntry in
                    NavigationLink(destination: DiaryEntryDetails(diaryEntry: anEntry)) {
                        DiaryEntryItem(diaryEntry: anEntry)
                    }
                }   // End of ForEach
                .onDelete(perform: delete)
                
            }   // End of List
            .navigationBarTitle(Text("Diary Entries"), displayMode: .inline)
            .navigationBarItems(leading: EditButton(), trailing:
                NavigationLink(destination: AddDiaryEntry()) {
                    Image(systemName: "plus")
            })
            
        }   // End of NavigationView
        .customNavigationViewStyle()
        
    }   // End of body
    
    /*
     ---------------------------------
     MARK: Delete Selected Diary Entry
     ---------------------------------
     */
    func delete(at offsets: IndexSet) {
        
        let entryToDelete = allDiaries[offsets.first!]
        
        // ❎ Delete Selected Diary Entry
        managedObjectContext.delete(entryToDelete)
        
        // ❎ Save Changes to Core Data Database
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
    }
    
}

struct DiaryEntriesList_Previews: PreviewProvider {
    static var previews: some View {
        DiaryEntriesList()
    }
}
