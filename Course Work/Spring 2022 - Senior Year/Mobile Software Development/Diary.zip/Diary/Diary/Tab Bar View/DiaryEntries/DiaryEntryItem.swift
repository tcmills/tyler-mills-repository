//
//  DiaryEntryItem.swift
//  Diary
//
//  Created by Tyler Mills, Haylin Kwok, and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct DiaryEntryItem: View {
    
    // Input parameter
    let diaryEntry: Diary
    
    var body: some View {
        
        HStack {
            
            diaryEntryPhoto()
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100)
            
            VStack (alignment: .leading) {
                if (!(diaryEntry.title ?? "").isEmpty) {
                    Text(diaryEntry.title ?? "")
                }
                Text(diaryEntry.date ?? "")
            }   // End of VStack
            .font(.system(size: 14))
            
        }   // End of HStack
        
    }   // End of body
    
    /*
     ---------------------
     MARK: Get Diary Photo
     ---------------------
     */
    func diaryEntryPhoto() -> Image {
        
        if (!(diaryEntry.photo?.photoUrl ?? "").isEmpty) {
            return getImageFromUrl(url: (diaryEntry.photo?.photoUrl ?? ""), defaultFilename: "ImageUnavailable")
        }
        
        return getImageFromBinaryData(binaryData: (diaryEntry.photo?.photoData ?? nil), defaultFilename: "ImageUnavailable")
        
    }
    
}
