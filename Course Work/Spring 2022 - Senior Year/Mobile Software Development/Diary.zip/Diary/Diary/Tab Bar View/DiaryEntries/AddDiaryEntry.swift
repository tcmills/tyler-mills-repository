//
//  AddDiaryEntry.swift
//  Diary
//
//  Created by Haylin Kwok, Shuai Lin, and Osman Balci on 4/14/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI
import CoreData
import AVFoundation

fileprivate var audioRecorder: AVAudioRecorder!

var chosenPhoto = PhotoApiStruct(id: UUID(), photoUrl: "", authorName: "", profileUrl: "")
var photoPickedFromApi = false

struct AddDiaryEntry: View {
    /*
     Display this view as a Modal View and enable it to dismiss itself
     to go back to the previous view in the navigation hierarchy.
     */
    @Environment(\.presentationMode) var presentationMode
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //--------------------------
    // Primary Diary Information
    //--------------------------
    @State private var diaryTitle = ""
    @State private var diaryDate = Date()
    @State private var diaryEntry = ""
    @State private var diaryYouTubeId = ""
    @State private var recordingVoice = false
    
    //------------------
    // Photo Information
    //------------------
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var useCamera = false
    @State private var usePhotoLibrary = true
    @State private var apiQuery = ""
    @State private var searchCompleted = false
    
    /*
     ---------------
     MARK: Body View
     ---------------
     */
    var body: some View {
        /*
         Create Binding between 'useCamera', 'usePhotoLibrary', and 'choosePhotoFromApi' boolean @State variables so that only one of them can be true.
         get
            A closure that retrieves the binding value. The closure has no parameters.
         set
            A closure that sets the binding value. The closure has the following parameter:
            newValue stored in $0: The new value of 'useCamera', 'usePhotoLibrary', or 'choosePhotoFromApi' boolean variable as true or false.
         
         Custom get and set closures are run when a newValue is obtained from the Toggle when it is turned on or off.
         */
        let camera = Binding(
            get: { useCamera },
            set: {
                useCamera = $0
                if $0 == true {
                    usePhotoLibrary = false
                }
            }
        )
        let photoLibrary = Binding(
            get: { usePhotoLibrary },
            set: {
                usePhotoLibrary = $0
                if $0 == true {
                    useCamera = false
                }
            }
        )
        
        Form {
            /*
             **********************************
             *   Primary Diary Information    *
             **********************************
             */
            Section(header: Text("Diary Entry Title")) {
                TextField("Enter diary title", text: $diaryTitle)
            }   // End of Section
            Section(header: Text("Diary Entry Date")) {
                HStack {
                    Text("Date Created")
                    DatePicker(
                        selection: $diaryDate,
                        in: dateClosedRange,
                        displayedComponents: .date // Sets DatePicker to pick a date
                    ){
                        Text("")
                    }
                }   // End of HStack
            }   // End of Section
            Section(header: Text("Diary Entry"),
                    footer: Image(systemName: "keyboard")
                        .foregroundColor(.blue)
                        .font(Font.title.weight(.regular))) {
                HStack {
                    TextEditor(text: $diaryEntry)
                        .frame(height: 100)
                        .font(.custom("Helvetica", size: 14))
                        .foregroundColor(.primary)
                        .lineSpacing(2)
                        .multilineTextAlignment(.leading)
                }   // End of HStack
            }   // End of Section
            Section(header: Text("YouTube Video Id")) {
                TextField("Enter YouTube video id", text: $diaryYouTubeId)
            }   // End of Section
            Section(header: Text("Diary Entry By Voice Recording")) {
                Button(action: {
                    voiceRecordingMicrophoneTapped()
                }) {
                    voiceRecordingMicrophoneLabel
                }
            }
            Section(header: Text("Take, Pick, or Choose Photo")) {
                VStack {
                    Toggle("Use Camera", isOn: camera)
                    Toggle("Use Photo Library", isOn: photoLibrary)
                    
                    Button(action: {
                        showImagePicker = true
                        chosenPhoto = PhotoApiStruct(id: UUID(), photoUrl: "", authorName: "", profileUrl: "")
                    }) {
                        Text("Get Photo")
                            .padding()
                    }
                }   // End of VStack
            }
            Section(header: Text("Search Photo from Api")) {
                HStack {
                    TextField("Enter Search Query", text: $apiQuery, onCommit: {
                        if (apiQuery.isEmpty) {
                            showAlertMessage = true
                            alertTitle = "Missing Input Data!"
                            alertMessage = "Please enter a search query"
                        }
                        else {
                            let queryTrimmed = apiQuery.trimmingCharacters(in: .whitespacesAndNewlines)
                            let queryWithoutSpace = queryTrimmed.replacingOccurrences(of: " ", with: "")
                            getPhotoSearchResultsFromApi(query: queryWithoutSpace)
                            searchCompleted = true
                        }
                    })
                        .textFieldStyle(RoundedBorderTextFieldStyle())
                        .disableAutocorrection(true)
                        .autocapitalization(.none)
                        .frame(minWidth: 260, maxWidth: 500, alignment: .leading)
                       
                    // Button to clear the text field
                    Button(action: {
                        apiQuery = ""
                        searchCompleted = false
                    }) {
                        Image(systemName: "clear")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                    }
                }   // End of HStack
            }
            if searchCompleted {
                Section(header: Text("Get Photo from Api"), footer: Text("Shows the first 25 photos").italic()) {
                    NavigationLink(destination: ApiPhotoGrid()) {
                        Text("Get Photo from API")
                    }
                }
            }
            Section(header: Text("Photo")) {
                photoImageTakenOrPicked
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 100.0, height: 100.0)
            }
        }   // End of Form
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .autocapitalization(.none)
            .disableAutocorrection(true)
            .font(.system(size: 14))
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                  Button("OK") {
                      if alertTitle == "New Diary Saved!" {
                          // Dismiss this Modal View, reset photos, and go back
                          photoImageData = nil
                          chosenPhoto = PhotoApiStruct(id: UUID(), photoUrl: "", authorName: "", profileUrl: "")
                          photoPickedFromApi = false
                          presentationMode.wrappedValue.dismiss()
                      }
                  }
                }, message: {
                  Text(alertMessage)
                })
            .navigationBarTitle(Text("Add New Diary"), displayMode: .inline)
            .navigationBarItems(trailing:
                Button(action: {
                    if inputDataValidated() {
                        saveNewDiary()
                        
                        showAlertMessage = true
                        alertTitle = "New Diary Saved!"
                        alertMessage = "New Diary is successfully saved in the database."
                    } else {
                        showAlertMessage = true
                        alertTitle = "Missing Input Data!"
                        alertMessage = "Please enter all required data! Required Data: Diary Date and Diary Entry."
                    }
                }) {
                    Text("Save")
            })
        
            .sheet(isPresented: $showImagePicker) {
                /*
                 🔴 We pass $showImagePicker and $photoImageData with $ sign into PhotoCaptureView
                 so that PhotoCaptureView can change them. The @Binding keywork in PhotoCaptureView
                 indicates that the input parameter is passed by reference and is changeable (mutable).
                 */
                PhotoCaptureView(showImagePicker: $showImagePicker,
                                 photoImageData: $photoImageData,
                                 cameraOrLibrary: useCamera ? "Camera" : "Photo Library")
            }
        
            .onAppear() {
                if (photoPickedFromApi) {
                    photoImageData = nil
                    photoPickedFromApi = false
                }
            }
        
    }   // End of body
    
    /*
     -----------------------
     MARK: Date Closed Range
     -----------------------
     */
    var dateClosedRange: ClosedRange<Date> {
        // Set minimum date to 40 years earlier than the current year
        let minDate = Calendar.current.date(byAdding: .year, value: -40, to: Date())!
       
        // Set maximum date to 10 years later than the current year
        let maxDate = Calendar.current.date(byAdding: .year, value: 10, to: Date())!
        return minDate...maxDate
    }
    
    /*
    --------------------------------------------
    MARK: Photo Image Taken or Picked or Default
    --------------------------------------------
    */
    var photoImageTakenOrPicked: Image {
        
        if let imageData = photoImageData {
            // The public function is given in UtilityFunctions.swift
            let photo = getImageFromBinaryData(binaryData: imageData, defaultFilename: "ImageUnavailable")
            return photo
        } else if (!chosenPhoto.photoUrl.isEmpty) {
            let photo = getImageFromUrl(url: chosenPhoto.photoUrl, defaultFilename: "ImageUnavailable")
            return photo
        } else {
            return Image("ImageUnavailable")
        }
    }
    
    /*
     --------------------------------------
     MARK: Voice Recording Microphone Label
     --------------------------------------
     */
    var voiceRecordingMicrophoneLabel: some View {
        VStack {
            Image(systemName: recordingVoice ? "mic.fill" : "mic.slash.fill")
                .imageScale(.large)
                .font(Font.title.weight(.medium))
                .foregroundColor(.blue)
                .padding()
            Text(recordingVoice ? "Recording your voice... Tap to Stop!" : "Start Recording!")
                .multilineTextAlignment(.center)
        }
    }
    
    /*
     --------------------
     MARK: Date Converter
     --------------------
     */
    func dateConverter(date: Date) -> String{
        let diaryDateBeforeConversion = diaryDate
        
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "yyyy-MM-dd"
        
        let diaryDateAfterConversion = dateFormatter.string(from: diaryDateBeforeConversion)
        
        return diaryDateAfterConversion
    }
    
    /*
     ---------------------------------------
     MARK: Voice Recording Microphone Tapped
     ---------------------------------------
     */
    func voiceRecordingMicrophoneTapped() {
        if audioRecorder == nil {
            recordingVoice = true
            startRecording()
        } else {
            recordingVoice = false
            finishRecording()
        }
    }
    
    /*
     --------------------------------
     MARK: Start Voice Memo Recording
     --------------------------------
     */
    func startRecording() {

        let settings = [
            AVFormatIDKey: Int(kAudioFormatMPEG4AAC),
            AVSampleRateKey: 12000,
            AVNumberOfChannelsKey: 1,
            AVEncoderAudioQualityKey: AVAudioQuality.high.rawValue
        ]
        
        let audioFullFilename = "temp.m4a"
        let audioFilenameUrl = documentDirectory.appendingPathComponent(audioFullFilename)
        
        do {
            audioRecorder = try AVAudioRecorder(url: audioFilenameUrl, settings: settings)
            audioRecorder.record()
        } catch {
            finishRecording()
        }
    }
    
    /*
     ---------------------------------
     MARK: Finish Voice Memo Recording
     ---------------------------------
     */
    func finishRecording() {
        audioRecorder.stop()
        audioRecorder = nil
        recordingVoice = false
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        if diaryEntry.isEmpty {
            return false
        }
        
        return true
    }
    
    /*
     ---------------------
     MARK: Save New Diary
     ---------------------
     */
    func saveNewDiary() {
        /*
         =============================
         *   Diary Entity Creation   *
         =============================
         */

        // 1️⃣ Create an instance of the diary entity in managedObjectContext
        let diaryEntity = Diary(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        diaryEntity.title = diaryTitle
        diaryEntity.date = dateConverter(date: diaryDate)
        diaryEntity.diaryEntry = diaryEntry
        diaryEntity.youTubeId = diaryYouTubeId
        
        // Store the recorded voice notes audio data into a temporary file
        let temporaryAudioFileUrl = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("temp.m4a")

        do {
            // Try to get the audio file data from temporaryAudioFileUrl
            diaryEntity.audio = try Data(contentsOf: temporaryAudioFileUrl, options: NSData.ReadingOptions.mappedIfSafe)
        } catch {
            diaryEntity.audio = nil
        }
        
        // 3️⃣ Its relationship with another Entity is defined below
        
        /*
         =============================
         *   Photo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Photo Entity in managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        
        if photoImageData == nil {
            photoEntity.photoData = nil
            photoEntity.photoUrl = chosenPhoto.photoUrl
            photoEntity.author = chosenPhoto.authorName
            photoEntity.profileUrl = chosenPhoto.profileUrl
        }
        else if let imageData = photoImageData {
            photoEntity.photoData = imageData
            photoEntity.photoUrl = ""
            photoEntity.author = ""
            photoEntity.profileUrl = ""
        } else {
            // Obtain the image unavailable from Assets.xcassets as UIImage
            let photoUIImage = UIImage(named: "ImageUnavailable")
            
            // Convert photoUIImage to data of type Data (Binary Data) in JPEG format with 100% quality
            let photoData = photoUIImage?.jpegData(compressionQuality: 1.0)
            
            // Assign photoData to Core Data entity attribute of type Data (Binary Data)
            photoEntity.photoData = photoData!
            photoEntity.photoUrl = ""
            photoEntity.author = ""
            photoEntity.profileUrl = ""
        }
        
        // 3️⃣ Establish one-to-one relationship between Diary and Photo
        diaryEntity.photo = photoEntity      // A diary can have only one photo
        photoEntity.diary = diaryEntity     // A photo can belong to only one diary
                
        /*
         ===========================================
         MARK: ✳️ Save Changes to Core Data Database
         ===========================================
         */

        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
        
    }   // End of func
    
}

struct AddDiaryEntry_Previews: PreviewProvider {
    static var previews: some View {
        AddDiaryEntry()
    }
}

