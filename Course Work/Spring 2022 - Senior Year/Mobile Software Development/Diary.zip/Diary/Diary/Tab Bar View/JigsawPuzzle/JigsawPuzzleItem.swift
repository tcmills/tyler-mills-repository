//
//  JigsawPuzzleItem.swift
//  Diary
//
//  Created by Tyler Mills and Osman Balci on 4/23/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct JigsawPuzzleItem: View {
    
    // ✳️ Input parameter: Core Data Company Entity instance reference
    let diary: Diary
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        Spacer()
        diaryEntryPhoto()
            .resizable()
            .aspectRatio(contentMode: .fit)
            .frame(width: 150.0)
        Spacer()
    }
    
    /*
     ---------------------
     MARK: Get Diary Photo
     ---------------------
     */
    func diaryEntryPhoto() -> Image {
        
        if (!(diary.photo?.photoUrl ?? "").isEmpty) {
            return getImageFromUrl(url: (diary.photo?.photoUrl ?? ""), defaultFilename: "ImageUnavailable")
        }
        
        return getImageFromBinaryData(binaryData: (diary.photo?.photoData ?? nil), defaultFilename: "ImageUnavailable")
        
    }
}
