//
//  JigsawPuzzle.swift
//  Diary
//
//  Created by Tyler Mills, Haylin Kwok, and Osman Balci on 4/23/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

fileprivate var startTime = Date().timeIntervalSinceReferenceDate
fileprivate var timerHours: UInt8 = 0
fileprivate var timerMinutes: UInt8 = 0
fileprivate var timerSeconds: UInt8 = 0

struct JigsawPuzzle: View {
    
    @State private var gameStarted = false
    @State private var gameEnded = false
    @State private var gamePlayDuration = ""
    @State private var sourceImage = UIImage()
    
    /*
     CGSize is a structure that is sometimes used to represent a distance vector,
     as used herein, rather than a physical size. As a vector, its values can be negative.
     The value .zero defines the size whose width and height are both zero.
     */
    @State private var currentPosition1:    CGSize = .zero
    @State private var newPosition1:        CGSize = .zero
    @State private var currentPosition2:    CGSize = .zero
    @State private var newPosition2:        CGSize = .zero
    @State private var currentPosition3:    CGSize = .zero
    @State private var newPosition3:        CGSize = .zero
    @State private var currentPosition4:    CGSize = .zero
    @State private var newPosition4:        CGSize = .zero
    @State private var currentPosition5:    CGSize = .zero
    @State private var newPosition5:        CGSize = .zero
    @State private var currentPosition6:    CGSize = .zero
    @State private var newPosition6:        CGSize = .zero
    @State private var currentPosition7:    CGSize = .zero
    @State private var newPosition7:        CGSize = .zero
    @State private var currentPosition8:    CGSize = .zero
    @State private var newPosition8:        CGSize = .zero
    @State private var currentPosition9:    CGSize = .zero
    @State private var newPosition9:        CGSize = .zero
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    // ✳️ Input parameter: Core Data Company Entity instance reference
    let diary: Diary
        
    @State private var puzzlePiece1 = UIImage()
    @State private var puzzlePiece2 = UIImage()
    @State private var puzzlePiece3 = UIImage()
    @State private var puzzlePiece4 = UIImage()
    @State private var puzzlePiece5 = UIImage()
    @State private var puzzlePiece6 = UIImage()
    @State private var puzzlePiece7 = UIImage()
    @State private var puzzlePiece8 = UIImage()
    @State private var puzzlePiece9 = UIImage()
    
    /*
     ------------------------------
     Global Constants and Variables
     ------------------------------
     */

    // Obtain the screen size of the device the app is running on
    let screenWidth  = UIScreen.main.bounds.width
    let screenHeight = UIScreen.main.bounds.height

    // Set the completed puzzle image size for iPhone and iPad the app is running on
    @State var completedPuzzleImageWidth:  CGFloat = 606 // Temporary: Will change once photo is measured
    @State var completedPuzzleImageHeight:  CGFloat = 448 // Temporary: Will change once photo is measured

    let puzzlePieceImageNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]

    // Image numbers are shuffled to produce a random list of puzzle piece images
    @State var shuffledPuzzlePieceImageNumbers = [1, 2, 3, 4, 5, 6, 7, 8, 9]

    // Set the correct positions of the solved puzzle piece images for iPhone and iPad the app is running on
    @State var correctPosition1  = CGSize(width: 0, height: 0)
    @State var correctPosition2  = CGSize(width: 0, height: 0)
    @State var correctPosition3  = CGSize(width: 0, height: 0)
    @State var correctPosition4  = CGSize(width: 0, height: 0)
    @State var correctPosition5  = CGSize(width: 0, height: 0)
    @State var correctPosition6  = CGSize(width: 0, height: 0)
    @State var correctPosition7  = CGSize(width: 0, height: 0)
    @State var correctPosition8  = CGSize(width: 0, height: 0)
    @State var correctPosition9  = CGSize(width: 0, height: 0)

    /*
     Distance tolerance to snap the puzzle piece image to its correct position:
        IF currentPosition width  is within the correctPosition width  +/- delta AND
           currentPosition height is within the correctPosition height +/- delta
        THEN
           The puzzle piece image will be snapped to its correct position AND
           Click sound will be played to inform the user for the snap action
     */
    let delta = isiPhone() ? CGFloat(10.0) : CGFloat(20.0)
    
    var body: some View {
        ZStack {    // Background View
            
            if gameStarted {
                // Create a rectangle to show the game play area
                Rectangle()
                    .stroke(Color.gray, lineWidth: 1)
                    .frame(width: completedPuzzleImageWidth, height: completedPuzzleImageHeight)
                    .offset(.zero)
            } else {
                // Show the original jigsaw puzzle image if game is not started
                
                if (!(diary.photo?.photoUrl ?? "").isEmpty) {
                    getImageFromUrl(url: (diary.photo?.photoUrl ?? ""), defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: 300, maxHeight: 260)
                        .offset(.zero)
                }
                else {
                    getImageFromBinaryData(binaryData: diary.photo?.photoData, defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(maxWidth: 300, maxHeight: 260)
                        .offset(.zero)
                }
            }
            
            if gameStarted {
                /*
                 Display randomly shuffled puzzle piece images in the order generated
                 on top of each other at each image's initial current position as set
                 to .zero, which is the iPad's center point coordinate (0, 0)
                 */
                ForEach(shuffledPuzzlePieceImageNumbers, id: \.self) { imageNumber in
                    shuffledPuzzlePieceImage(imageNo: imageNumber)
                }
            }
            
            HStack {    // Foreground View
                if gameEnded {  // If game ended show balloons
                    Image(isiPhone() ? "Balloons_iPhone" : "Balloons_iPad")
                        // Image position on left
                        .offset(x: -(completedPuzzleImageWidth/2 + (screenWidth - completedPuzzleImageWidth)/8), y: 0.0)
                    
                    Image(isiPhone() ? "Balloons_iPhone" : "Balloons_iPad")
                        // Image position on right
                        .offset(x: (completedPuzzleImageWidth/2 + (screenWidth - completedPuzzleImageWidth)/8), y: 0.0)
                }
            }
            
            VStack {    // Foreground View
                HStack {
                    //-----------------
                    // Play Game Button
                    //-----------------
                    Button(action: {
                        cropPuzzlePieceImage()
                        playGame()
                    }) {
                        Text("Play Game")
                            .padding(5)
                            .padding(.horizontal)
                    }
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .strokeBorder(Color.blue, lineWidth: 1)
                    )
                    .padding(.leading)
                    .padding(.top)
                    .disabled(gameStarted)
                    
                    //--------------
                    // Cancel Button
                    //--------------
                    Button(action: {
                        initializeGame()
                    }) {
                        Text("Cancel")
                            .padding(5)
                            .padding(.horizontal)
                    }
                    .background(
                        RoundedRectangle(cornerRadius: 20)
                            .strokeBorder(Color.blue, lineWidth: 1)
                    )
                    .padding(.leading)
                    .padding(.top)
                    
                    Spacer()    // Move the two buttons to left side of the screen
                    
                    //-------------------------
                    // Game Play Duration Timer
                    //-------------------------
                    Text(gamePlayDuration)
                        .padding(20)
                    
                }   // End of HStack
                
                Spacer()    // Move the HStack to top side of the screen
                
            }   // End of VStack
            .onAppear() {
                // Create Audio Players
                createAudioPlayers()        // Given in JigsawPuzzleData.swift
            }
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                Button("OK") {
                    initializeGame()
                }
            }, message: {
                Text(alertMessage)
            })
            
        }   // End of ZStack
    }       // End of body
    
    /*
     ---------------------------------------
     MARK: Return Cropped Puzzle Piece Image
     ---------------------------------------
     */
    func cropPuzzlePieceImage() {
        
        if (!(diary.photo?.photoUrl ?? "").isEmpty) {
            let url = URL(string: diary.photo?.photoUrl ?? "")
            if let data = try? Data(contentsOf: url!) {
                sourceImage = UIImage(data: data) ?? UIImage()
            }
        }
        else {
            sourceImage = UIImage(data: diary.photo?.photoData ?? Data()) ?? UIImage()
        }
        
        var newScale = sourceImage.imageRendererFormat.scale
        
        if (sourceImage.size.width > 300) {
            completedPuzzleImageWidth = 300
            completedPuzzleImageHeight = (sourceImage.size.height/(sourceImage.size.width/300))
            newScale = (sourceImage.size.width/300)
        } else {
            completedPuzzleImageWidth = sourceImage.size.width
            completedPuzzleImageHeight = sourceImage.size.height
        }
        
        if (completedPuzzleImageHeight > 260) {
            completedPuzzleImageHeight = 260
            completedPuzzleImageWidth = (sourceImage.size.width/(sourceImage.size.height/260))
            newScale = (sourceImage.size.height/260)
        }
        
        correctPosition1  = CGSize(width: ((-1)*(completedPuzzleImageWidth/3)), height: ((-1)*(completedPuzzleImageHeight/3)))
        correctPosition2  = CGSize(width: 0, height: ((-1)*(completedPuzzleImageHeight/3)))
        correctPosition3  = CGSize(width: (completedPuzzleImageWidth/3), height: ((-1)*(completedPuzzleImageHeight/3)))
        correctPosition4  = CGSize(width: ((-1)*(completedPuzzleImageWidth/3)), height: 0)
        correctPosition5  = CGSize(width: 0, height: 0)
        correctPosition6  = CGSize(width: (completedPuzzleImageWidth/3), height: 0)
        correctPosition7  = CGSize(width: ((-1)*(completedPuzzleImageWidth/3)), height: (completedPuzzleImageHeight/3))
        correctPosition8  = CGSize(width: 0, height: (completedPuzzleImageHeight/3))
        correctPosition9  = CGSize(width: (completedPuzzleImageWidth/3), height: (completedPuzzleImageHeight/3))

        // The dimensions of each piece
        let pieceHeight = sourceImage.size.height / 3
        let pieceWidth = sourceImage.size.width / 3

        // The cropRect is the rect of the image to keep
        let cropRect1 = CGRect(
            x: 0,
            y: 0,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect2 = CGRect(
            x: pieceWidth,
            y: 0,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect3 = CGRect(
            x: pieceWidth * 2,
            y: 0,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect4 = CGRect(
            x: 0,
            y: pieceHeight,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect5 = CGRect(
            x: pieceWidth,
            y: pieceHeight,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect6 = CGRect(
            x: pieceWidth * 2,
            y: pieceHeight,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect7 = CGRect(
            x: 0,
            y: pieceHeight * 2,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect8 = CGRect(
            x: pieceWidth,
            y: pieceHeight * 2,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        let cropRect9 = CGRect(
            x: pieceWidth * 2,
            y: pieceHeight * 2,
            width: pieceWidth,
            height: pieceHeight
        ).integral
        
        

        // Crop the image
        let sourceCGImage = sourceImage.cgImage!
        let croppedCGImage1 = sourceCGImage.cropping(
            to: cropRect1
        )!
        
        let croppedCGImage2 = sourceCGImage.cropping(
            to: cropRect2
        )!
        
        let croppedCGImage3 = sourceCGImage.cropping(
            to: cropRect3
        )!
        
        let croppedCGImage4 = sourceCGImage.cropping(
            to: cropRect4
        )!
        
        let croppedCGImage5 = sourceCGImage.cropping(
            to: cropRect5
        )!
        
        let croppedCGImage6 = sourceCGImage.cropping(
            to: cropRect6
        )!
        
        let croppedCGImage7 = sourceCGImage.cropping(
            to: cropRect7
        )!
        
        let croppedCGImage8 = sourceCGImage.cropping(
            to: cropRect8
        )!
        
        let croppedCGImage9 = sourceCGImage.cropping(
            to: cropRect9
        )!
        
        // UIImage with the same image scale and orientation
        puzzlePiece1 = UIImage(
            cgImage: croppedCGImage1,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece2 = UIImage(
            cgImage: croppedCGImage2,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece3 = UIImage(
            cgImage: croppedCGImage3,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece4 = UIImage(
            cgImage: croppedCGImage4,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece5 = UIImage(
            cgImage: croppedCGImage5,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece6 = UIImage(
            cgImage: croppedCGImage6,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece7 = UIImage(
            cgImage: croppedCGImage7,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece8 = UIImage(
            cgImage: croppedCGImage8,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
        
        puzzlePiece9 = UIImage(
            cgImage: croppedCGImage9,
            scale: newScale,
            orientation: sourceImage.imageOrientation
        )
    }
    
    /*
     ----------------------------------------
     MARK: Return Shuffled Puzzle Piece Image
     ----------------------------------------
     */
    func shuffledPuzzlePieceImage(imageNo: Int) -> some View {
        
        switch imageNo {
        case 1:
            return AnyView(puzzlePieceImage1)
        case 2:
            return AnyView(puzzlePieceImage2)
        case 3:
            return AnyView(puzzlePieceImage3)
        case 4:
            return AnyView(puzzlePieceImage4)
        case 5:
            return AnyView(puzzlePieceImage5)
        case 6:
            return AnyView(puzzlePieceImage6)
        case 7:
            return AnyView(puzzlePieceImage7)
        case 8:
            return AnyView(puzzlePieceImage8)
        case 9:
            return AnyView(puzzlePieceImage9)
        default:
            print("Image number is out of range!")
        }
        return AnyView(puzzlePieceImage9)
    }
    
    /*
     ---------------------
     MARK: Initialize Game
     ---------------------
     */
    func initializeGame() {
        
        gameStarted = false
        gameEnded = false
        
        gamePlayDuration = ""
        startTime = Date().timeIntervalSinceReferenceDate
        timerHours = 0
        timerMinutes = 0
        timerSeconds = 0
        
        currentPosition1   = .zero
        newPosition1       = .zero
        currentPosition2   = .zero
        newPosition2       = .zero
        currentPosition3   = .zero
        newPosition3       = .zero
        currentPosition4   = .zero
        newPosition4       = .zero
        currentPosition5   = .zero
        newPosition5       = .zero
        currentPosition6   = .zero
        newPosition6       = .zero
        currentPosition7   = .zero
        newPosition7       = .zero
        currentPosition8   = .zero
        newPosition8       = .zero
        currentPosition9   = .zero
        newPosition9       = .zero
    }
    
    /*
     ---------------
     MARK: Play Game
     ---------------
     */
    func playGame() {
        
        shuffledPuzzlePieceImageNumbers = puzzlePieceImageNumbers.shuffled()
        
        gameStarted = true
        
        // Time at which game starts
        startTime = Date().timeIntervalSinceReferenceDate
        durationTimer()
    }
    
    /*
     -------------------------
     MARK: Game Duration Timer
     -------------------------
     */
    func durationTimer() {
        
        // Schedule a timer that repeats every 0.01 second
        Timer.scheduledTimer(withTimeInterval: 0.01, repeats: true) { timer in
            
            if gameStarted {
                
                // Calculate total time in seconds since timer started
                var timeElapsed = Date().timeIntervalSinceReferenceDate - startTime
                
                // Calculate hours
                timerHours = UInt8(timeElapsed / 3600)
                timeElapsed = timeElapsed - (TimeInterval(timerHours) * 3600)
                
                // Calculate minutes
                timerMinutes = UInt8(timeElapsed / 60.0)
                timeElapsed = timeElapsed - (TimeInterval(timerMinutes) * 60)
                
                // Calculate seconds
                timerSeconds = UInt8(timeElapsed)
                timeElapsed = timeElapsed - TimeInterval(timerSeconds)
                
                // Calculate milliseconds
                let timerMilliseconds = UInt8(timeElapsed * 100)
                
                // Create the time string and update the label
                let timeString = String(format: "%02d:%02d:%02d.%02d", timerHours, timerMinutes, timerSeconds, timerMilliseconds)
                
                gamePlayDuration = timeString
                
            } else {
                timer.invalidate()      // Stop the timer
            }
        }
    }
    
    /*
     -------------------------
     MARK: Check If Game Ended
     -------------------------
     */
    func checkIfGameEnded() {
        if
            currentPosition1.width   == correctPosition1.width   &&
            currentPosition1.height  == correctPosition1.height  &&
            currentPosition2.width   == correctPosition2.width   &&
            currentPosition2.height  == correctPosition2.height  &&
            currentPosition3.width   == correctPosition3.width   &&
            currentPosition3.height  == correctPosition3.height  &&
            currentPosition4.width   == correctPosition4.width   &&
            currentPosition4.height  == correctPosition4.height  &&
            currentPosition5.width   == correctPosition5.width   &&
            currentPosition5.height  == correctPosition5.height  &&
            currentPosition6.width   == correctPosition6.width   &&
            currentPosition6.height  == correctPosition6.height  &&
            currentPosition7.width   == correctPosition7.width   &&
            currentPosition7.height  == correctPosition7.height  &&
            currentPosition8.width   == correctPosition8.width   &&
            currentPosition8.height  == correctPosition8.height  &&
            currentPosition9.width   == correctPosition9.width   &&
            currentPosition9.height  == correctPosition9.height
        {
            /*
             ******************
             *   Game Ended   *
             ******************
             */
            
            gameEnded = true
            gameStarted = false
            durationTimer()
            
            // Calculate game play duration in seconds
            let gameDurationInSeconds = 3600 * Int(timerHours) + 60 * Int(timerMinutes) + Int(timerSeconds)
            
            var gamePerformance = ""
            
            switch gameDurationInSeconds {
            case 1..<20:
                gamePerformance = "Outstanding"
            case 20..<40:
                gamePerformance = "Excellent"
            case 40..<60:
                gamePerformance = "Good"
            case 60..<80:
                gamePerformance = "Satisfactory"
            default:
                gamePerformance = "Slow"
            }
            
            showAlertMessage = true
            alertTitle = "Game Over!"
            alertMessage = "You solved the jigsaw puzzle in \(gameDurationInSeconds) seconds!\n\nYour game play performance is \(gamePerformance)!"
            
            applaudSoundAudioPlayer!.play()
        }
    }   // End of function
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 1
     --------------------------
     */
    var puzzlePieceImage1: some View {
        return AnyView(
            Image(uiImage: puzzlePiece1)
            /*
             Since currentPosition1 width and height are both zero initially,
             puzzlePieceImage1 is placed at the center point of the screen.
             */
                .offset(x: currentPosition1.width, y: currentPosition1.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition1 = CGSize(width: value.translation.width + newPosition1.width, height: value.translation.height + newPosition1.height)
                            }
                            .onEnded { value in
                                currentPosition1 = CGSize(width: value.translation.width + newPosition1.width, height: value.translation.height + newPosition1.height)
                                newPosition1 = currentPosition1
                                
                                if currentPosition1.width  > (correctPosition1.width - delta) &&
                                    currentPosition1.width  < (correctPosition1.width + delta) &&
                                    currentPosition1.height > (correctPosition1.height - delta) &&
                                    currentPosition1.height < (correctPosition1.height + delta)
                                {
                                    currentPosition1.width  = correctPosition1.width
                                    currentPosition1.height = correctPosition1.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 2
     --------------------------
     */
    var puzzlePieceImage2: some View {
        return AnyView(
            Image(uiImage: puzzlePiece2)
                .offset(x: currentPosition2.width, y: currentPosition2.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition2 = CGSize(width: value.translation.width + newPosition2.width, height: value.translation.height + newPosition2.height)
                            }
                            .onEnded { value in
                                currentPosition2 = CGSize(width: value.translation.width + newPosition2.width, height: value.translation.height + newPosition2.height)
                                newPosition2 = currentPosition2
                                
                                if currentPosition2.width  > (correctPosition2.width - delta) &&
                                    currentPosition2.width  < (correctPosition2.width + delta) &&
                                    currentPosition2.height > (correctPosition2.height - delta) &&
                                    currentPosition2.height < (correctPosition2.height + delta)
                                {
                                    currentPosition2.width  = correctPosition2.width
                                    currentPosition2.height = correctPosition2.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 3
     --------------------------
     */
    var puzzlePieceImage3: some View {
        return AnyView(
            Image(uiImage: puzzlePiece3)
                .offset(x: currentPosition3.width, y: currentPosition3.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition3 = CGSize(width: value.translation.width + newPosition3.width, height: value.translation.height + newPosition3.height)
                            }
                            .onEnded { value in
                                currentPosition3 = CGSize(width: value.translation.width + newPosition3.width, height: value.translation.height + newPosition3.height)
                                newPosition3 = currentPosition3
                                
                                if currentPosition3.width  > (correctPosition3.width - delta) &&
                                    currentPosition3.width  < (correctPosition3.width + delta) &&
                                    currentPosition3.height > (correctPosition3.height - delta) &&
                                    currentPosition3.height < (correctPosition3.height + delta)
                                {
                                    currentPosition3.width  = correctPosition3.width
                                    currentPosition3.height = correctPosition3.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 4
     --------------------------
     */
    var puzzlePieceImage4: some View {
        return AnyView(
            Image(uiImage: puzzlePiece4)
                .offset(x: currentPosition4.width, y: currentPosition4.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition4 = CGSize(width: value.translation.width + newPosition4.width, height: value.translation.height + newPosition4.height)
                            }
                            .onEnded { value in
                                currentPosition4 = CGSize(width: value.translation.width + newPosition4.width, height: value.translation.height + newPosition4.height)
                                newPosition4 = currentPosition4
                                
                                if currentPosition4.width  > (correctPosition4.width - delta) &&
                                    currentPosition4.width  < (correctPosition4.width + delta) &&
                                    currentPosition4.height > (correctPosition4.height - delta) &&
                                    currentPosition4.height < (correctPosition4.height + delta)
                                {
                                    currentPosition4.width  = correctPosition4.width
                                    currentPosition4.height = correctPosition4.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 5
     --------------------------
     */
    var puzzlePieceImage5: some View {
        return AnyView(
            Image(uiImage: puzzlePiece5)
                .offset(x: currentPosition5.width, y: currentPosition5.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition5 = CGSize(width: value.translation.width + newPosition5.width, height: value.translation.height + newPosition5.height)
                            }
                            .onEnded { value in
                                currentPosition5 = CGSize(width: value.translation.width + newPosition5.width, height: value.translation.height + newPosition5.height)
                                newPosition5 = currentPosition5
                                
                                if currentPosition5.width  > (correctPosition5.width - delta) &&
                                    currentPosition5.width  < (correctPosition5.width + delta) &&
                                    currentPosition5.height > (correctPosition5.height - delta) &&
                                    currentPosition5.height < (correctPosition5.height + delta)
                                {
                                    currentPosition5.width  = correctPosition5.width
                                    currentPosition5.height = correctPosition5.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 6
     --------------------------
     */
    var puzzlePieceImage6: some View {
        return AnyView(
            Image(uiImage: puzzlePiece6)
                .offset(x: currentPosition6.width, y: currentPosition6.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition6 = CGSize(width: value.translation.width + newPosition6.width, height: value.translation.height + newPosition6.height)
                            }
                            .onEnded { value in
                                currentPosition6 = CGSize(width: value.translation.width + newPosition6.width, height: value.translation.height + newPosition6.height)
                                newPosition6 = currentPosition6
                                
                                if currentPosition6.width  > (correctPosition6.width - delta) &&
                                    currentPosition6.width  < (correctPosition6.width + delta) &&
                                    currentPosition6.height > (correctPosition6.height - delta) &&
                                    currentPosition6.height < (correctPosition6.height + delta)
                                {
                                    currentPosition6.width  = correctPosition6.width
                                    currentPosition6.height = correctPosition6.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 7
     --------------------------
     */
    var puzzlePieceImage7: some View {
        return AnyView(
            Image(uiImage: puzzlePiece7)
                .offset(x: currentPosition7.width, y: currentPosition7.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition7 = CGSize(width: value.translation.width + newPosition7.width, height: value.translation.height + newPosition7.height)
                            }
                            .onEnded { value in
                                currentPosition7 = CGSize(width: value.translation.width + newPosition7.width, height: value.translation.height + newPosition7.height)
                                newPosition7 = currentPosition7
                                
                                if currentPosition7.width  > (correctPosition7.width - delta) &&
                                    currentPosition7.width  < (correctPosition7.width + delta) &&
                                    currentPosition7.height > (correctPosition7.height - delta) &&
                                    currentPosition7.height < (correctPosition7.height + delta)
                                {
                                    currentPosition7.width  = correctPosition7.width
                                    currentPosition7.height = correctPosition7.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 8
     --------------------------
     */
    var puzzlePieceImage8: some View {
        return AnyView(
            Image(uiImage: puzzlePiece8)
                .offset(x: currentPosition8.width, y: currentPosition8.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition8 = CGSize(width: value.translation.width + newPosition8.width, height: value.translation.height + newPosition8.height)
                            }
                            .onEnded { value in
                                currentPosition8 = CGSize(width: value.translation.width + newPosition8.width, height: value.translation.height + newPosition8.height)
                                newPosition8 = currentPosition8
                                
                                if currentPosition8.width  > (correctPosition8.width - delta) &&
                                    currentPosition8.width  < (correctPosition8.width + delta) &&
                                    currentPosition8.height > (correctPosition8.height - delta) &&
                                    currentPosition8.height < (correctPosition8.height + delta)
                                {
                                    currentPosition8.width  = correctPosition8.width
                                    currentPosition8.height = correctPosition8.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
    /*
     --------------------------
     MARK: Puzzle Piece Image 9
     --------------------------
     */
    var puzzlePieceImage9: some View {
        return AnyView(
            Image(uiImage: puzzlePiece9)
                .offset(x: currentPosition9.width, y: currentPosition9.height)
            
                .gesture(DragGesture()
                            .onChanged { value in
                                currentPosition9 = CGSize(width: value.translation.width + newPosition9.width, height: value.translation.height + newPosition9.height)
                            }
                            .onEnded { value in
                                currentPosition9 = CGSize(width: value.translation.width + newPosition9.width, height: value.translation.height + newPosition9.height)
                                newPosition9 = currentPosition9
                                
                                if currentPosition9.width  > (correctPosition9.width - delta) &&
                                    currentPosition9.width  < (correctPosition9.width + delta) &&
                                    currentPosition9.height > (correctPosition9.height - delta) &&
                                    currentPosition9.height < (correctPosition9.height + delta)
                                {
                                    currentPosition9.width  = correctPosition9.width
                                    currentPosition9.height = correctPosition9.height
                                    clickSoundAudioPlayer!.play()
                                    checkIfGameEnded()
                                }
                            }
                        )   // End of gesture
        )   // End of AnyView
    }   // End of var
    
}
