//
//  JigsawPuzzleList.swift
//  Diary
//
//  Created by Tyler Mills and Osman Balci on 4/23/22.
//  Copyright © 2022 Team 2. All rights reserved.
//

import SwiftUI

struct JigsawPuzzleList: View {
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ✳️ Core Data FetchRequest returning all Diary entities from the database
    @FetchRequest(fetchRequest: Diary.allDiariesFetchRequest()) var allDiaries: FetchedResults<Diary>
    
    var body: some View {
        
        NavigationView {
            List {
                ForEach(allDiaries) { aDiary in
                    if ((aDiary.photo?.photoData ?? nil) != nil) {
                        NavigationLink(destination: JigsawPuzzle(diary: aDiary)) {
                            JigsawPuzzleItem(diary: aDiary)
                        }
                    }
                    else if (!(aDiary.photo?.photoUrl ?? "").isEmpty) {
                        NavigationLink(destination: JigsawPuzzle(diary: aDiary)) {
                            JigsawPuzzleItem(diary: aDiary)
                        }
                    }
                }
            }
            .navigationBarTitle(Text("Jigsaw Puzzles"), displayMode: .inline)
        }   // End of NavigationView
        .navigationViewStyle(StackNavigationViewStyle())
        
    }   // End of body
}

struct JigsawPuzzleList_Previews: PreviewProvider {
    static var previews: some View {
        JigsawPuzzleList()
    }
}
