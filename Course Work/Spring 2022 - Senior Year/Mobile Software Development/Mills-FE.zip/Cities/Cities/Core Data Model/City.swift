//
//  City.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data City entity public class
public class City: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var name: String?
    @NSManaged public var country: String?
    @NSManaged public var definition: String?
    @NSManaged public var population: NSNumber?
    @NSManaged public var latitude: NSNumber?
    @NSManaged public var longitude: NSNumber?
    @NSManaged public var cityWebsiteUrl: String?
    @NSManaged public var countryFlagImageUrl: String?
    
    // Relationships
    @NSManaged public var photo: Photo?
}

extension City {
    /*
     ❎ CoreData @FetchRequest in FavoritesList.swift invokes this class method
        to fetch all of the City entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as City.allCitiesFetchRequest() in any .swift file in your project.
     */
    static func allCitiesFetchRequest() -> NSFetchRequest<City> {
        /*
         Create a fetchRequest to fetch City entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the City entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<City>(entityName: "City")
        /*
         List the fetched cities in alphabetical order with respect to city name.
         */
        fetchRequest.sortDescriptors = [
            // Sort key: city name
            NSSortDescriptor(key: "name", ascending: true),
        ]
        
        return fetchRequest
    }

}

