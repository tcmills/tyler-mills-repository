//
//  Photo.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Photo entity public class
public class Photo: NSManagedObject, Identifiable {

    // Attribute
    @NSManaged public var cityPhoto: Data?    // 'Binary Data' type
    
    // Relationship
    @NSManaged public var city: City?
}
