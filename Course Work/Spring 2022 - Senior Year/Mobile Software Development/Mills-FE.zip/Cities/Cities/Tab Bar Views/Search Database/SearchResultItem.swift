//
//  SearchResultItem.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/28/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchResultItem: View {
    
    // ❎ Input parameter: Core Data City Entity instance reference
    let city: City
    
    var body: some View {
        HStack {
            // This public function is given in UtilityFunctions.swift
            getImageFromBinaryData(binaryData: city.photo?.cityPhoto!, defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80.0)
            
            VStack(alignment: .leading) {
                /*
                ?? is called nil coalescing operator.
                IF city.name is not nil THEN
                    unwrap it and return its value
                ELSE return ""
                */
                Text(city.name ?? "")
                Text(city.country ?? "")
                Text(city.definition ?? "")
            }
            .font(.system(size: 14))
        }
    }
}
