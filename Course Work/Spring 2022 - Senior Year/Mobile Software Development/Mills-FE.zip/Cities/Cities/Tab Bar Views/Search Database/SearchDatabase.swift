//
//  SearchDatabase.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/28/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Global Variables
var searchCategory = ""
var searchQuery = ""

struct SearchDatabase: View {
    
    let searchCategoriesList = ["City Name Contains", "Country Name Contains", "City Definition Contains", "City Population ≥", "City Population <"]
    @State private var selectedSearchCategoryIndex = 2
    
    @State private var searchFieldValue = ""
    @State private var searchCompleted = false
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            Form {
                Section(header: Text("Select a Search Category")) {
                   
                    Picker("", selection: $selectedSearchCategoryIndex) {
                        ForEach(0 ..< searchCategoriesList.count, id: \.self) {
                            Text(searchCategoriesList[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                   
                }
                Section(header: Text("Search Query under Selected Category")) {
                    HStack {
                        TextField("Enter Search Query", text: $searchFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .frame(minWidth: 260, maxWidth: 500, alignment: .leading)
                       
                        // Button to clear the text field
                        Button(action: {
                            searchFieldValue = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }   // End of HStack
                }
                Section(header: Text("Search Database")) {
                    HStack {
                        Button(action: {
                            if inputDataValidated() {
                                searchDB()
                                searchCompleted = true
                            } else {
                                showAlertMessage = true
                                alertTitle = "Unrecognized Input Data!"
                                alertMessage = "Please enter a valid database search query!"
                            }
                        }) {
                            Text(searchCompleted ? "Search Completed" : "Search")
                        }
                        .frame(width: 240, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                }
                if searchCompleted {
                    Section(header: Text("List Cities Found")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("List Cities Found")
                                    .font(.system(size: 16))
                            }
                        }
                        .frame(minWidth: 300, maxWidth: 500)
                    }
                    Section(header: Text("Clear")) {
                        HStack {
                            Button(action: {
                                searchCompleted = false
                                searchFieldValue = ""
                            }) {
                                Text("Clear")
                            }
                            .frame(width: 120, height: 36, alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .strokeBorder(Color.black, lineWidth: 1)
                            )
                        }
                    }
                }
            
            }   // End of Form
            .navigationBarTitle(Text("Search Database"), displayMode: .inline)
            .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                  Button("OK") {}
                }, message: {
                  Text(alertMessage)
                })
                
            }   // End of ZStack
            
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body var
    
    /*
     ---------------------
     MARK: Search Database
     ---------------------
     */
    func searchDB() {
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // searchCategory and searchQuery are global search parameters defined on top of this file

        searchCategory = searchCategoriesList[selectedSearchCategoryIndex]
        searchQuery = queryTrimmed

        // Public function conductDatabaseSearch is given in DatabaseSearch.swift
        conductDatabaseSearch()
    }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array databaseSearchResults is given in DatabaseSearch.swift
        if databaseSearchResults.isEmpty {
            return AnyView(NotFound(message: "Database Search Produced No Results!\n\nThe database did not return any value for the given search query!"))
        }
        
        return AnyView(SearchResultsList())
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if (queryTrimmed.isEmpty) {
            return false
        }
        
        if selectedSearchCategoryIndex == 3 || selectedSearchCategoryIndex == 4 {
            
            if let _ = Int(queryTrimmed) {
                // Entered value is valid integer
            } else {
                return false
            }

        }
        
        return true
    }
}

struct SearchDatabase_Previews: PreviewProvider {
    static var previews: some View {
        SearchDatabase()
    }
}
