//
//  DatabaseSearch.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/28/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Global variable
var databaseSearchResults = [City]()

fileprivate let managedObjectContext: NSManagedObjectContext = PersistenceController.shared.persistentContainer.viewContext

/*
 =====================
 MARK: Search Database
 =====================
 */
public func conductDatabaseSearch() {
    
    // Initialize the array of City structs
    databaseSearchResults = [City]()
    
    switch searchCategory {
    case "City Name Contains":
        searchName()
    case "Country Name Contains":
        searchCountry()
    case "City Definition Contains":
        searchDefinition()
    case "City Population ≥":
        searchPopulationGTE()
    case "City Population <":
        searchPopulationLT()
    default:
        print("Search category is out of range!")
    }
    
}

/*
 ======================
 MARK: Search City Name
 ======================
 */
public func searchName() {

    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<City>(entityName: "City")
    
    fetchRequest.sortDescriptors = [
        // Primary sort key: name
        NSSortDescriptor(key: "name", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    fetchRequest.predicate = NSPredicate(format: "name CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for City name failed!")
    }
}

/*
 =========================
 MARK: Search Country Name
 =========================
 */
public func searchCountry() {

    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<City>(entityName: "City")
    
    fetchRequest.sortDescriptors = [
        // Primary sort key: name
        NSSortDescriptor(key: "name", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    fetchRequest.predicate = NSPredicate(format: "country CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Country name failed!")
    }
}

/*
 ============================
 MARK: Search City Definition
 ============================
 */
public func searchDefinition() {

    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<City>(entityName: "City")
    
    fetchRequest.sortDescriptors = [
        // Primary sort key: name
        NSSortDescriptor(key: "name", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    fetchRequest.predicate = NSPredicate(format: "definition CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for City definition failed!")
    }
}

/*
 ==============================
 MARK: Search City Population ≥
 ==============================
 */
public func searchPopulationGTE() {

    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<City>(entityName: "City")
    
    fetchRequest.sortDescriptors = [
        // Primary sort key: name
        NSSortDescriptor(key: "name", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // City population ≥ Integer value of searchQuery
    fetchRequest.predicate = NSPredicate(format: "population >= %i", Int(searchQuery)!)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for City Population ≥ failed!")
    }
}

/*
 ==============================
 MARK: Search City Population <
 ==============================
 */
public func searchPopulationLT() {

    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<City>(entityName: "City")
    
    fetchRequest.sortDescriptors = [
        // Primary sort key: name
        NSSortDescriptor(key: "name", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // City population < Integer value of searchQuery
    fetchRequest.predicate = NSPredicate(format: "population < %i", Int(searchQuery)!)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for City Population < failed!")
    }
}
