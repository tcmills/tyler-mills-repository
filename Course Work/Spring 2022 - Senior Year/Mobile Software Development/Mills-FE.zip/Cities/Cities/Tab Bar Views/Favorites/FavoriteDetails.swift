//
//  FavoriteDetails.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/28/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import MapKit

struct FavoriteDetails: View {
    
    // ❎ Input parameter: Core Data City Entity instance reference
    let city: City
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        Form {
            /*
            ?? is called nil coalescing operator.
            IF city.name is not nil THEN
                unwrap it and return its value
            ELSE return ""
            */
            Section(header: Text("City Name")) {
                Text(city.name ?? "")
            }
            Section(header: Text("City Photo")) {
                // This public function is given in UtilityFunctions.swift
                getImageFromBinaryData(binaryData: city.photo!.cityPhoto!, defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 500, alignment: .center)
            }
            Section(header: Text("Definition (Type of City)")) {
                Text(city.definition ?? "")
            }
            Section(header: Text("Country Name")) {
                Text(city.country ?? "")
            }
            Section(header: Text("Country Flag")) {
                getImageFromUrl(url: city.countryFlagImageUrl ?? "", defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(minWidth: 300, maxWidth: 320, alignment: .center)
            }
            Section(header: Text("City Population")) {
                Text(addThousandSeparators(nsNumber: city.population ?? 0 as NSNumber))
            }
            Section(header: Text("City Map"), footer: Text("City Map Provided by Apple Maps").italic()) {
                NavigationLink(destination: locationMap) {
                    HStack {
                        Image(systemName: "map.fill")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("Show City Map")
                            .font(.system(size: 16))
                    }
                    .frame(minWidth: 300, maxWidth: 500, alignment: .leading)
                    .foregroundColor(.blue)
                }
            }
            Section(header: Text("City Website")) {
                // Show city's website externally in default web browser
                Link(destination: URL(string: city.cityWebsiteUrl ?? "")!) {
                    HStack {
                        Image(systemName: "globe")
                            .imageScale(.medium)
                            .font(Font.title.weight(.regular))
                        Text("Show City Website")
                            .font(.system(size: 16))
                    }
                    .foregroundColor(.blue)
                }
            }

        }   // End of Form
        .navigationBarTitle(Text("City Details"), displayMode: .inline)
        .font(.system(size: 14))
        
    }   // End of body var
    
    //---------------------
    // City Location on Map
    //---------------------
    var locationMap: some View {
        
        let lat = city.latitude as! Double
        let long = city.longitude as! Double
        
        return AnyView(MapView(mapType: MKMapType.standard, latitude: lat, longitude: long, delta: 1, deltaUnit: "degrees", annotationTitle: city.name ?? "", annotationSubtitle: city.country ?? "")
                .navigationBarTitle(Text(city.name ?? ""), displayMode: .inline))
    }
    
}

