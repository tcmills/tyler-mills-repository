//
//  FavoritesList.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/28/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

struct FavoritesList: View {
    
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all city entities in the database
    @FetchRequest(fetchRequest: City.allCitiesFetchRequest()) var allCities: FetchedResults<City>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        NavigationView {
            List {
                /*
                 Each NSManagedObject has internally assigned unique ObjectIdentifier
                 used by ForEach to display the cities in a dynamic scrollable list.
                 */
                ForEach(allCities) { aCity in
                    NavigationLink(destination: FavoriteDetails(city: aCity)) {
                        FavoriteItem(city: aCity)
                    }
                }
                .onDelete(perform: delete)
                
            }   // End of List
            .navigationBarTitle(Text("Favorites"), displayMode: .inline)
            
            // Place the Edit button on left and Add (+) button on right of the navigation bar
            .navigationBarItems(leading: EditButton(), trailing:
                NavigationLink(destination: AddCity()) {
                    Image(systemName: "plus")
                })
            
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
    }
    
    /*
     --------------------------
     MARK: Delete Selected City
     --------------------------
     */
    func delete(at offsets: IndexSet) {
        
        let cityToDelete = allCities[offsets.first!]
        
        // ❎ Delete Selected City
        managedObjectContext.delete(cityToDelete)

        // ❎ Save Changes to Core Data Database
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
    }

}

struct FavoritesList_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesList()
    }
}
