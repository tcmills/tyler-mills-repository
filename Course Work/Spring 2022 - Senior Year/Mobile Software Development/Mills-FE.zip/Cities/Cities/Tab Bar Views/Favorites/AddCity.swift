//
//  AddCity.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/28/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

struct AddCity: View {
    
    // Enable this View to be dismissed to go back when the Save button is tapped
    @Environment(\.presentationMode) var presentationMode
    
    // ❎ CoreData managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //------------
    // City Entity
    //------------
    @State private var name = ""
    @State private var country = ""
    @State private var definition = ""
    @State private var population = ""
    @State private var latitudeTextFieldValue = "0.0"
    @State private var latitude = 0.0
    @State private var longitudeTextFieldValue = "0.0"
    @State private var longitude = 0.0
    @State private var cityWebsiteUrl = ""
    @State private var cca2 = ""
    
    //------------------
    // City Photo Entity
    //------------------
    @State private var showImagePicker = false
    @State private var photoImageData: Data? = nil
    @State private var useCamera = false
    @State private var usePhotoLibrary = true
    
    var body: some View {
        /*
         Create Binding between 'useCamera' and 'usePhotoLibrary' boolean @State variables so that only one of them can be true.
         get
            A closure that retrieves the binding value. The closure has no parameters.
         set
            A closure that sets the binding value. The closure has the following parameter:
            newValue stored in $0: The new value of 'useCamera' or 'usePhotoLibrary' boolean variable as true or false.
         
         Custom get and set closures are run when a newValue is obtained from the Toggle when it is turned on or off.
         */
        let camera = Binding(
            get: { useCamera },
            set: {
                useCamera = $0
                if $0 == true {
                    usePhotoLibrary = false
                }
            }
        )
        let photoLibrary = Binding(
            get: { usePhotoLibrary },
            set: {
                usePhotoLibrary = $0
                if $0 == true {
                    useCamera = false
                }
            }
        )
        
        Form {
            Group {
                Section(header: Text("City Name")) {
                    TextField("Enter city name", text: $name)
                }
                Section(header: Text("Country Name")) {
                    TextField("Enter country name", text: $country)
                }
                Section(header: Text("Definition (Type of City)")) {
                    TextField("Enter definition", text: $definition)
                }
                Section(header: Text("City Population")) {
                    TextField("Enter population", text: $population)
                }
                Section(header: Text("City Website URL")) {
                    TextField("Enter URL", text: $cityWebsiteUrl)
                }
                Section(header: Text("Country Code Alpha 2")) {
                    TextField("Enter 2-letter country code", text: $cca2)
                }
            }
            Group {
                Section(header: Text("Location Latitude")) {
                    TextField("Latitude", text: $latitudeTextFieldValue)
                        .keyboardType(.numbersAndPunctuation)
                        .onSubmit {
                            if let lat = Double(latitudeTextFieldValue) {
                                latitude = lat
                                // Latitude must be a number between -90 and 90
                                if ((latitude > -90.0) && (latitude < 90.0)) {
                                    // Valid latitude value
                                } else {
                                    showAlertMessage = true
                                    alertTitle = "Invalid Latitude Value!"
                                    alertMessage = "Valid latitude must be > -90.0 and < 90.0"
                                }
                            } else {
                                showAlertMessage = true
                                alertTitle = "Invalid Latitude Value!"
                                alertMessage = "Entered latitude value \(latitudeTextFieldValue) is not a number."
                            }
                        }
                }
                Section(header: Text("Location Longitude")) {
                    TextField("Longitude", text: $longitudeTextFieldValue)
                        .keyboardType(.numbersAndPunctuation)
                        .onSubmit {
                            if let long = Double(longitudeTextFieldValue) {
                                longitude = long
                                // Longitude must be a number between -180 and 180
                                if ((longitude > -180.0) && (longitude < 180.0)) {
                                    // Valid longitude value
                                } else {
                                    showAlertMessage = true
                                    alertTitle = "Invalid Longitude Value!"
                                    alertMessage = "Valid longitude must be > -180.0 and < 180.0"
                                }
                            } else {
                                showAlertMessage = true
                                alertTitle = "Invalid Longitude Value!"
                                alertMessage = "Entered longitude value \(longitudeTextFieldValue) is not a number."
                            }
                        }
                }
            }   // End of Group
                .keyboardType(.numbersAndPunctuation)
            Group {
                Section(header: Text("Take or Pick Photo")) {
                    VStack {
                        Toggle("Use Camera", isOn: camera)
                        Toggle("Use Photo Library", isOn: photoLibrary)
                        
                        Button(action: {
                            showImagePicker = true
                        }) {
                            Text("Get Photo")
                                .padding()
                        }
                    }   // End of VStack
                }
                Section(header: Text("Photo")) {
                    photoImageTakenOrPicked
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100.0, height: 100.0)
                }
            }   // End of Group

        }   // End of Form
        .textFieldStyle(RoundedBorderTextFieldStyle())
        .autocapitalization(.none)
        .disableAutocorrection(true)
        .font(.system(size: 14))
        .alert(alertTitle, isPresented: $showAlertMessage, actions: {
              Button("OK") {
                  if alertTitle == "City Added!" {
                      // Dismiss this Modal View and go back
                      presentationMode.wrappedValue.dismiss()
                  }
              }
            }, message: {
              Text(alertMessage)
            })
        .navigationBarTitle(Text("Add City"), displayMode: .inline)
        .navigationBarItems(trailing:
            Button(action: {
                if inputDataValidated() {
                    saveNewCity()
                    
                    showAlertMessage = true
                    alertTitle = "City Added!"
                    alertMessage = "New city is added to your favorites list!"
                } else {
                    showAlertMessage = true
                    alertTitle = "Missing Input Data!"
                    alertMessage = "All fields are required!"
                }
            }) {
                Text("Save")
            })
        
        .sheet(isPresented: $showImagePicker) {
            /*
             🔴 We pass $showImagePicker and $photoImageData with $ sign into PhotoCaptureView
             so that PhotoCaptureView can change them. The @Binding keywork in PhotoCaptureView
             indicates that the input parameter is passed by reference and is changeable (mutable).
             */
            PhotoCaptureView(showImagePicker: $showImagePicker,
                             photoImageData: $photoImageData,
                             cameraOrLibrary: useCamera ? "Camera" : "Photo Library")
        }
        
    }   // End of body var
    
    /*
    --------------------------------------------
    MARK: Photo Image Taken or Picked or Default
    --------------------------------------------
    */
    var photoImageTakenOrPicked: Image {
        
        if let imageData = photoImageData {
            // The public function is given in UtilityFunctions.swift
            let photo = getImageFromBinaryData(binaryData: imageData, defaultFilename: "ImageUnavailable")
            return photo
        } else {
            return Image("ImageUnavailable")
        }
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {

        if name.isEmpty || country.isEmpty || definition.isEmpty {
            return false
        }
        
        if let _ = Int(population) {
            // Entered value is valid integer
        } else {
            return false
        }
        
        if photoImageData == nil { return false }
        
        if latitude == 0.0 || longitude == 0.0 || cityWebsiteUrl.isEmpty || cca2.isEmpty {
            return false
        }
        
        return true
    }
    
    /*
     -------------------
     MARK: Save New City
     -------------------
     */
    func saveNewCity() {
        /*
         ============================
         *   City Entity Creation   *
         ============================
         */
        
        // 1️⃣ Create an instance of the City entity in managedObjectContext
        let cityEntity = City(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        cityEntity.name = name
        cityEntity.country = country
        cityEntity.definition = definition
        cityEntity.population = NSNumber(value: Int(population)!)
        cityEntity.latitude = latitude as NSNumber
        cityEntity.longitude = longitude as NSNumber
        cityEntity.cityWebsiteUrl = cityWebsiteUrl
        cityEntity.countryFlagImageUrl = "https://flagcdn.com/w320/\(cca2).png"
        
        // 3️⃣ Its relationship with another Entity is defined below
        
        /*
         =============================
         *   Photo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Photo Entity in managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Obtain the city photo image from the taken or picked photo
        let photoUIImage = UIImage(data: photoImageData!)
        
        /*
         City photo images have transparent backgrounds and therefore
         they are provided in the PNG format to preserve transparency.
         JPEG format cannot have transparency; therefore, PNG must be used.
         */
        
        // Convert photoUIImage to PNG data format
        if let data = photoUIImage?.pngData() {
            // Store PNG data into database attribute cityPhoto of type Binary Data
            photoEntity.cityPhoto = data
        } else {
            photoEntity.cityPhoto = nil
        }
        
        // 3️⃣ Establish one-to-one relationship between City and Photo
        cityEntity.photo = photoEntity         // A city can have only one photo
        photoEntity.city = cityEntity      // A photo can belong to only one city
        
        /*
         *************************************
         ❎ Save Changes to Core Data Database
         *************************************
         */
        
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
    }   // End of func saveNewCity

}
