//
//  AppDelegate.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        /*
        ******************************
        *   Create Cities Database   *
        ******************************
        */
        createCitiesDatabase()      // Given in CitiesData.swift
        
        return true
    }
}
