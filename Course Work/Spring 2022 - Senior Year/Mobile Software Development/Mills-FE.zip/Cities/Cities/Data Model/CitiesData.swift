//
//  CitiesData.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Array of CityStruct structs obtained from the JSON file
// for use only in this file to create the database
fileprivate var arrayOfCityStructs = [CityStruct]()

public func createCitiesDatabase() {

    // ❎ Get object reference of Core Data managedObjectContext from the persistent container
    let managedObjectContext = PersistenceController.shared.persistentContainer.viewContext
    
    //----------------------------
    // ❎ Define the Fetch Request
    //----------------------------
    let fetchRequest = NSFetchRequest<City>(entityName: "City")
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "name", ascending: true)]
    
    var listOfAllCityEntitiesInDatabase = [City]()
    
    do {
        //-----------------------------
        // ❎ Execute the Fetch Request
        //-----------------------------
        listOfAllCityEntitiesInDatabase = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("Database Creation Failed!")
        return
    }
    
    if listOfAllCityEntitiesInDatabase.count > 0 {
        print("Database has already been created!")
        return
    }
    
    print("Database will be created!")
    
    arrayOfCityStructs = decodeJsonFileIntoArrayOfStructs(fullFilename: "CitiesData.json", fileLocation: "Main Bundle")

    for aCity in arrayOfCityStructs {
        /*
         =============================
         *   City Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the City entity in managedObjectContext
        let cityEntity = City(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        cityEntity.name = aCity.name
        cityEntity.country = aCity.country
        cityEntity.definition = aCity.definition
        cityEntity.population = aCity.population as NSNumber
        cityEntity.latitude = aCity.latitude as NSNumber
        cityEntity.longitude = aCity.longitude as NSNumber
        cityEntity.cityWebsiteUrl = aCity.cityWebsiteUrl
        cityEntity.countryFlagImageUrl = aCity.countryFlagImageUrl
        
        // 3️⃣ Its relationship with another Entity is defined below
        
        /*
         =============================
         *   Photo Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Photo Entity in managedObjectContext
        let photoEntity = Photo(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attribute
        
        // Obtain the city photo image from Assets.xcassets as UIImage
        let photoUIImage = UIImage(named: aCity.cityPhotoFilename)
        
        /*
         City photo images have transparent backgrounds and therefore
         they are provided in the PNG format to preserve transparency.
         JPEG format cannot have transparency; therefore, PNG must be used.
         */
        
        // Convert photoUIImage to PNG data format
        if let data = photoUIImage?.pngData() {
            // Store PNG data into database attribute cityPhoto of type Binary Data
            photoEntity.cityPhoto = data
        } else {
            photoEntity.cityPhoto = nil
        }
        
        // 3️⃣ Establish one-to-one relationship between City and Photo
        cityEntity.photo = photoEntity         // A city can have only one photo
        photoEntity.city = cityEntity      // A photo can belong to only one city
        
        /*
         *************************************
         ❎ Save Changes to Core Data Database
         *************************************
         */
        
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
    }   // End of for loop

}
