//
//  CitiesStructs.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation

struct CityStruct: Decodable {
    
    var id: Int
    var name: String
    var cityPhotoFilename: String
    var country: String
    var definition: String
    var population: Int
    var latitude: Double
    var longitude: Double
    var cityWebsiteUrl: String
    var countryFlagImageUrl: String
}

/*
 {
     "id": 1,
     "name": "Tokyo",
     "cityPhotoFilename": "Tokyo",
     "country": "Japan",
     "definition": "Metropolis Prefecture",
     "population": 13515271,
     "latitude": 35.6897,
     "longitude": 139.6922,
     "cityWebsiteUrl": "https://www.metro.tokyo.lg.jp/english/",
     "countryFlagImageUrl": "https://flagcdn.com/w320/jp.png"
 }
 */
