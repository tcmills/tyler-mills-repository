//
//  ContentView.swift
//  Cities
//
//  Created by Tyler Mills and Osman Balci on 4/27/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

struct ContentView: View {

    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            FavoritesList()
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Favorites")
                }
            
            SearchDatabase()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search Database")
                }
            
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

