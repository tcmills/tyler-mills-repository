//
//  ApiCastStruct.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/17/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ApiCastStruct: Hashable, Codable, Identifiable {
    
    var id: UUID            // Storage Type: String, Use Type (format): UUID
    var character: String
    var name: String
    var profileFileName: String
}

/*
 {
     "id": "FC991AC2-CD4F-4A8B-96E3-89363CF55CF2",
     "character": "Jack Reacher",
     "name": "Tom Cruise",
     "profileFileName": "/3oWEuo0e8Nx8JvkqYCDec2iMY6K.jpg"
 }
 */
