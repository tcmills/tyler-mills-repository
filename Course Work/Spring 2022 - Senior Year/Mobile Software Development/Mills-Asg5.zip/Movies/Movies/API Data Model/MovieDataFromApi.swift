//
//  MovieDataFromApi.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import SwiftUI
 
// Global array of Movie structs
var movieSearchResults = [ApiMovieStruct]()
 
let myTMDbApiKey = "5d25ee4960272e915d80e0eb15faf9a3"
 
/*
*********************************************
MARK: - Obtain Movies Now Playing in Theaters
*********************************************
*/
public func getMovieSearchResultsFromApi(query: String) {
 
    // Initialize the array as an empty list
    movieSearchResults = [ApiMovieStruct]()
 
    let movieApiUrl = "https://api.themoviedb.org/3/search/movie?api_key=\(myTMDbApiKey)&query=\(query)"
    
    // The function is given in ApiData.swift
    let jsonDataFromApi = getJsonDataFromApi(apiUrl: movieApiUrl)
 
    //------------------------------------------------
    // JSON data is obtained from the API. Process it.
    //------------------------------------------------
 
    do {
        /*
        Foundation framework’s JSONSerialization class is used to convert JSON data
        into Swift data types such as Dictionary, Array, String, Number, or Bool.
        */
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!,
                         options: JSONSerialization.ReadingOptions.mutableContainers)

        /*
        JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
        Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
        where Dictionary Key type is String and Value type is Any (instance of any type)
        */
        var jsonDataDictionary = Dictionary<String, Any>()
         
        if let jsonObject = jsonResponse as? [String: Any] {
            jsonDataDictionary = jsonObject
        } else {
            return
        }
        
        //---------------------------------------
        // Obtain Array of "results" JSON Objects
        //---------------------------------------
        var arrayOfHitsJsonObjects = Array<Any>()
        
        if let jsonArray = jsonDataDictionary["results"] as? [Any] {
            arrayOfHitsJsonObjects = jsonArray
        } else {
            // foundRecipesList will be empty
            return
        }
        
        for index in 0..<arrayOfHitsJsonObjects.count {
            
            //-------------------------
            // Obtain Movie Dictionary
            //-------------------------
            var movieDictionary = Dictionary<String, Any>()
            
            if let jsonDictionary = arrayOfHitsJsonObjects[index] as? [String: Any] {
                movieDictionary = jsonDictionary
            } else {
                // movieSearchResults will be empty
                return
            }
            
            //*******************
            // Obtain Movie Title
            //*******************
            
            var movieTitle = ""
            /*
             IF movieDictionary["title"] has a value AND the value is of type String THEN
             unwrap the value and assign it to local variable movieTitle
             ELSE leave movieTitle as set to ""
             */
            if let titleOfMovie = movieDictionary["title"] as! String? {
                movieTitle = titleOfMovie
            }
            
            //*************************
            // Obtain Movie Poster Path
            //*************************
            
            var moviePosterPath = ""
            /*
             IF movieDictionary["poster_path"] has a value AND the value is of type String THEN
             unwrap the value and assign it to local variable moviePosterPath
             ELSE leave moviePosterPath as set to ""
             */
            if let posterPathOfMovie = movieDictionary["poster_path"] as? String? {
                moviePosterPath = posterPathOfMovie ?? ""
            }
            
            //**********************
            // Obtain Movie Overview
            //**********************
            
            var movieOverview = ""
            /*
             IF movieDictionary["overview"] has a value AND the value is of type String THEN
             unwrap the value and assign it to local variable movieOverview
             ELSE leave movieOverview as set to ""
             */
            if let overviewOfMovie = movieDictionary["overview"] as! String? {
                movieOverview = overviewOfMovie
            }
            
            //**************************
            // Obtain Movie Release Date
            //**************************
            
            var movieReleaseDate = ""
            /*
             IF movieDictionary["release_date"] has a value AND the value is of type String THEN
             unwrap the value and assign it to local variable movieReleaseDate
             ELSE leave movieReleaseDate as set to ""
             */
            if let releaseDateOfMovie = movieDictionary["release_date"] as! String? {
                movieReleaseDate = releaseDateOfMovie
            }
            
            //*********************
            // Obtain Movie TMDb ID
            //*********************
            
            var movieTmdbId = 0
            /*
             IF movieDictionary["id"] has a value AND the value is of type Int THEN
             unwrap the value and assign it to local variable movieTmdbId
             ELSE leave movieTmdbId as set to 0
             */
            if let tmdbIdOfMovie = movieDictionary["id"] as! Int? {
                movieTmdbId = tmdbIdOfMovie
            }
            
            let movieApiUrlVideo = "https://api.themoviedb.org/3/movie/\(movieTmdbId)?api_key=\(myTMDbApiKey)&append_to_response=videos"
            
            // The function is given in ApiData.swift
            let jsonDataFromApiVideo = getJsonDataFromApi(apiUrl: movieApiUrlVideo)
         
            //------------------------------------------------
            // JSON data is obtained from the API. Process it.
            //------------------------------------------------
         
            do {
                /*
                Foundation framework’s JSONSerialization class is used to convert JSON data
                into Swift data types such as Dictionary, Array, String, Number, or Bool.
                */
                let jsonResponseVideo = try JSONSerialization.jsonObject(with: jsonDataFromApiVideo!,
                                 options: JSONSerialization.ReadingOptions.mutableContainers)

                /*
                JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
                Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
                where Dictionary Key type is String and Value type is Any (instance of any type)
                */
                var jsonDataDictionaryVideo = Dictionary<String, Any>()
                 
                if let jsonObjectVideo = jsonResponseVideo as? [String: Any] {
                    jsonDataDictionaryVideo = jsonObjectVideo
                } else {
                    return
                }
                
                //*********************
                // Obtain Movie IMDB ID
                //*********************
                
                var movieImdbId = ""
                /*
                 IF jsonDataDictionaryVideo["imdb_id"] has a value AND the value is of type String THEN
                 unwrap the value and assign it to local variable movieImdbId
                 ELSE leave movieImdbId as set to ""
                 */
                if let imdbIdOfMovie = jsonDataDictionaryVideo["imdb_id"] as? String? {
                    movieImdbId = imdbIdOfMovie ?? ""
                }
                
                //*********************
                // Obtain Movie Runtime
                //*********************
                
                var movieRuntime = 0
                /*
                 IF jsonDataDictionaryVideo["runtime"] has a value AND the value is of type Int THEN
                 unwrap the value and assign it to local variable movieRuntime
                 ELSE leave movieRuntime as set to 0
                 */
                if let runtimeOfMovie = jsonDataDictionaryVideo["runtime"] as! Int? {
                    movieRuntime = runtimeOfMovie
                }
                
                //********************************
                // Obtain Movie YouTube Trailer Id
                //********************************
                
                var movieTrailerId = ""
                /*
                 IF jsonDataDictionaryVideo["videos"] has a value AND the value is of type [String: Any] THEN
                 unwrap the value and assign it to local variable movieTrailerId
                 ELSE leave movieTrailerId as set to ""
                 */
                if let videosJsonObject = jsonDataDictionaryVideo["videos"] as? [String: Any] {
                    
                    var arrayOfHitsJsonObjectsVideo = Array<Any>()
                    
                    if let jsonArrayVideo = videosJsonObject["results"] as? [Any] {
                        arrayOfHitsJsonObjectsVideo = jsonArrayVideo
                        if arrayOfHitsJsonObjectsVideo.isEmpty {
                            return
                        }
                    } else {
                        return
                    }
                    
                    //------------------------
                    // Obtain Video Dictionary
                    //------------------------
                    var movieDictionaryVideo = Dictionary<String, Any>()
                    
                    if let jsonDictionaryVideo = arrayOfHitsJsonObjectsVideo[0] as? [String: Any] {
                        movieDictionaryVideo = jsonDictionaryVideo
                    } else {
                        return
                    }
                    
                    if let key = movieDictionaryVideo["key"] as? String {
                        movieTrailerId = key
                    }
                    
                }
                
                let movieApiUrlData = "https://www.omdbapi.com/?apikey=9f67dd7a&i=\(movieImdbId )&plot=full&r=json"
                
                // The function is given in ApiData.swift
                let jsonDataFromApiData = getJsonDataFromApi(apiUrl: movieApiUrlData)
             
                //------------------------------------------------
                // JSON data is obtained from the API. Process it.
                //------------------------------------------------
             
                do {
                    /*
                    Foundation framework’s JSONSerialization class is used to convert JSON data
                    into Swift data types such as Dictionary, Array, String, Number, or Bool.
                    */
                    let jsonResponseData = try JSONSerialization.jsonObject(with: jsonDataFromApiData!,
                                     options: JSONSerialization.ReadingOptions.mutableContainers)

                    /*
                    JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
                    Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
                    where Dictionary Key type is String and Value type is Any (instance of any type)
                    */
                    var jsonDataDictionaryData = Dictionary<String, Any>()
                     
                    if let jsonObjectData = jsonResponseData as? [String: Any] {
                        jsonDataDictionaryData = jsonObjectData
                    } else {
                        return
                    }
                    
                    //*************************
                    // Obtain Movie MPAA Rating
                    //*************************
                    
                    var movieMpaaRating = ""
                    /*
                     IF jsonDataDictionaryData["Rated"] has a value AND the value is of type String THEN
                     unwrap the value and assign it to local variable movieMpaaRating
                     ELSE leave movieMpaaRating as set to ""
                     */
                    if let ratingOfMovie = jsonDataDictionaryData["Rated"] as! String? {
                        movieMpaaRating = ratingOfMovie
                    }
                    
                    //*******************
                    // Obtain Movie Genre
                    //*******************
                    
                    var movieGenre = ""
                    /*
                     IF jsonDataDictionaryData["Genre"] has a value AND the value is of type String THEN
                     unwrap the value and assign it to local variable movieGenre
                     ELSE leave movieGenre as set to ""
                     */
                    if let genreOfMovie = jsonDataDictionaryData["Genre"] as! String? {
                        movieGenre = genreOfMovie
                    }
                    
                    //**********************
                    // Obtain Movie Director
                    //**********************
                    
                    var movieDirector = ""
                    /*
                     IF jsonDataDictionaryData["Director"] has a value AND the value is of type String THEN
                     unwrap the value and assign it to local variable movieDirector
                     ELSE leave movieDirector as set to ""
                     */
                    if let directorOfMovie = jsonDataDictionaryData["Director"] as! String? {
                        movieDirector = directorOfMovie
                    }
                    
                    //********************
                    // Obtain Movie Actors
                    //********************
                    
                    var movieActors = ""
                    /*
                     IF jsonDataDictionaryData["Actors"] has a value AND the value is of type String THEN
                     unwrap the value and assign it to local variable movieActors
                     ELSE leave movieActors as set to ""
                     */
                    if let actorsOfMovie = jsonDataDictionaryData["Actors"] as! String? {
                        movieActors = actorsOfMovie
                    }
                    
                    //*************************
                    // Obtain Movie IMDB Rating
                    //*************************
                    
                    var movieImdbRating = ""
                    /*
                     IF jsonDataDictionaryData["imdbRating"] has a value AND the value is of type String THEN
                     unwrap the value and assign it to local variable movieImdbRating
                     ELSE leave movieImdbRating as set to ""
                     */
                    if let imdbRatingOfMovie = jsonDataDictionaryData["imdbRating"] as! String? {
                        movieImdbRating = imdbRatingOfMovie
                    }
                    
                    //-------------------------------------------------------------------------
                    // Create an Instance of ApiMovieStruct and Append it to movieSearchResults
                    //-------------------------------------------------------------------------
          
                    let foundMovie = ApiMovieStruct(id: UUID(), title: movieTitle, posterFileName: String(moviePosterPath.dropFirst(1)), overview: movieOverview, genres: movieGenre, releaseDate: movieReleaseDate, runtime: movieRuntime, director: movieDirector, actors: movieActors, mpaaRating: movieMpaaRating, imdbRating: movieImdbRating, youTubeTrailerId: movieTrailerId, tmdbID: movieTmdbId)
                    
                    movieSearchResults.append(foundMovie)
                    
                } catch {
                    return
                }
                
            } catch {
                return
            }
            
        }

    } catch {
        return
    }
    
}
