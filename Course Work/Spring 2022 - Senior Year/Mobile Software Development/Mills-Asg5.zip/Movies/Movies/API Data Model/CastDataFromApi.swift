//
//  CastDataFromApi.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/17/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import SwiftUI
 
// Global array of Cast structs
var castSearchResults = [ApiCastStruct]()
 
/*
**************************************
MARK: - Obtain Cast for specific Movie
**************************************
*/
public func getCastSearchResultsFromApi(query: String) {
 
    // Initialize the array as an empty list
    castSearchResults = [ApiCastStruct]()
 
    let movieApiUrl = "https://api.themoviedb.org/3/search/movie?api_key=\(myTMDbApiKey)&query=\(query)"
    
    // The function is given in ApiData.swift
    let jsonDataFromApi = getJsonDataFromApi(apiUrl: movieApiUrl)
 
    //------------------------------------------------
    // JSON data is obtained from the API. Process it.
    //------------------------------------------------
 
    do {
        /*
        Foundation framework’s JSONSerialization class is used to convert JSON data
        into Swift data types such as Dictionary, Array, String, Number, or Bool.
        */
        let jsonResponse = try JSONSerialization.jsonObject(with: jsonDataFromApi!,
                         options: JSONSerialization.ReadingOptions.mutableContainers)

        /*
        JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
        Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
        where Dictionary Key type is String and Value type is Any (instance of any type)
        */
        var jsonDataDictionary = Dictionary<String, Any>()
         
        if let jsonObject = jsonResponse as? [String: Any] {
            jsonDataDictionary = jsonObject
        } else {
            return
        }
        
        //---------------------------------------
        // Obtain Array of "results" JSON Objects
        //---------------------------------------
        var arrayOfHitsJsonObjects = Array<Any>()
        
        if let jsonArray = jsonDataDictionary["results"] as? [Any] {
            arrayOfHitsJsonObjects = jsonArray
        } else {
            return
        }
        
        for index in 0..<arrayOfHitsJsonObjects.count {
            
            //-------------------------
            // Obtain Movie Dictionary
            //-------------------------
            var movieDictionary = Dictionary<String, Any>()
            
            if let jsonDictionary = arrayOfHitsJsonObjects[index] as? [String: Any] {
                movieDictionary = jsonDictionary
            } else {
                return
            }
            
            //*********************
            // Obtain Movie TMDb ID
            //*********************
            
            var movieTmdbId = 0
            /*
             IF movieDictionary["id"] has a value AND the value is of type Int THEN
             unwrap the value and assign it to local variable movieTmdbId
             ELSE leave movieTmdbId as set to 0
             */
            if let tmdbIdOfMovie = movieDictionary["id"] as! Int? {
                movieTmdbId = tmdbIdOfMovie
            }
            
            let movieApiUrlCast = "https://api.themoviedb.org/3/movie/\(movieTmdbId)?api_key=\(myTMDbApiKey)&append_to_response=credits"
            
            // The function is given in ApiData.swift
            let jsonDataFromApiCast = getJsonDataFromApi(apiUrl: movieApiUrlCast)
         
            //------------------------------------------------
            // JSON data is obtained from the API. Process it.
            //------------------------------------------------
         
            do {
                /*
                Foundation framework’s JSONSerialization class is used to convert JSON data
                into Swift data types such as Dictionary, Array, String, Number, or Bool.
                */
                let jsonResponseCast = try JSONSerialization.jsonObject(with: jsonDataFromApiCast!,
                                 options: JSONSerialization.ReadingOptions.mutableContainers)

                /*
                JSON object with Attribute-Value pairs corresponds to Swift Dictionary type with
                Key-Value pairs. Therefore, we use a Dictionary to represent a JSON object
                where Dictionary Key type is String and Value type is Any (instance of any type)
                */
                var jsonDataDictionaryCast = Dictionary<String, Any>()
                 
                if let jsonObjectCast = jsonResponseCast as? [String: Any] {
                    jsonDataDictionaryCast = jsonObjectCast
                } else {
                    return
                }
                
                //---------------------------------------
                // Obtain Array of "credits" JSON Objects
                //---------------------------------------
                if let creditsJsonObject = jsonDataDictionaryCast["credits"] as? [String: Any] {
                    
                    var arrayOfHitsJsonObjectsCast = Array<Any>()
                    
                    if let jsonArrayCast = creditsJsonObject["cast"] as? [Any] {
                        arrayOfHitsJsonObjectsCast = jsonArrayCast
                    } else {
                        return
                    }
                    
                    for indexCast in 0..<arrayOfHitsJsonObjectsCast.count {
                        
                        //-------------------------
                        // Obtain Cast Dictionary
                        //-------------------------
                        var movieDictionaryCast = Dictionary<String, Any>()
                        
                        if let jsonDictionaryCast = arrayOfHitsJsonObjectsCast[indexCast] as? [String: Any] {
                            movieDictionaryCast = jsonDictionaryCast
                        } else {
                            return
                        }
                        
                        //***********************
                        // Obtain Movie Character
                        //***********************
                        
                        var movieCharacter = ""
                        /*
                         IF movieDictionaryCast["character"] has a value AND the value is of type String THEN
                         unwrap the value and assign it to local variable movieCharacter
                         ELSE leave movieCharacter as set to ""
                         */
                        if let characterOfMovie = movieDictionaryCast["character"] as! String? {
                            movieCharacter = characterOfMovie
                        }
                        
                        //******************
                        // Obtain Actor Name
                        //******************
                        
                        var actorName = ""
                        /*
                         IF movieDictionaryCast["name"] has a value AND the value is of type String THEN
                         unwrap the value and assign it to local variable actorName
                         ELSE leave actorName as set to ""
                         */
                        if let nameOfActor = movieDictionaryCast["name"] as! String? {
                            actorName = nameOfActor
                        }
                        
                        //**************************
                        // Obtain Actor Profile Path
                        //**************************
                        
                        var actorProfilePath = ""
                        /*
                         IF movieDictionaryCast["profile_path"] has a value AND the value is of type String THEN
                         unwrap the value and assign it to local variable actorProfilePath
                         ELSE leave actorProfilePath as set to ""
                         */
                        if let profilePathOfActor = movieDictionaryCast["profile_path"] as? String? {
                            actorProfilePath = profilePathOfActor ?? ""
                        }
                        
                        //-----------------------------------------------------------------------
                        // Create an Instance of ApiCastStruct and Append it to castSearchResults
                        //-----------------------------------------------------------------------
              
                        let foundCast = ApiCastStruct(id: UUID(), character: movieCharacter, name: actorName, profileFileName: String(actorProfilePath.dropFirst(1)))
                        
                        castSearchResults.append(foundCast)
                    }
                }
                
            } catch {
                return
            }
            
        }

    } catch {
        return
    }
    
}
