//
//  ApiMovieStruct.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ApiMovieStruct: Hashable, Codable, Identifiable {
    
    var id: UUID            // Storage Type: String, Use Type (format): UUID
    var title: String
    var posterFileName: String
    var overview: String
    var genres: String
    var releaseDate: String
    var runtime: Int
    var director: String
    var actors: String
    var mpaaRating: String
    var imdbRating: String
    var youTubeTrailerId: String
    var tmdbID: Int
}

/*
 {
     "id": "FC991AC2-CD4F-4A8B-96E3-89363CE55CF2",
     "title": "Joker",
     "posterFileName": "udDclJoHjfjb8Ekgsd4FDteOkCU.jpg",
     "overview": "During the 1980s, a failed stand-up comedian is driven insane and turns to a life of crime and chaos in Gotham City while becoming an infamous psychopathic crime figure.",
     "genres": "Crime, Drama, Thriller",
     "releaseDate": "2019-10-04",
     "runtime": 122,
     "director": "Todd Phillips",
     "actors": "Joaquin Phoenix, Robert De Niro, Zazie Beetz, Frances Conroy",
     "mpaaRating": "R",
     "imdbRating": "9.1",
     "youTubeTrailerId": "xRjvmVaFHkk",
     "tmdbID": 475557
 }
 */
