//
//  ContentView.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/7/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            Home()
                .tabItem {
                    Image(systemName: "house")
                    Text("Home")
                }
            FavoritesList()
                .tabItem {
                    Image(systemName: "star.fill")
                    Text("Favorites")
            }
            SearchDatabase()
                .tabItem {
                    Image(systemName: "magnifyingglass")
                    Text("Search Database")
            }
            SearchApi()
                .tabItem {
                    Image(systemName: "magnifyingglass.circle")
                    Text("Search API")
            }
            Genres()
                .tabItem {
                    Image(systemName: "list.and.film")
                    Text("Genres")
            }
            
        }   // End of TabView
            .font(.headline)
            .imageScale(.medium)
            .font(Font.title.weight(.regular))
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
