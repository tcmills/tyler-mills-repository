//
//  Movie.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/7/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import Foundation
import CoreData

// ❎ Core Data Movie entity public class
public class Movie: NSManagedObject, Identifiable {

    // Attributes
    @NSManaged public var title: String?
    @NSManaged public var posterFileName: String?
    @NSManaged public var overview: String?
    @NSManaged public var genres: String?
    @NSManaged public var releaseDate: String?
    @NSManaged public var runtime: NSNumber?
    @NSManaged public var director: String?
    @NSManaged public var actors: String?
    @NSManaged public var mpaaRating: String?
    @NSManaged public var imdbRating: String?
    @NSManaged public var youTubeTrailerId: String?
    @NSManaged public var tmdbID: NSNumber?
}

extension Movie {
    /*
     ❎ CoreData @FetchRequest in FavoritesList.swift invokes this class method
        to fetch all of the Movie entities from the database.
        The 'static' keyword designates the func as a class method invoked by using the
        class name as Movie.allMoviesFetchRequest() in any .swift file in your project.
     */
    static func allMoviesFetchRequest() -> NSFetchRequest<Movie> {
        /*
         Create a fetchRequest to fetch Movie entities from the database.
         Since the fetchRequest's 'predicate' property is not set to filter,
         all of the Movie entities will be fetched.
         */
        let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
        /*
         List the fetched movies in alphabetical order with respect to movie name.
         */
        fetchRequest.sortDescriptors = [
            // Sort key: movie name
            NSSortDescriptor(key: "title", ascending: true),
        ]
        
        return fetchRequest
    }

}

