//
//  AppDelegate.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/7/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import UIKit

class AppDelegate: NSObject, UIApplicationDelegate {
    func application(_ application: UIApplication, didFinishLaunchingWithOptions
                     launchOptions: [UIApplication.LaunchOptionsKey: Any]?) -> Bool {
        
        /*
        ******************************
        *   Create Movies Database   *
        ******************************
        */
        createMoviesDatabase()      // Given in MoviesData.swift
        
        /*
        ************************************
        *   Get Currently Playing Movies   *
        ************************************
        */
        getCurrentlyPlayingSearchResultsFromApi()      // Given in CurrentlyPlayingDataFromApi.swift
        return true
    }
}
