//
//  Home.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

struct Home: View {
    
    // ✳️ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ✳️ Core Data FetchRequest returning all Movie entities from the database
    @FetchRequest(fetchRequest: Movie.allMoviesFetchRequest()) var allMovies: FetchedResults<Movie>
    
    @State private var index = 0
    /*
     Create a timer publisher that fires 'every' 3 seconds and updates the view.
     It runs 'on' the '.main' runloop so that it can update the view.
     It runs 'in' the '.common' mode so that it can run alongside other
     common events such as when the ScrollView is being scrolled.
     */
    @State private var timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    
    var body: some View {
        ZStack {
            Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            
        ScrollView(.vertical, showsIndicators: false) {
            VStack {
                Image("Welcome")
                    .padding(.top, 30)
                    .padding(.bottom, 20)
                
                /*
                 ------------------------------------------------------------------------
                 Show an image slider of the poster of all of the movies in the database.
                 ------------------------------------------------------------------------
                 */
                
                getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(allMovies[index].posterFileName!)", defaultFilename: "ImageUnavailable")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 400)
                    .padding()
                
                    // Subscribe to the timer publisher
                    .onReceive(timer) { _ in
                        index += 1
                        if index > allMovies.count - 1 {
                            index = 0
                        }
                    }
                
                // Movie title
                Text(allMovies[index].title ?? "")
                    .font(.headline)
                    // Allow lines to wrap around
                    .fixedSize(horizontal: false, vertical: true)
                    .multilineTextAlignment(.center)
                    .padding()
                
                // Show TMDb API provider's website externally in default web browser
                Link(destination: URL(string: "https://www.themoviedb.org")!, label: {
                    Image("tmdbAttribution")
                        .renderingMode(.original)   // To keep the image in its original form
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 60)
                })
                .padding()
                
                // Show OMDb API provider's website externally in default web browser
                Link(destination: URL(string: "https://www.omdbapi.com")!, label: {
                    Image("omdbAttribution")
                        .renderingMode(.original)   // To keep the image in its original form
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(height: 60)
                })
                .padding()
                
            }   // End of VStack
        }   // End of ScrollView
        .onAppear() {
            startTimer()
        }
        .onDisappear() {
            stopTimer()
        }

        }   // End of ZStack
    }   // End of var
    
    func startTimer() {
        timer = Timer.publish(every: 3, on: .main, in: .common).autoconnect()
    }
    
    func stopTimer() {
        timer.upstream.connect().cancel()
    }
    
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}

