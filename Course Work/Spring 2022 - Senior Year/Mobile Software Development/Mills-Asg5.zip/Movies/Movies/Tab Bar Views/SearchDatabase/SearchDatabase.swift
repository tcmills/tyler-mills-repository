//
//  SearchDatabase.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchDatabase: View {

    //-----------------
    // Search Variables
    //-----------------
    @State private var searchFieldValue = ""
    @State private var searchCompleted = false
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //------------------
    // Search Categories
    //------------------
    let searchCategories = ["Movie Title", "Movie Overview", "Movie Genres", "Movie Release Date", "Movie Director", "Movie Actors", "MPAA Rating", "IMDb Rating"]
    @State private var selectedIndex = 3
    
    var body: some View {
        NavigationView {
            ZStack {
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            Form {
                Section(header: Text("Select Search Category")) {
                    Picker("", selection: $selectedIndex) {
                        ForEach(0 ..< searchCategories.count, id: \.self) {
                            Text(searchCategories[$0])
                        }
                    }
                    .pickerStyle(WheelPickerStyle())
                    .frame(minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
                }
                Section(header: Text("Enter Search Query")) {
                    HStack {
                        TextField("Enter Search Query", text: $searchFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                            .autocapitalization(.none)
                            .frame(minWidth: 260, maxWidth: 500, alignment: .leading)
                       
                        // Button to clear the text field
                        Button(action: {
                            searchFieldValue = ""
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                    }   // End of HStack
                }
                Section(header: Text("Search Database")) {
                    HStack {
                        Button(action: {
                            if inputDataValidated() {
                                searchDB()
                                searchCompleted = true
                            } else {
                                showAlertMessage = true
                                alertTitle = "Missing Input Data!"
                                alertMessage = "Please enter a database search query!"
                            }
                        }) {
                            Text(searchCompleted ? "Search Completed" : "Search")
                        }
                        .frame(width: 240, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                }
                if searchCompleted {
                    Section(header: Text("List Movies Found")) {
                        NavigationLink(destination: showSearchResults) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("List Movies Found")
                                    .font(.system(size: 16))
                            }
                        }
                        .frame(minWidth: 300, maxWidth: 500)
                    }
                    Section(header: Text("Clear")) {
                        HStack {
                            Button(action: {
                                searchCompleted = false
                                searchFieldValue = ""
                            }) {
                                Text("Clear")
                            }
                            .frame(width: 120, height: 36, alignment: .center)
                            .background(
                                RoundedRectangle(cornerRadius: 16)
                                    .strokeBorder(Color.black, lineWidth: 1)
                            )
                        }
                    }
                }

            }   // End of Form
                .navigationBarTitle(Text("Search Database"), displayMode: .inline)
                .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                      Button("OK") {}
                    }, message: {
                      Text(alertMessage)
                    })
                
            }   // End of ZStack
            
        }   // End of NavigationView
            .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body var
    
    /*
     ---------------------
     MARK: Search Database
     ---------------------
     */
    func searchDB() {
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        // searchCategory and searchQuery are global search parameters defined in DatabaseSearch.swift
        
        searchCategory = searchCategories[selectedIndex]
        searchQuery = queryTrimmed

        // Public function conductDatabaseSearch is given in DatabaseSearch.swift
        conductDatabaseSearch()
    }
    
    /*
     -------------------------
     MARK: Show Search Results
     -------------------------
     */
    var showSearchResults: some View {
        
        // Global array databaseSearchResults is given in DatabaseSearch.swift
        if databaseSearchResults.isEmpty {
            return AnyView(NotFound(message: "Database Search Produced No Results!\n\nThe database did not return any value for the given search query!"))
        }
        
        return AnyView(SearchResultsList())
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if (queryTrimmed.isEmpty) {
            return false
        }
        
        return true
    }
    
}

struct SearchDatabase_Previews: PreviewProvider {
    static var previews: some View {
        SearchDatabase()
    }
}
