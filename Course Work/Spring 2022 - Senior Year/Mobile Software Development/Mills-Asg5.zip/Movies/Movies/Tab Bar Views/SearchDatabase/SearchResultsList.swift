//
//  SearchResultsList.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchResultsList: View {
    
    var body: some View {
        List {
            ForEach(databaseSearchResults) { aMovie in
                NavigationLink(destination: SearchResultDetails(movie: aMovie)) {
                    SearchResultItem(movie: aMovie)
                }
            }
        }
        .navigationBarTitle(Text("Movies Found in Database"), displayMode: .inline)
        
    }   // End of body
}

struct SearchResultsList_Previews: PreviewProvider {
    static var previews: some View {
        SearchResultsList()
    }
}
