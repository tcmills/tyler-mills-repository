//
//  DatabaseSearch.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Global Variable
var databaseSearchResults = [Movie]()

// Global Search Parameters
var searchCategory = ""
var searchQuery = ""

fileprivate let managedObjectContext: NSManagedObjectContext = PersistenceController.shared.persistentContainer.viewContext

/*
 =====================
 MARK: Search Database
 =====================
 */
public func conductDatabaseSearch() {
    
    // Initialize the array of Movie structs
    databaseSearchResults = [Movie]()
    
    switch searchCategory {
    case "Movie Title":
        searchMovieTitle()
    case "Movie Overview":
        searchMovieOverview()
    case "Movie Genres":
        searchMovieGenres()
    case "Movie Release Date":
        searchMovieReleaseDate()
    case "Movie Director":
        searchMovieDirector()
    case "Movie Actors":
        searchMovieActors()
    case "MPAA Rating":
        searchMPAARating()
    case "IMDb Rating":
        searchIMDbRating()
    default:
        print("Search category is out of range!")
    }
}

/*
 ========================
 MARK: Search Movie Title
 ========================
 */
public func searchMovieTitle() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie title contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "title CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie title failed!")
    }
}

/*
 ===========================
 MARK: Search Movie Overview
 ===========================
 */
public func searchMovieOverview() {
    
    // 1️⃣ Define the Fetch Request
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie overview contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "overview CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie overview failed!")
    }
}

/*
 =========================
 MARK: Search Movie Genres
 =========================
 */
public func searchMovieGenres() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie genres contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "genres CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie genres failed!")
    }
}

/*
 ===============================
 MARK: Search Movie Release Date
 ===============================
 */
public func searchMovieReleaseDate() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie release date contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "releaseDate CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie release date failed!")
    }
}

/*
 ===========================
 MARK: Search Movie Director
 ===========================
 */
public func searchMovieDirector() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie director contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "director CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie director failed!")
    }
}

/*
 =========================
 MARK: Search Movie Actors
 =========================
 */
public func searchMovieActors() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie actors contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "actors CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie actors failed!")
    }
}

/*
 ==============================
 MARK: Search Movie MPAA Rating
 ==============================
 */
public func searchMPAARating() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie mpaa rating contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "mpaaRating CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie mpaa rating failed!")
    }
}

/*
 ==============================
 MARK: Search Movie IMDb Rating
 ==============================
 */
public func searchIMDbRating() {
    
    // 1️⃣ Define the Fetch Request
    /*
     Create a fetchRequest to fetch Movie entities from the database.
     Since the fetchRequest's 'predicate' property is set to a NSPredicate condition,
     only those Movie entities satisfying the condition will be fetched.
     */
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    
    // List the fetched movies in alphabetical order with respect to movie title.
    fetchRequest.sortDescriptors = [
        // Sort key: movie title
        NSSortDescriptor(key: "title", ascending: true)
    ]
    
    // 2️⃣ Define the Search Criteria
    // Movie imdb rating contains searchQuery in case insensitive manner
    fetchRequest.predicate = NSPredicate(format: "imdbRating CONTAINS[c] %@", searchQuery)
    
    do {
        // 3️⃣ Execute the Fetch Request
        databaseSearchResults = try managedObjectContext.fetch(fetchRequest)
        
    } catch {
        print("fetchRequest for Movie imdb rating failed!")
    }
}
