//
//  FavoriteDetails.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct FavoriteDetails: View {
    
    // ✳️ Input parameter: Core Data Movie Entity instance reference
    let movie: Movie
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("Movie Title")) {
                    Text(movie.title ?? "")
                }
                Section(header: Text("Movie Poster")) {
                    getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName!)", defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 350)
                }
                Section(header: Text("YouTube Movie Trailer")) {
                    NavigationLink(destination: WebView(url: "http://www.youtube.com/embed/\(movie.youTubeTrailerId ?? "")")
                        .navigationBarTitle(Text("Play YouTube Video"), displayMode: .inline) )
                    {
                        HStack {
                            Image(systemName: "play.rectangle.fill")
                                .foregroundColor(.red)
                                .font(Font.title.weight(.regular))
                            Text("Play YouTube Movie Trailer")
                        }
                    }
                }
                Section(header: Text("Movie Overview")) {
                    Text(movie.overview ?? "")
                }
                Section(header: Text("List Movie Cast Members")) {
                    NavigationLink(destination: castData) {
                        HStack {
                            Image(systemName: "person.crop.rectangle.stack")
                                .foregroundColor(.blue)
                                .font(Font.title.weight(.regular))
                            Text("List Movie Cast Members")
                        }
                    }
                }
                Section(header: Text("Movie Runtime")) {
                    let hours = (movie.runtime as! Int) / 60
                    let minutes = (movie.runtime as! Int) - (hours * 60)
                    Text("\(hours) hours \(minutes) mins")
                }
                Section(header: Text("Movie Genres")) {
                    Text(movie.genres ?? "")
                }
                Section(header: Text("Movie Release Date")) {
                    Text(movie.releaseDate ?? "")
                }
                Section(header: Text("Movie Director")) {
                    Text(movie.director ?? "")
                }
                Section(header: Text("Movie Top Actors")) {
                    Text(movie.actors ?? "")
                }
            }
            Group {
                Section(header: Text("Movie MPAA Rating")) {
                    Text(movie.mpaaRating ?? "")
                }
                Section(header: Text("Movie IMDB Rating")) {
                    Text(movie.imdbRating ?? "")
                }
            }
            
        }   // End of Form
            .font(.system(size: 14))
            .navigationBarTitle(Text(movie.title ?? ""), displayMode: .inline)
        
    }   // End of body var
    
    var castData: some View {
        let querySpaceless = movie.title?.replacingOccurrences(of: " ", with: "+")
        getCastSearchResultsFromApi(query: querySpaceless ?? "")
        
        return CastList()
    }
    
}

