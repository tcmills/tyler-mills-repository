//
//  CastItem.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/17/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct CastItem: View {
    
    // ✳️ Input parameter: Core Data Movie Entity instance reference
    let cast: ApiCastStruct
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        HStack {
            getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(cast.profileFileName)", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 80.0)
            
            VStack(alignment: .leading) {
                Text(cast.name)
                Text("playing")
                Text(cast.character)
            }
            .font(.system(size: 14))
        }   // End of HStack
    }   // End of body
    
}
