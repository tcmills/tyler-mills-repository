//
//  FavoritesList.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

struct FavoritesList: View {
    
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all Movie entities from the database
    @FetchRequest(fetchRequest: Movie.allMoviesFetchRequest()) var allMovies: FetchedResults<Movie>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        NavigationView {
            List {
                /*
                 Each NSManagedObject has internally assigned unique ObjectIdentifier
                 used by ForEach to display the Movies in a dynamic scrollable list.
                 */
                ForEach(allMovies) { aMovie in
                    NavigationLink(destination: FavoriteDetails(movie: aMovie)) {
                        FavoriteItem(movie: aMovie)
                    }
                }
                .onDelete(perform: delete)
                
            }   // End of List
                .navigationBarTitle(Text("Favorites"), displayMode: .inline)
                
                // Place the Edit button on left
                .navigationBarItems(leading: EditButton())
            
        }   // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle
        
    }   // End of body
    
    /*
     ---------------------------
     MARK: Delete Selected Movie
     ---------------------------
     */
    func delete(at offsets: IndexSet) {
        
        let movieToDelete = allMovies[offsets.first!]
        
        // ❎ Delete Selected Movie
        managedObjectContext.delete(movieToDelete)
        
        // ❎ Save Changes to Core Data Database
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
        // Toggle database change indicator so that its subscribers can refresh their views
        databaseChange.indicator.toggle()
    }
    
}   // End of struct


struct FavoritesList_Previews: PreviewProvider {
    static var previews: some View {
        FavoritesList()
    }
}
