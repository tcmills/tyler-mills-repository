//
//  CastList.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/17/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct CastList: View {
    
    var body: some View {
        List {
            ForEach(castSearchResults) { aCast in
                CastItem(cast: aCast)
            }
        }
        
    }   // End of body
}

struct CastList_Previews: PreviewProvider {
    static var previews: some View {
        CastList()
    }
}
