//
//  SearchApi.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchApi: View {
    
    var body: some View {
        NavigationView {
            VStack {
                NavigationLink(destination: SearchMovies()) {
                    VStack {
                        Image("MovieSearch")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 300.0)
                        Text("Search Movies")
                            .font(.system(size: 16))
                            .foregroundColor(.blue)
                    }
                    .padding()
                }
                NavigationLink(destination: CurrentlyPlayingResultsList()) {
                    VStack {
                        Image("Cinema")
                            .resizable()
                            .aspectRatio(contentMode: .fit)
                            .frame(width: 300.0)
                        Text("List Movies Currently Playing in Theaters")
                            .font(.system(size: 16))
                            .foregroundColor(.blue)
                    }
                    .padding()
                }
            }  // End of VStack
        }  // End of NavigationView
        .customNavigationViewStyle()  // Given in NavigationStyle.swift
        
    }   // End of body
}

struct SearchApi_Previews: PreviewProvider {
    static var previews: some View {
        SearchApi()
    }
}
