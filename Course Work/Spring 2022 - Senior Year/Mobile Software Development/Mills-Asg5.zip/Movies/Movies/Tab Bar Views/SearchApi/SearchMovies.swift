//
//  SearchMovies.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct SearchMovies: View {
    
    //---------------
    // Alert Messages
    //---------------
    @State private var showAlertMessage = false
    @State private var alertTitle = ""
    @State private var alertMessage = ""
    
    //-----------------
    // Search Variables
    //-----------------
    @State private var searchFieldValue = ""
    @State private var searchCompleted = false
    
    var body: some View {
            Form {
                Section(header: Text("Enter Movie Title to Search")) {
                    HStack {
                        TextField("Enter Search Query", text: $searchFieldValue)
                            .textFieldStyle(RoundedBorderTextFieldStyle())
                            .disableAutocorrection(true)
                            .frame(width: 240, height: 36)
                        
                        // Button to clear the text field
                        Button(action: {
                            searchFieldValue = ""
                            showAlertMessage = false
                            searchCompleted = false
                        }) {
                            Image(systemName: "clear")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                        }
                        
                    }   // End of HStack
                }
                Section(header: Text("Search Movies")) {
                    HStack {
                        Button(action: {
                            if inputDataValidated() {
                                searchMovie()
                                searchCompleted = true
                            } else {
                                showAlertMessage = true
                                alertTitle = "Missing Input Data!"
                                alertMessage = "Please enter a search query!"
                            }
                        }) {
                            Text(searchCompleted ? "Search Completed" : "Search")
                        }
                        .frame(width: 240, height: 36, alignment: .center)
                        .background(
                            RoundedRectangle(cornerRadius: 16)
                                .strokeBorder(Color.black, lineWidth: 1)
                        )
                    }   // End of HStack
                }
                
                if searchCompleted {
                    Section(header: Text("List Movies Found")) {
                        NavigationLink(destination: showSearchResult) {
                            HStack {
                                Image(systemName: "list.bullet")
                                    .imageScale(.medium)
                                    .font(Font.title.weight(.regular))
                                    .foregroundColor(.blue)
                                Text("List Movies Found")
                                    .font(.system(size: 16))
                            }
                        }
                        .frame(minWidth: 300, maxWidth: 500)
                    }
                }
                
            }   // End of Form
                .navigationBarTitle(Text("Search Movies"), displayMode: .inline)
                .alert(alertTitle, isPresented: $showAlertMessage, actions: {
                    Button("OK") {}
                }, message: {
                    Text(alertMessage)
                })
        
    }   // End of body var
    
    func searchMovie() {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        //let queryLowercased = queryTrimmed.lowercased()
        
        let querySpaceless = queryTrimmed.replacingOccurrences(of: " ", with: "+")
        
        // Public function getMovieSearchResultsFromApi is given in MovieDataFromApi.swift
        getMovieSearchResultsFromApi(query: querySpaceless)
    }
    
    var showSearchResult: some View {
        
        if movieSearchResults.isEmpty {
            return AnyView(
                NotFound(message: "No Movie Found!\n\nThe entered query \(searchFieldValue) did not return any movie from the API! Please enter another search query.")
            )
        }
        
        return AnyView(ApiSearchResultsList())
    }
    
    /*
     ---------------------------
     MARK: Input Data Validation
     ---------------------------
     */
    func inputDataValidated() -> Bool {
        
        // Remove spaces, if any, at the beginning and at the end of the entered search query string
        let queryTrimmed = searchFieldValue.trimmingCharacters(in: .whitespacesAndNewlines)
        
        if queryTrimmed.isEmpty {
            return false
        }
        return true
    }
}

struct SearchMovies_Previews: PreviewProvider {
    static var previews: some View {
        SearchMovies()
    }
}
