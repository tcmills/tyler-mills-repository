//
//  ApiSearchResultsList.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ApiSearchResultsList: View {
    
    var body: some View {
        List {
            ForEach(movieSearchResults) { aMovie in
                NavigationLink(destination: ApiSearchResultDetails(movie: aMovie)) {
                    ApiSearchResultItem(movie: aMovie)
                }
            }
        }
        .navigationBarTitle(Text("Movies Found from the API"), displayMode: .inline)
        
    }   // End of body
}

struct ApiSearchResultsList_Previews: PreviewProvider {
    static var previews: some View {
        ApiSearchResultsList()
    }
}
