//
//  ApiSearchResultItem.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ApiSearchResultItem: View {
    
    // ✳️ Input parameter: Core Data Movie Entity instance reference
    let movie: ApiMovieStruct
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    var body: some View {
        HStack {
            getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName)", defaultFilename: "ImageUnavailable")
                .resizable()
                .aspectRatio(contentMode: .fit)
                .frame(width: 100.0)
            
            VStack(alignment: .leading) {
                Text(movie.title)
                HStack {
                    Image("IMDb")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 20.0)
                    Text(movie.imdbRating)
                }
                Text(movie.actors)
                HStack {
                    Text(movie.mpaaRating)
                    Text("\(movie.runtime) mins")
                }
                Text(movie.releaseDate)
            }
            .font(.system(size: 14))
        }
    }
    
}
