//
//  CurrentlyPlayingResultsList.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/17/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct CurrentlyPlayingResultsList: View {
    
    var body: some View {
        List {
            ForEach(currentlyPlayingSearchResults) { aMovie in
                NavigationLink(destination: CurrentlyPlayingResultDetails(movie: aMovie)) {
                    CurrentlyPlayingResultItem(movie: aMovie)
                }
            }
        }
        .navigationBarTitle(Text("Movies Found from the API"), displayMode: .inline)
        
    }   // End of body
}

struct CurrentlyPlayingResultsList_Previews: PreviewProvider {
    static var previews: some View {
        CurrentlyPlayingResultsList()
    }
}
