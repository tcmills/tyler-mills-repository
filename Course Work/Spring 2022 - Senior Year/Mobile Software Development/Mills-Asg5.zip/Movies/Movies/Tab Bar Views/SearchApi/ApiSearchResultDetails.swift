//
//  ApiSearchResultDetails.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/10/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI

struct ApiSearchResultDetails: View {
    
    // ✳️ Input parameter: Core Data Movie Entity instance reference
    let movie: ApiMovieStruct
    
    // Enable this View to be dismissed to go back when the "Add Movie To Database As Favorite" button is tapped
    @Environment(\.presentationMode) var presentationMode
    
    // ❎ CoreData managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
    
    @State private var showMovieAddedMessage = false
    
    var body: some View {
        Form {
            Group {
                Section(header: Text("Movie Title")) {
                    Text(movie.title)
                }
                Section(header: Text("Movie Poster")) {
                    getImageFromUrl(url: "https://image.tmdb.org/t/p/w500/\(movie.posterFileName)", defaultFilename: "ImageUnavailable")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 350)
                }
                Section(header: Text("YouTube Movie Trailer")) {
                    NavigationLink(destination: WebView(url: "http://www.youtube.com/embed/\(movie.youTubeTrailerId)")
                        .navigationBarTitle(Text("Play YouTube Video"), displayMode: .inline) )
                    {
                        HStack {
                            Image(systemName: "play.rectangle.fill")
                                .foregroundColor(.red)
                                .font(Font.title.weight(.regular))
                            Text("Play YouTube Movie Trailer")
                        }
                    }
                }
                Section(header: Text("Movie Overview")) {
                    Text(movie.overview)
                }
                Section(header: Text("List Movie Cast Members")) {
                    NavigationLink(destination: castData) {
                        HStack {
                            Image(systemName: "person.crop.rectangle.stack")
                                .foregroundColor(.blue)
                                .font(Font.title.weight(.regular))
                            Text("List Movie Cast Members")
                        }
                    }
                }
                Section(header: Text("Add Movie To Database As Favorite")) {
                    Button(action: {
                        /*
                         =============================
                         *   Movie Entity Creation   *
                         =============================
                         */
                        
                        // 1️⃣ Create an instance of the Movie entity in managedObjectContext
                        let movieEntity = Movie(context: managedObjectContext)
                        
                        // 2️⃣ Dress it up by specifying its attributes
                        movieEntity.title = movie.title
                        movieEntity.posterFileName = movie.posterFileName
                        movieEntity.overview = movie.overview
                        movieEntity.genres = movie.genres
                        movieEntity.releaseDate = movie.releaseDate
                        movieEntity.runtime = movie.runtime as NSNumber
                        movieEntity.director = movie.director
                        movieEntity.actors = movie.actors
                        movieEntity.mpaaRating = movie.mpaaRating
                        movieEntity.imdbRating = movie.imdbRating
                        movieEntity.youTubeTrailerId = movie.youTubeTrailerId
                        movieEntity.tmdbID = movie.tmdbID as NSNumber
                        
                        /*
                         ===========================================
                         MARK: ❎ Save Changes to Core Data Database
                         ===========================================
                         */

                        // The saveContext() method is given in Persistence.
                        PersistenceController.shared.saveContext()
                        
                        // Toggle database change indicator so that its subscribers can refresh their views
                        databaseChange.indicator.toggle()
                        
                        showMovieAddedMessage = true
                        
                        presentationMode.wrappedValue.dismiss()
                    }) {
                        HStack {
                            Image(systemName: "plus")
                                .imageScale(.medium)
                                .font(Font.title.weight(.regular))
                                .foregroundColor(.blue)
                            Text("Add Movie to Database")
                                .font(.system(size: 16))
                        }
                    }
                }
                Section(header: Text("Movie Runtime")) {
                    let hours = (movie.runtime) / 60
                    let minutes = (movie.runtime) - (hours * 60)
                    Text("\(hours) hours \(minutes) mins")
                }
                Section(header: Text("Movie Genres")) {
                    Text(movie.genres)
                }
                Section(header: Text("Movie Release Date")) {
                    Text(movie.releaseDate)
                }
                Section(header: Text("Movie Director")) {
                    Text(movie.director)
                }
            }
            Group {
                Section(header: Text("Movie Top Actors")) {
                    Text(movie.actors)
                }
                Section(header: Text("Movie MPAA Rating")) {
                    Text(movie.mpaaRating)
                }
                Section(header: Text("Movie IMDB Rating")) {
                    Text(movie.imdbRating)
                }
            }
            
        }   // End of Form
            .font(.system(size: 14))
            .navigationBarTitle(Text(movie.title), displayMode: .inline)
            .alert(isPresented: $showMovieAddedMessage, content: { self.movieAddedMessage })
        
    }   // End of body var
    
    var movieAddedMessage: Alert {
        Alert(title: Text("Movie Added!"),
              message: Text("Selected movie is added to your database as favorite."),
              dismissButton: .default(Text("OK")) )
    }
    
    var castData: some View {
        let querySpaceless = movie.title.replacingOccurrences(of: " ", with: "+")
        getCastSearchResultsFromApi(query: querySpaceless)
        
        return CastList()
    }
    
}

