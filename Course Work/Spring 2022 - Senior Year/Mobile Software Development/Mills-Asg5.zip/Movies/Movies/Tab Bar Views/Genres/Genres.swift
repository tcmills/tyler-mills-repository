//
//  Genres.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/16/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import WebKit
 
struct Genres : View {
    
    // ❎ Core Data managedObjectContext reference
    @Environment(\.managedObjectContext) var managedObjectContext
    
    // ❎ Core Data FetchRequest returning all Movie entities from the database
    @FetchRequest(fetchRequest: Movie.allMoviesFetchRequest()) var allMovies: FetchedResults<Movie>
    
    // Subscribe to changes in Core Data database
    @EnvironmentObject var databaseChange: DatabaseChange
   
    let movieGenresList = ["Action", "Adventure", "Animation", "Biography", "Comedy", "Crime", "Documentary", "Drama", "Family", "Fantasy", "Horror", "Music", "Mystery", "Romance", "Sci-Fi", "Suspense", "Thriller", "War", "Western"]
    
    @State private var selectedGenre = "Action"
   
    var body: some View {
        NavigationView {
            ZStack {
                // Color the background to light gray
                Color.gray.opacity(0.1).edgesIgnoringSafeArea(.all)
            VStack {
                Text("Genre List of Movies")
                    .font(.headline)
                Divider()
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(0 ..< movieGenresList.count, id: \.self) { index in
                       
                            Button(action: {
                                selectedGenre = movieGenresList[index]
                            }) {
                                VStack {
                                    Image(movieGenresList[index])
                                        .renderingMode(.original)
                                        .resizable()
                                        .aspectRatio(contentMode: .fit)
                                        .frame(height: 60.0)
                                    Text(movieGenresList[index])
                                        .fixedSize()
                                        .foregroundColor(movieGenresList[index] == selectedGenre ? .red : .blue)
                                        .multilineTextAlignment(.center)
                                }
                            }   // End of Button
                           
                        }   // End of ForEach
                       
                    }   // End of HStack
                    .font(.system(size: 14))
                   
                }   // End of ScrollView
                
                Divider()
                List {
                    ForEach(allMovies) { aMovie in
                        Group {
                            if aMovie.genres!.contains(selectedGenre) {
                                NavigationLink(destination: GenreDetails(movie: aMovie)) {
                                    GenreItem(movie: aMovie)
                                }
                            }
                        }
                    }
                }   // End of List
                .navigationBarHidden(true)
               
            }   // End of VStack
            }   // End of ZStack
        }
        .customNavigationViewStyle()  // Given in NavigationStyle.swift
        
    }
}

struct Genres_Previews: PreviewProvider {
    static var previews: some View {
        Genres()
    }
}
