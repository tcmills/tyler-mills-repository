//
//  MoviesData.swift
//  Movies
//
//  Created by Tyler Mills and Osman Balci on 4/7/22.
//  Copyright © 2022 Tyler Mills. All rights reserved.
//

import SwiftUI
import CoreData

// Array of MovieStruct structs obtained from the JSON file
// for use only in this file to create the database
fileprivate var arrayOfMovieStructs = [MovieStruct]()

public func createMoviesDatabase() {

    // ❎ Get object reference of Core Data managedObjectContext from the persistent container
    let managedObjectContext = PersistenceController.shared.persistentContainer.viewContext
    
    //----------------------------
    // ❎ Define the Fetch Request
    //----------------------------
    let fetchRequest = NSFetchRequest<Movie>(entityName: "Movie")
    fetchRequest.sortDescriptors = [NSSortDescriptor(key: "title", ascending: true)]
    
    var listOfAllMovieEntitiesInDatabase = [Movie]()
    
    do {
        //-----------------------------
        // ❎ Execute the Fetch Request
        //-----------------------------
        listOfAllMovieEntitiesInDatabase = try managedObjectContext.fetch(fetchRequest)
    } catch {
        print("Database Creation Failed!")
        return
    }
    
    if listOfAllMovieEntitiesInDatabase.count > 0 {
        print("Database has already been created!")
        return
    }
    
    print("Database will be created!")
    
    arrayOfMovieStructs = decodeJsonFileIntoArrayOfStructs(fullFilename: "MoviesData.json", fileLocation: "Main Bundle")

    for aMovie in arrayOfMovieStructs {
        /*
         =============================
         *   Movie Entity Creation   *
         =============================
         */
        
        // 1️⃣ Create an instance of the Movie entity in managedObjectContext
        let movieEntity = Movie(context: managedObjectContext)
        
        // 2️⃣ Dress it up by specifying its attributes
        movieEntity.title = aMovie.title
        movieEntity.posterFileName = aMovie.posterFileName
        movieEntity.overview = aMovie.overview
        movieEntity.genres = aMovie.genres
        movieEntity.releaseDate = aMovie.releaseDate
        movieEntity.runtime = aMovie.runtime as NSNumber
        movieEntity.director = aMovie.director
        movieEntity.actors = aMovie.actors
        movieEntity.mpaaRating = aMovie.mpaaRating
        movieEntity.imdbRating = aMovie.imdbRating
        movieEntity.youTubeTrailerId = aMovie.youTubeTrailerId
        movieEntity.tmdbID = aMovie.tmdbID as NSNumber
        
        /*
         *************************************
         ❎ Save Changes to Core Data Database
         *************************************
         */
        
        // The saveContext() method is given in Persistence.
        PersistenceController.shared.saveContext()
        
    }   // End of for loop

}
